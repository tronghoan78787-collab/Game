'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
for(const name of ['engine','expansion','director','operations'])require('../src/'+name+'.js');
const C=require('../src/commerce.js');
const E=globalThis.StoreEngine;
const root=path.resolve(__dirname,'..');
test('V71 preserves starting cash, staff and initial four selling zones',()=>{
 const s=E.createGame();assert.equal(s.cash,10_000_000);assert.deepEqual(s.staff.map(x=>x.name),['An','Bình']);
 assert.deepEqual(E.activeCats(s).map(c=>c.id),['drink','snack','milk','fruit']);
 assert.equal(s.commerce.prices.drink,14000);
});
test('V71 allows permitted category prices and rejects impossible ones',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'SET_PRICE',id:'drink',price:16000}).ok,true);
 for(const price of [0,5000,30000,13499,14000.5,Infinity,NaN,'invalid']){
  assert.equal(E.dispatch(s,{type:'SET_PRICE',id:'drink',price}).ok,false,String(price));}
 assert.equal(E.commercePrice(s,'drink'),16000);
});
test('V71 price changes do not modify import price or purchasing cash',()=>{
 const s=E.createGame();E.dispatch(s,{type:'SET_PRICE',id:'drink',price:16000});
 assert.equal(E.dispatch(s,{type:'ORDER',id:'drink',qty:12}).ok,true);
 assert.equal(s.cash,10_000_000-12*8000);
});
test('V71 price changes apply to actual paid receipts',()=>{
 const sell=price=>{const s=E.createGame();s.stock.drink=200;s.opened=true;s.everOpened=true;
  E.dispatch(s,{type:'SET_PRICE',id:'drink',price});for(let i=0;i<260;i++)E.advance(s,()=>.01);return s;};
 const normal=sell(14000),premium=sell(16000);
 assert.ok(normal.stats.served>=5);assert.equal(normal.stats.served,premium.stats.served);
 assert.equal(premium.stats.revenue-normal.stats.revenue,normal.stats.served*2000);
 assert.equal(premium.stats.cogs,normal.stats.cogs);
 assert.equal(premium.receipts[0].bill,16000);
});
test('V71 adjustment leaves global catalog prices unchanged for other saves',()=>{
 const s=E.createGame();E.dispatch(s,{type:'SET_PRICE',id:'drink',price:16000});
 for(let i=0;i<20;i++)E.advance(s,()=>.5);
 assert.equal(E.CATEGORIES.find(c=>c.id==='drink').price,14000);
 assert.equal(E.commercePrice(E.createGame(),'drink'),14000);
});
test('V72 event calendar is deterministic, cyclic, and offline',()=>{
 const ids=[1,2,3,4,5].map(day=>C.eventOf(day).id);assert.deepEqual(ids,['heat','family','rain','normal','heat']);
 assert.ok(C.EVENTS.every(x=>x.description&&x.weights.drink));
});
test('V72 higher featured demand and lower selling price raise preference weight',()=>{
 const s=E.createGame();const base=C.demand(s,'drink');
 E.dispatch(s,{type:'FEATURE_SKU',id:'drink',sku:'water'});const feat=C.demand(s,'drink');
 E.dispatch(s,{type:'SET_PRICE',id:'drink',price:12000});const cheap=C.demand(s,'drink');
 assert.ok(feat>base);assert.ok(cheap>feat);
});
test('V72 demand adjusts new NPC product preference without changing stock arbitrarily',()=>{
 const s=E.createGame();s.opened=true;s.everOpened=true;
 s.runtime.spawnIn=1;const before=E.stockTotal(s,'stock');E.advance(s,()=>0);
 assert.ok(s.customers.length>=1);assert.equal(s.customers[0].cat,'drink');
 assert.equal(E.stockTotal(s,'stock'),before);
});
test('V73 catalog has 3 valid SKUs per category and invalid feature rejected',()=>{
 const s=E.createGame();for(const cat of E.CATEGORIES){assert.equal(C.CATALOG.filter(x=>x.cat===cat.id).length,3);}
 assert.equal(E.dispatch(s,{type:'FEATURE_SKU',id:'milk',sku:'water'}).ok,false);
 assert.equal(E.dispatch(s,{type:'FEATURE_SKU',id:'frozen',sku:'icecream'}).ok,false);
 assert.equal(E.dispatch(s,{type:'FEATURE_SKU',id:'milk',sku:'yogurt'}).ok,true);
});
test('V73 features are persisted and do not make up SKU stock',()=>{
 const s=E.createGame();E.dispatch(s,{type:'FEATURE_SKU',id:'milk',sku:'yogurt'});
 const loaded=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(loaded.commerce.featured.milk,'yogurt');assert.equal(loaded.stock.milk,0);
 assert.equal(loaded.warehouse.milk,0);
});
test('V73 old V70 saves migrate without changing income or staff',()=>{
 const legacy=E.createGame();legacy.cash=9_543_000;delete legacy.commerce;
 const migrated=E.normalizeSave(JSON.parse(JSON.stringify(legacy)));
 assert.equal(migrated.cash,9_543_000);assert.equal(migrated.staff.length,2);
 assert.equal(migrated.commerce.prices.fruit,19000);
});
test('V73 cannot abuse save payload with overpriced price or bad featured SKU',()=>{
 const s=E.createGame();s.commerce.prices.drink=100000000;s.commerce.featured.drink='<script>';
 const fixed=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(fixed.commerce.prices.drink,14000);assert.equal(fixed.commerce.featured.drink,undefined);
});
test('V74 reward can be claimed once, adds exact amount and XP',()=>{
 const s=E.createGame();E.dispatch(s,{type:'FEATURE_SKU',id:'drink',sku:'water'});
 const before=s.cash;assert.equal(E.dispatch(s,{type:'CLAIM_GROWTH',id:'firstFeature'}).ok,true);
 assert.equal(s.cash,before+65000);
 assert.equal(E.dispatch(s,{type:'CLAIM_GROWTH',id:'firstFeature'}).ok,false);
});
test('V74 18 product PNG/SVG assets and 4 event banners available',()=>{
 for(const p of C.CATALOG){for(const ext of ['png','svg'])assert.ok(fs.statSync(path.join(root,'assets','merch',p.id+'.'+ext)).size>200);}
 for(const event of C.EVENTS)assert.ok(fs.statSync(path.join(root,'assets','merch',event.id+'_event.png')).size>200);
});
test('V75 market and product menus are accessible and actual frontend actions wired',()=>{
 const ui=fs.readFileSync(path.join(root,'src','app.js'),'utf8');
 for(const key of ['viewMerch','viewMarket','viewGrowth','data-adjust-price','data-feature-sku','CLAIM_GROWTH'])assert.ok(ui.includes(key),key);
 assert.ok(fs.readFileSync(path.join(root,'index.html'),'utf8').includes('src/commerce.js'));
});
test('V75 4 categories can reorder and cashier handles customer with stable money',()=>{
 const s=E.createGame();for(const id of ['drink','snack','milk','fruit'])assert.equal(E.dispatch(s,{type:'ORDER',id,qty:12}).ok,true);
 for(let i=0;i<70;i++)E.advance(s,()=>.5);
 assert.ok(E.stockTotal(s,'stock')>0);assert.equal(E.dispatch(s,{type:'OPEN'}).ok,true);
 for(let i=0;i<260;i++)E.advance(s,()=>.2);
 assert.ok(s.stats.served>=1);assert.ok(E.activeCats(s).every(c=>s.stock[c.id]>=0&&s.warehouse[c.id]>=0));
 assert.ok(s.cash>=0);
});
