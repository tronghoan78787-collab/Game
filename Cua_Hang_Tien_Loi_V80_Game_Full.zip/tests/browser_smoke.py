from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    html=(root/'index.html').read_text()
    html=html.replace('<link rel="stylesheet" href="src/style.css">','<style>'+ (root/'src/style.css').read_text() + '</style>')
    for script in ['engine','scene','scene3d','app']:
        html=html.replace('<script src="src/'+script+'.js"></script>','<script>'+ (root/'src'/ (script+'.js')).read_text()+'</script>')
    for mode,w,h,mobile in [('iphone_landscape',844,390,True),('iphone_portrait',390,844,True),('desktop',1280,720,False)]:
        context=browser.new_context(viewport={'width':w,'height':h},device_scale_factor=2 if mobile else 1,is_mobile=mobile,has_touch=mobile)
        page=context.new_page()
        page.on('pageerror',lambda exc:errors.append(str(exc)))
        page.set_content(html,wait_until='load',timeout=15000)
        page.wait_for_timeout(1200)
        page.screenshot(path=str(root/'screenshots'/f'{mode}.png'))
        initial=page.evaluate('({cash:window.ConvenienceGame.getState().cash,canvas:[document.querySelector("#scene").clientWidth,document.querySelector("#scene").clientHeight],buttons:document.querySelectorAll(".nav-item").length,loaded:!!window.StoreScene})')
        print(mode,initial)
        assert initial['cash']==10000000 and initial['buttons']==8 and initial['loaded']
        page.locator('[data-panel="order"]').last.click(force=True)
        assert page.locator('.game-modal').count()==1
        page.screenshot(path=str(root/'screenshots'/f'{mode}_order.png'))
        page.locator('[data-buy-order="drink"]').click()
        cash=page.evaluate('window.ConvenienceGame.getState().cash')
        print('cash after order',cash)
        assert cash==10000000-24*8000
        page.locator('.modal-heading .close').click()
        page.locator('[data-panel="staff"]').last.click(force=True)
        assert page.locator('#role-binh').count()==1
        page.locator('#role-binh').select_option('rest')
        assert page.evaluate('window.ConvenienceGame.getState().staff[1].role')=='rest'
        page.screenshot(path=str(root/'screenshots'/f'{mode}_staff.png'))
        page.locator('.modal-heading .close').click()
        page.locator('[data-panel="promo"]').last.click(force=True)
        page.locator('[data-set-promo="drink"]').click()
        assert page.evaluate('window.ConvenienceGame.getState().promo.rate')==10
        page.locator('.modal-heading .close').click()
        page.locator('[data-panel="shop"]').last.click(force=True)
        page.locator('[data-purchase="scanner"]').click()
        assert 'scanner' in page.evaluate('window.ConvenienceGame.getState().equipment')
        page.locator('[data-tab="decor"]').click()
        page.locator('[data-purchase="plant"]').click()
        assert 'plant' in page.evaluate('window.ConvenienceGame.getState().decor')
        page.locator('.modal-heading .close').click()
        page.locator('[data-panel="missions"]').last.click(force=True)
        page.locator('[data-claim="order24"]').click()
        assert 'order24' in page.evaluate('window.ConvenienceGame.getState().questsClaimed')
        page.locator('.modal-heading .close').click()
        context.close()
    browser.close()
print('PAGE ERRORS',errors)
assert not errors
