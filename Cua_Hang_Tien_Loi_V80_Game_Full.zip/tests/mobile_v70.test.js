'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const E=require('../src/engine.js');
const root=path.resolve(__dirname,'..');
test('V70 starter four shelves keeps exact opening economics and four orders',()=>{
 const s=E.createGame();assert.equal(s.cash,10_000_000);assert.equal(s.staff.length,2);
 const categories=['drink','snack','milk','fruit'];
 for(const id of categories)assert.equal(E.dispatch(s,{type:'ORDER',id,qty:12}).ok,true);
 assert.equal(s.cash,9_484_000);assert.equal(s.pending.length,4);
 assert.equal(s.stats.ordered,48);assert.deepEqual(categories.map(id=>s.stock[id]),[0,0,0,0]);
});
test('V70 warehouse receives and restocks before opening',()=>{
 const s=E.createGame();for(const id of ['drink','snack','milk','fruit'])E.dispatch(s,{type:'ORDER',id,qty:12});
 assert.equal(E.dispatch(s,{type:'OPEN'}).ok,false);
 for(let t=0;t<48;t++)E.advance(s,()=>0.5);
 assert.ok(E.stockTotal(s,'stock')>0);
 assert.equal(E.dispatch(s,{type:'OPEN'}).ok,true);
});
test('V70 Lite is a self-contained HTML with CSS and no external JS asset dependency',()=>{
 const lite=fs.readFileSync(path.join(root,'lite.html'),'utf8');
 assert.match(lite,/window\.EMBEDDED_SPRITES/);
 assert.match(lite,/window\.STORE_LITE_MODE=true/);
 assert.ok(!/<script\s+src=/.test(lite));
 assert.ok(!/<link\s+rel="stylesheet"\s+href=/.test(lite));
 assert.ok(lite.includes('NHẬP GÓI 4 KỆ'));
});
test('V70 Web PWA caches Lite version for offline installation',()=>{
 const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
 assert.ok(/mobile-v(?:70|80)\.0/.test(sw));
 assert.ok(sw.includes("'./lite.html'"));
});
test('V70 optimized sprites have 4 initial shelf variants and avatar fallback',()=>{
 for(const id of ['drink','snack','milk','fruit'])for(const fill of ['empty','low','full']){
   assert.ok(fs.statSync(path.join(root,'assets','art_webp',`${id}_${fill}.webp`)).size>100);
 }
 assert.ok(fs.statSync(path.join(root,'assets','avatars','an.svg')).size>100);
});
