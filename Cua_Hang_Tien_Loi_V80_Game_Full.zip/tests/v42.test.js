'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const P=path.resolve(__dirname,'..');
const raw=p=>fs.readFileSync(path.join(P,p),'utf8');
globalThis.STORE_RELEASE_STAGE=42;
const E=require('../src/engine.js');
require('../src/expansion.js');
require('../src/director.js');
const make=()=>E.createGame();

test('V42 keeps 10 million, exactly two employees and four starter categories',()=>{
 const s=make();assert.equal(s.cash,10000000);assert.equal(s.staff.length,2);
 assert.deepEqual(E.activeCats(s).map(c=>c.id),['drink','snack','milk','fruit']);
 assert.equal(s.staff[0].role,'cashier');assert.equal(s.staff[1].role,'operator');
});
test('V42 uses save format V12 and preserves old saves',()=>{
 const old=make();delete old.director;old.cash=7654321;
 const copy=E.normalizeSave(JSON.parse(JSON.stringify(old)));
 assert.equal(copy.cash,7654321);assert.ok(copy.director);
 assert.equal(copy.director.seenServed,copy.stats.served);
});
test('V38 AI descriptions are based on observable urgent events',()=>{
 const s=make();s.customers=[{stage:'needHelp',cat:'milk',patience:4},{stage:'queue'}];
 s.cleanliness=50;const list=E.recommendations(s);
 assert.equal(list[0].icon,'🙋');assert.ok(list.some(x=>x.icon==='🧹'));
 assert.ok(list[0].text.includes('khách'));
});
test('V38 team huddle improves mood only once a day',()=>{
 const s=make();s.staff[0].mood=50;const r=E.dispatch(s,{type:'TEAM_HUDDLE'});
 assert.equal(r.ok,true);assert.equal(s.staff[0].mood,56);
 assert.equal(E.dispatch(s,{type:'TEAM_HUDDLE'}).ok,false);
});
test('V38 complaint care requires real complaint and costs player funds',()=>{
 const s=make();assert.equal(E.dispatch(s,{type:'CUSTOMER_CARE'}).ok,false);
 s.customerCare.complaints=2;let start=s.cash;s.reputation=50;
 assert.equal(E.dispatch(s,{type:'CUSTOMER_CARE'}).ok,true);
 assert.equal(s.cash,start-30000);assert.equal(s.customerCare.complaints,1);
 assert.equal(E.dispatch(s,{type:'CUSTOMER_CARE'}).ok,false);
});
test('V39 forecast recognizes category stock and supplier deliveries',()=>{
 const s=make();let drink=E.salesForecast(s).find(x=>x.id==='drink');assert.ok(drink.pack>0);
 s.stock.drink=20;s.pending.push({cat:'drink',qty:12,received:0,arrived:false,arrivesAt:9});
 drink=E.salesForecast(s).find(x=>x.id==='drink');assert.equal(drink.pack,0);
});
test('V39 assisted ordering deducts cash and respects warehouse capacity',()=>{
 const s=make(),start=s.cash;const out=E.dispatch(s,{type:'AUTO_ORDER'});
 assert.equal(out.ok,true);assert.ok(s.pending.length>0);assert.ok(s.cash<start);
 assert.ok(s.pending.reduce((n,p)=>n+p.qty-p.received,0)<=E.warehouseCapacity(s));
});
test('V39 assisted ordering cannot spend below protected reserve',()=>{
 const s=make();s.cash=480000;
 assert.equal(E.dispatch(s,{type:'AUTO_ORDER'}).ok,false);assert.equal(s.cash,480000);
});
test('V39 forecast stays finite with dirty imported state',()=>{
 const s=make();s.director.salesByCat.drink=-999;
 E.salesForecast(s);assert.equal(s.director.salesByCat.drink,0);
 for(const p of E.salesForecast(s))assert.ok(Number.isFinite(p.target)&&p.pack>=0);
});
test('V40 both touch gesture codepaths exist and are independent from actual sales',()=>{
 assert.match(raw('src/scene.js'),/pinchLength\(/);
 assert.match(raw('src/scene3d.js'),/usedGesture/);
 assert.match(raw('src/style.css'),/touch-action:none/);
});
test('V41 daily contracts rotate over days and never pay out twice',()=>{
 const s=make();s.today.served=5;s.cleanliness=90;
 let first=E.contractList(s).find(c=>c.id==='smiles');assert.ok(first);
 const initial=s.cash;const out=E.dispatch(s,{type:'CLAIM_CONTRACT',id:'smiles'});
 assert.equal(out.ok,true);assert.equal(s.cash,initial+first.reward);
 assert.equal(E.dispatch(s,{type:'CLAIM_CONTRACT',id:'smiles'}).ok,false);
 s.day++;
 assert.equal(E.contractList(s).some(c=>c.id==='smiles'),true);
});
test('V41 incomplete contracts cannot be claimed for free money',()=>{
 const s=make();const before=s.cash;
 assert.equal(E.dispatch(s,{type:'CLAIM_CONTRACT',id:'profit'}).ok,false);
 assert.equal(s.cash,before);
});
test('V42 dialogue memory bounded and sanitized by UI',()=>{
 const s=make();for(let i=0;i<30;i++)E.directorNote(s,'Khách','Xin hỏi chỗ bán hàng '+i);
 assert.equal(s.director.dialogue.length,16);
 assert.match(raw('src/app.js'),/safe\(x\.text\)/);
});
test('V42 shipment and store workflow completes and tracks actual sold items',()=>{
 const s=make();const result=E.dispatch(s,{type:'ORDER',id:'drink',qty:96});assert.equal(result.ok,true);
 for(let i=0;i<125;i++)E.advance(s,()=>.55);
 assert.ok(s.stock.drink>0,'operator should stock shelves');
 assert.equal(E.dispatch(s,{type:'OPEN'}).ok,true);
 for(let i=0;i<600;i++)E.advance(s,()=>.55);
 assert.ok(s.stats.served>0,'cashier should complete checkout');
 assert.ok(s.receipts.length>0);
 assert.ok(s.receipts[0].items&&s.receipts[0].items.includes('drink'));
 assert.ok(s.director.salesByCat.drink>0);
});
test('V42 state remains JSON-restorable after extended play',()=>{
 const s=make();E.dispatch(s,{type:'AUTO_ORDER'});
 for(let i=0;i<2000;i++)E.advance(s,()=>.5);
 const t=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(t.stats.served,s.stats.served);
 assert.ok(t.cash>=0&&Number.isFinite(t.cash));
 for(const c of E.CATEGORIES)assert.ok(t.stock[c.id]>=0&&t.warehouse[c.id]>=0);
});
test('V42 delivery is offline and there are no required third-party API calls',()=>{
 const html=raw('index.html');assert.doesNotMatch(html,/<script[^>]+src=['"]https?:/);
 assert.doesNotMatch(raw('src/director.js'),/\bfetch\(|XMLHttpRequest|WebSocket\(/);
});
test('V42 service worker precaches director and important art assets',()=>{
 const sw=raw('sw.js');assert.match(sw,/cua-hang-tien-loi-mobile-v(?:70|80)\.0/);
 for(const x of ['director.js','hero_v37.svg','health.json'])assert.ok(sw.includes(x));
});
test('V42 guidance and AI panel remain accessible on the HUD',()=>{
 const html=raw('index.html'),app=raw('src/app.js');
 assert.match(html,/data-panel="advisor"/);assert.match(html,/data-panel="help"/);
 assert.match(app,/function viewAdvisor\(\)/);assert.match(app,/function viewContracts\(\)/);
});
test('V42 project can publish to a static HTTPS host without secrets',()=>{
 const workflow=raw('.github/workflows/deploy.yml');
 assert.match(workflow,/npm test/);assert.match(workflow,/needs: test/);
 const health=JSON.parse(raw('health.json'));assert.equal(health.deployed,false);
 assert.equal(health.release,'54.0.0-ios-rc');
});
test('V42 service worker install caches required core files and serves offline navigation', async()=>{
 const vm=require('node:vm');
 const listeners={};const cacheMap=new Map();let fetched=0;
 const cache={addAll:async files=>{for(const f of files)cacheMap.set(f,{status:200,body:'FILE:'+f,clone(){return this;}});},
   match:async req=>cacheMap.get(typeof req==='string'?req:req.url),put:async(k,v)=>cacheMap.set(k,v)};
 const caches={open:async()=>cache,keys:async()=>['cua-hang-tien-loi-v35.0','cua-hang-tien-loi-mobile-v55.0'],delete:async()=>true};
 const self={location:{origin:'https://shop.example'},addEventListener:(k,fn)=>{listeners[k]=fn;},skipWaiting:async()=>{},clients:{claim:async()=>{}}};
 const context={self,caches,URL,Response,AbortController,setTimeout,clearTimeout,fetch:async()=>{fetched++;throw Error('OFFLINE');}};
 vm.runInNewContext(raw('sw.js'),context);
 let install;listeners.install({waitUntil:p=>{install=p;}});await install;
 assert.ok(cacheMap.has('./src/director.js'));
 assert.ok(cacheMap.has('./index.html'));
 let responsePromise;
 listeners.fetch({request:{method:'GET',url:'https://shop.example/index.html',mode:'navigate'},respondWith:x=>{responsePromise=x;}});
 const response=await responsePromise;
 assert.equal(response.status,200);assert.equal(fetched,1);
});
