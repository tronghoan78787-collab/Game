from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
html=(R.parent/'cua_hang_tien_loi_mobile_V55_choi_ngay.html').read_text(encoding='utf8')
results=[]
for width,height,label in [(390,844,'iphone_portrait'),(844,390,'iphone_landscape'),(375,667,'iphone_se_portrait'),(932,430,'iphone_plus_landscape'),(667,375,'iphone_se_landscape'),(320,568,'small_portrait')]:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
  context=browser.new_context(viewport={'width':width,'height':height},is_mobile=True,has_touch=True,device_scale_factor=2)
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto('about:blank');page.evaluate('window.__CHIBI_QA__=true')
  page.set_content(html,wait_until='load',timeout=40000)
  page.evaluate('window.ConvenienceGame.ready')
  assert page.evaluate("getComputedStyle(document.querySelector('.game')).transform")=='none'
  assert page.locator('.mobile-nav-button:visible').count()==5
  assert page.locator('.stat-cash:visible').count()==1, 'Tiền khởi đầu phải luôn thấy trên điện thoại'
  assert '10.000.000' in page.locator('.stat-cash').inner_text()
  assert page.locator('#categoryQuick button:visible').count()==4
  assert page.evaluate('(()=>{const g=document.querySelector(".game").getBoundingClientRect();return Math.abs(g.width-innerWidth)<2&&Math.abs(g.height-innerHeight)<5;})()')
  page.locator('.mobile-nav-button[data-panel="order"]').tap()
  assert 'Đặt hàng' in page.locator('.modal-heading').inner_text()
  # Verify a finger can scroll a long order window in portrait; mobile dialogs must not trap scrolling.
  if width < height:
   session=context.new_cdp_session(page)
   box=page.locator('.modal-body').bounding_box()
   x=int(box['x']+box['width']*.48)
   start=int(box['y']+box['height']*.84)
   end=int(box['y']+box['height']*.24)
   session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':start}]})
   for i in range(1,11):
    y=int(start+(end-start)*i/10)
    session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':y}]})
    page.wait_for_timeout(18)
   session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
   page.wait_for_timeout(100)
   assert page.evaluate('document.querySelector(".modal-body").scrollTop')>0, 'Ngón tay phải cuộn được bảng đặt hàng'
  page.locator('[data-qty="24"][data-cat="drink"]').tap()
  before=page.evaluate('window.ConvenienceGame.getState().cash')
  page.locator('[data-buy-order="drink"]').tap()
  assert page.evaluate('window.ConvenienceGame.getState().cash')<before
  assert page.evaluate('window.ConvenienceGame.getState().pending.length')>=1
  # close using real mobile tap, not forced desktop click
  page.locator('.modal-heading .close').tap()
  assert page.locator('#modalRoot').is_hidden()
  page.locator('.mobile-nav-button[data-panel="staff"]').tap()
  assert 'Phân công nhân sự' in page.locator('.modal-heading').inner_text()
  page.locator('[data-role-staff="an"]').select_option('operator')
  assert page.evaluate('window.ConvenienceGame.getState().staff.find(s=>s.id==="an").role')=='operator'
  page.locator('[data-role-staff="an"]').select_option('cashier')
  page.locator('.modal-heading .close').tap()
  page.locator('.mobile-nav-button[data-panel="more"]').tap()
  assert 'Toàn bộ chức năng' in page.locator('.modal-heading').inner_text()
  assert page.locator('.mobile-more-tile').count()>=12
  page.locator('[data-action="testTouch"]').tap()
  assert 'Nút chạm' in page.locator('#floatText').inner_text()
  page.locator('.mobile-more-tile[data-panel="operations"]').tap()
  assert 'Trung tâm vận hành' in page.locator('.modal-heading').inner_text()
  page.locator('.modal-heading .close').tap()
  page.locator('#categoryQuick [data-cat-panel="fruit"]').tap()
  assert 'Quản lý kệ hàng' in page.locator('.modal-heading').inner_text()
  page.locator('.modal-heading .close').tap()
  page.locator('.mobile-nav-button[data-panel="missions"]').tap()
  assert 'Nhiệm vụ cửa hàng' in page.locator('.modal-heading').inner_text()
  page.locator('.modal-heading .close').tap()
  # opening shop later is automatic by operator loading stock
  page.evaluate('window.ConvenienceGame.advanceForTest(35)')
  stock=page.evaluate('Object.values(window.ConvenienceGame.getState().stock).reduce((a,b)=>a+b,0)')
  assert stock>0,stock
  page.locator('.mobile-nav-button[data-panel="store"]').tap()
  # use enabled open button in management, not tapping canvas
  page.locator('.modal-body [data-action="open"]').tap()
  assert page.evaluate('window.ConvenienceGame.getState().opened')
  page.evaluate('window.ConvenienceGame.advanceForTest(70)')
  page.screenshot(path=str(R/f'V55_{label}.png'))
  assert not errors,errors
  results.append({'view':f'{width}x{height}','label':label,'touchControls':5,'categories':4,'ordered':True,'staff':True,'more':True,'shelves':True,'opened':True,'errors':errors})
  browser.close()
(R/'QA_TOUCH_V55.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(results,ensure_ascii=False,indent=2))
