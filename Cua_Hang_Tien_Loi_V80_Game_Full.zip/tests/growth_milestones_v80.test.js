'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const {spawnSync}=require('node:child_process');
function run(stage){
 const js=`globalThis.STORE_RELEASE_STAGE=30;globalThis.STORE_OPERATIONS_STAGE=54;globalThis.STORE_COMMERCE_STAGE=75;globalThis.STORE_GROWTH_STAGE=${stage};const E=require('./src/engine.js');require('./src/expansion.js');require('./src/director.js');require('./src/operations.js');require('./src/commerce.js');require('./src/growth_v80.js');let s=E.createGame();s.level=8;s.cash=40000000;for(let i=0;i<3;i++)E.dispatch(s,{type:'EXPAND'});let k=0;for(let i=0;i<6;i++){if(E.dispatch(s,{type:'HIRE'}).ok)k++}console.log(JSON.stringify({tier:s.storeLevel,types:E.activeCats(s).length,staff:s.staff.length,hired:k,area:E.growthArea(s)}));`;
 const out=spawnSync(process.execPath,['-e',js],{cwd:require('node:path').resolve(__dirname,'..'),encoding:'utf8'});
 assert.equal(out.status,0,out.stderr);return JSON.parse(out.stdout);
}
for(const [stage,expected] of [
 [76,{tier:3,types:8,staff:4,hired:2,area:144}],
 [77,{tier:3,types:8,staff:6,hired:4,area:144}],
 [78,{tier:4,types:10,staff:6,hired:4,area:192}],
 [79,{tier:4,types:10,staff:8,hired:6,area:192}],
 [80,{tier:4,types:10,staff:8,hired:6,area:192}]
])test(`V${stage} enables exactly its milestone features`,()=>assert.deepEqual(run(stage),expected));
