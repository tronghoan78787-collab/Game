/** V21–V24 acceptance tests. Run: npm test */
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../src/engine.js');
const step=(s,n,r=()=>.52)=>{for(let i=0;i<n;i++)E.advance(s,r);};

test('V21 starts with correct balance, role assignments and fresh-batch empty',()=>{
 const s=E.createGame();assert.equal(s.cash,10000000);assert.deepEqual(s.staff.map(m=>m.role),['cashier','operator']);
 assert.deepEqual(s.lots,{stock:{fruit:[],milk:[]},warehouse:{fruit:[],milk:[]}});
});
test('V21 fresh batches remain separate and FIFO moves oldest to shelf first',()=>{
 const s=E.createGame();s.day=2;s.warehouse.fruit=8;s.lots.warehouse.fruit=[{day:1,qty:5},{day:2,qty:3}];
 s.staff[1].x=E.CATEGORIES.find(c=>c.id==='fruit').pos[0]+30;s.staff[1].y=E.CATEGORIES.find(c=>c.id==='fruit').pos[1]+66;
 E.advance(s,()=>.5);
 assert.equal(s.stock.fruit,8);assert.deepEqual(s.lots.stock.fruit,[{day:1,qty:5},{day:2,qty:3}]);
 assert.equal(s.warehouse.fruit,0);
});
test('V21 older fruit is disposed while newer fruit remains',()=>{
 const s=E.createGame();s.day=3;s.minutes=1318;s.stock.fruit=10;s.lots.stock.fruit=[{day:1,qty:6},{day:3,qty:4}];
 E.advance(s,()=>.5);assert.equal(s.day,4);assert.equal(s.stock.fruit,4);
 assert.deepEqual(s.lots.stock.fruit,[{day:3,qty:4}]);assert.equal(s.stats.wasteCost,6*11000);
 assert.equal(s.today.wasteCost,6*11000);
});
test('V21 old V20 saves get fresh lot metadata without changing stock or cash',()=>{
 const prior=E.createGame();prior.cash=7370000;prior.stock.milk=7;prior.freshDay.milk=2;prior.day=4;delete prior.lots;
 const s=E.normalizeSave(JSON.parse(JSON.stringify(prior)));
 assert.equal(s.cash,7370000);assert.equal(s.stock.milk,7);assert.deepEqual(s.lots.stock.milk,[{day:2,qty:7}]);
});
test('V22 operator automatically rests when exhausted then resumes same role',()=>{
 const s=E.createGame();const op=s.staff[1];op.energy=13;E.advance(s,()=>.5);
 assert.equal(op.role,'operator');assert.equal(op.autoRest,true);
 step(s,13);assert.equal(op.autoRest,false);assert.equal(op.role,'operator');
});
test('V22 quick delivery contract is optional and advances eta',()=>{
 const s=E.createGame();E.dispatch(s,{type:'ORDER',id:'drink',qty:12});assert.equal(s.pending[0].arrivesAt,9);
 assert.equal(E.dispatch(s,{type:'BUY_EQUIPMENT',id:'express'}).ok,true);
 E.dispatch(s,{type:'ORDER',id:'snack',qty:12});assert.equal(s.pending[1].arrivesAt,5);
});
test('V22 cashier receipts only appear on actual payment',()=>{
 const s=E.createGame();s.stock.drink=23;s.staff[0].x=300;s.staff[0].y=369;
 E.dispatch(s,{type:'OPEN'});step(s,250);assert.ok(s.stats.served>0);
 assert.equal(s.receipts.length,Math.min(s.stats.served,40));
 for(const r of s.receipts){assert.ok(r.bill>0);assert.ok(r.cogs>0);assert.ok(r.qty>0);}
});
test('V22 customer complaint counter and review record remain in sync',()=>{
 const s=E.createGame();s.stock.drink=8;E.dispatch(s,{type:'OPEN'});
 E.dispatch(s,{type:'SET_ROLE',staffId:'an',role:'rest'});
 step(s,100);assert.ok(s.stats.missed>=1);assert.equal(s.customerCare.complaints,s.stats.missed);
});
test('V23 staff bonus is deducted once and improves mood',()=>{
 const s=E.createGame();const m=s.staff[0];m.mood=51;
 assert.equal(E.dispatch(s,{type:'STAFF_BONUS',staffId:'an'}).ok,true);
 assert.equal(s.cash,9950000);assert.equal(m.mood,71);assert.equal(s.stats.wages,50000);
});
test('V23 staff bonus cannot be paid without enough cash',()=>{
 const s=E.createGame();s.cash=20000;assert.equal(E.dispatch(s,{type:'STAFF_BONUS',staffId:'binh'}).ok,false);
 assert.equal(s.cash,20000);
});
test('V23 inventory audit reports shelf, backroom and acquisition value',()=>{
 const s=E.createGame();s.stock.drink=10;s.warehouse.drink=7;
 const record=E.inventoryAudit(s).find(x=>x.id==='drink');
 assert.equal(record.shelf,10);assert.equal(record.warehouse,7);assert.equal(record.stockValue,17*8000);
});
test('V24 normalization preserves settled receipts and customer loyalty',()=>{
 const s=E.createGame();s.receipts=[{day:1,time:510,customer:'săn ưu đãi',qty:2,bill:46000,cogs:28000}];
 s.customerCare.loyalty=3;let loaded=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.deepEqual(loaded.receipts,s.receipts);assert.equal(loaded.customerCare.loyalty,3);
});
test('V24 no negative quantities in a 12-day mixed simulation with rest and delivery',()=>{
 const s=E.createGame();s.storeLevel=2;s.level=4;
 for(const c of E.activeCats(s)){s.stock[c.id]=20;s.warehouse[c.id]=20;}
 s.lots.stock.fruit=[{day:1,qty:20}];s.lots.warehouse.fruit=[{day:1,qty:20}];
 s.lots.stock.milk=[{day:1,qty:20}];s.lots.warehouse.milk=[{day:1,qty:20}];
 E.dispatch(s,{type:'OPEN'});step(s,4800);
 for(const cat of E.activeCats(s)){assert.ok(s.stock[cat.id]>=0);assert.ok(s.warehouse[cat.id]>=0);}
 assert.ok(s.cash>=0);assert.ok(s.stats.served>0);assert.ok(s.history.length>0);
});
test('V24 damaged save collections are safely normalized',()=>{
 const s=E.normalizeSave({version:12,stock:null,warehouse:null,staff:[],cash:90000,stats:null,settings:null,day:1});
 assert.equal(s.cash,90000);assert.equal(s.staff.length,2);assert.equal(E.stockTotal(s,'stock'),0);
});
