/** V31–V35 release-candidate acceptance tests; deterministic, offline-first. */
'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const ROOT=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');
const E=require('../src/engine.js');

test('V31 deploy files and offline precache include every required app source',()=>{
 for(const file of ['index.html','netlify.toml','.github/workflows/deploy.yml','DEPLOY.md','404.html','sw.js'])assert.ok(fs.existsSync(path.join(ROOT,file)),file);
 const sw=read('sw.js');assert.match(sw,/cua-hang-tien-loi-mobile-v(?:70|80)\.0/);
 for(const item of ['engine.js','expansion.js','scene.js','scene3d.js','app.js','audio.js','style.css'])assert.ok(sw.includes(item),item);
});
test('V31 no third-party CDN or trackers on page',()=>{
 assert.doesNotMatch(read('index.html'),/<script[^>]+src=['"]https?:/);
 assert.doesNotMatch(read('index.html'),/<link[^>]+href=['"]https?:/);
 assert.doesNotMatch(read('index.html'),/google-analytics|facebook\.com\/tr|hotjar|adsense/i);
});
test('V32 shader supports daylight-dependent light and low-poly emotional characters',()=>{
 const scene=read('src/scene3d.js');
 for(const pattern of [/uniform float uSun/,/uniform1f/,/const blink=/,/scanGlow/,/Vệ sinh\|dọn\|lau/])assert.match(scene,pattern);
});
test('V33 accessibility: viewport-fit, status and help panel are included',()=>{
 const page=read('index.html');const app=read('src/app.js');
 assert.match(page,/viewport-fit=cover/);assert.match(page,/id="connectionNote"/);
 assert.match(page,/id="fpsBadge"/);assert.match(app,/updateConnection/);
 assert.match(app,/function viewHelp\(/);assert.match(page,/data-panel="help"/);
});
test('V34 sound generator is locked until interaction and never calls remote endpoints',()=>{
 const src=read('src/audio.js');
 let created=0;const timers=[];const events={};
 class AudioContextMock{constructor(){created++;this.state='running';this.currentTime=1;this.destination={};}
  createOscillator(){return {type:'sine',frequency:{setValueAtTime(){}},connect(){},start(){},stop(){}};}
  createGain(){return {gain:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){}};}}
 const window={AudioContext:AudioContextMock,addEventListener:(k,h)=>events[k]=h};
 const context={window,document:{hidden:false},performance:{now:()=>200},setInterval:(f,t)=>{timers.push(f);return 2;},clearInterval(){}};
 vm.runInNewContext(src,context);assert.ok(window.StoreAudio);assert.equal(created,0);
 window.StoreAudio.play('checkout');assert.equal(created,0);
 window.StoreAudio.unlock();assert.equal(created,1);
 window.StoreAudio.setEnabled(true);window.StoreAudio.play('checkout');window.StoreAudio.play('achievement');
 window.StoreAudio.setAmbient(true);assert.equal(timers.length,1);
 window.StoreAudio.setEnabled(false);assert.equal(window.StoreAudio.getEnabled(),false);
 assert.doesNotMatch(src,/fetch\(|XMLHttpRequest|https?:\/\//);
});
test('V35 retains 10 million dong, 2 free staff, and 4 starter categories',()=>{
 const state=E.createGame();assert.equal(state.cash,10000000);
 assert.deepEqual(state.staff.map(x=>x.role),['cashier','operator']);assert.deepEqual(E.activeCats(state).map(x=>x.id),['drink','snack','milk','fruit']);
});
test('V35 saved game survives serialization without losing money or roles',()=>{
 const state=E.createGame();E.dispatch(state,{type:'ORDER',id:'drink',qty:24});
 E.dispatch(state,{type:'SET_ROLE',staffId:'binh',role:'cashier'});
 const restored=E.normalizeSave(JSON.parse(JSON.stringify(state)));
 assert.equal(restored.cash,state.cash);assert.equal(restored.staff[1].role,'cashier');assert.equal(restored.stats.ordered,24);
});
test('V35 simulation 2000 ticks has finite balance and nonnegative inventory',()=>{
 const state=E.createGame();E.dispatch(state,{type:'ORDER',id:'drink',qty:24});
 for(let i=0;i<2000;i++)E.advance(state,()=>.55);
 assert.ok(Number.isFinite(state.cash));assert.ok(state.cash>=0);
 for(const id of E.CATEGORIES.map(c=>c.id)){
  assert.ok((state.stock[id]||0)>=0,id);assert.ok((state.warehouse[id]||0)>=0,id);
 }
});
