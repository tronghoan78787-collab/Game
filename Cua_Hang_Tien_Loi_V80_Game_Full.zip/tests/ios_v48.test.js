/** V43–V48 iOS release validations. Simulations do not certify physical iPhone / WebKit. */
'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ROOT=path.resolve(__dirname,'..');const read=name=>fs.readFileSync(path.join(ROOT,name),'utf8');
const E=require('../src/engine.js');const Vault=require('../src/vault.js');
test('V43 dynamic Safari viewport is measured without a blocking rotate overlay',()=>{
 const html=read('index.html'),js=read('src/ios.js'),css=read('src/style.css');
 assert.match(html,/viewport-fit=cover/);assert.match(js,/visualViewport/);assert.match(css,/--ios-view-height/);
 assert.doesNotMatch(html,/Hãy xoay điện thoại sang ngang để chơi/);
});
test('V43 touch controls retain bottom HUD within the landscape scene',()=>{
 const html=read('index.html'),css=read('src/style.css');
 assert.match(html,/class="bottom-nav"/);assert.match(html,/data-panel="staff"/);
 assert.match(css,/safe-area-inset-left/);assert.match(css,/--ios-view-width/);
});
test('V44 serializable checksum catches damaged saves',()=>{
 const state=E.createGame(),encoded=JSON.stringify(state),hash=Vault.checksum(encoded);
 assert.equal(Vault.validJSON(encoded,hash).cash,10000000);
 assert.equal(Vault.validJSON(encoded,hash.slice(1)),null);
 assert.equal(Vault.validJSON('{',null),null);
 assert.equal(Vault.validJSON(JSON.stringify({...state,version:999}),null),null);
});
test('V44 new game preserves V12 save format and two employees',()=>{
 const s=E.createGame();assert.equal(s.version,12);assert.equal(s.cash,10000000);assert.equal(s.staff.length,2);
 assert.deepEqual(E.activeCats(s).map(c=>c.id),['drink','snack','milk','fruit']);
 assert.match(read('src/app.js'),/cua_hang_tien_loi_chibi_v12/);
 assert.match(read('src/app.js'),/StoreVault\?\.latest/);
});
test('V44 backup has size cap and secondary IndexedDB store',()=>{
 assert.ok(Vault.MAX_BYTES>=1000000&&Vault.MAX_BYTES<=3000000);
 const code=read('src/vault.js');assert.match(code,/createObjectStore/);assert.match(code,/snapshot/);
 assert.match(code,/\.slice\(3\)/);
});
test('V45 accessible preferences can be changed but reject invalid types',()=>{
 const s=E.createGame();assert.equal(s.settings.largeText,false);assert.equal(s.settings.reducedMotion,false);
 assert.equal(E.dispatch(s,{type:'SETTING',key:'largeText',value:true}).ok,true);
 assert.equal(E.dispatch(s,{type:'SETTING',key:'reducedMotion',value:true}).ok,true);
 assert.equal(E.dispatch(s,{type:'SETTING',key:'reducedMotion',value:'oops'}).ok,false);
 assert.equal(s.settings.largeText,true);
});
test('V45 quality and reduced-motion are reflected by both renderers',()=>{
 assert.match(read('src/scene.js'),/settings\?\.reducedMotion/);
 assert.match(read('src/scene3d.js'),/settings\?\.reducedMotion/);
 assert.match(read('src/style.css'),/large-text/);
 assert.match(read('src/style.css'),/reduced-motion/);
});
test('V46 export uses iOS Files share when supported with fallback',()=>{
 const app=read('src/app.js');assert.match(app,/navigator\.canShare/);
 assert.match(app,/navigator\.share/);assert.match(app,/fallbackDownload/);
 assert.match(app,/StoreVault\?\.flush/);
});
test('V47 caches every app entrypoint including vault and ios viewport',()=>{
 const sw=read('sw.js');assert.match(sw,/cua-hang-tien-loi-mobile-v(?:70|80)\.0/);
 for(const filename of ['ios.js','vault.js','engine.js','scene3d.js','app.js','style.css','manifest.webmanifest'])assert.ok(sw.includes(filename));
 const assetList=[...sw.matchAll(/'\.\/([^']+)'/g)].map(x=>x[1]);
 for(const item of assetList)assert.ok(fs.existsSync(path.join(ROOT,item)),'missing '+item);
});
test('V47 cache update waits for user-triggered activation',()=>{
 const listeners={};let skip=0;const mock={location:{origin:'https://game.test'},addEventListener:(name,handler)=>listeners[name]=handler,skipWaiting:()=>{skip++;},clients:{claim:async()=>{}}};
 const context={self:mock,caches:{open:async()=>({addAll:async()=>{}}),keys:async()=>[],delete:async()=>{}},URL,Response,AbortController,setTimeout,clearTimeout};
 vm.runInNewContext(read('sw.js'),context);
 let promise;listeners.install({waitUntil:p=>{promise=p;}});
 return Promise.resolve(promise).then(()=>{assert.equal(skip,0);listeners.message({data:{type:'ACTIVATE_UPDATE'}});assert.equal(skip,1);});
});
test('V48 Capacitor iOS scaffold is valid and requires no hardcoded remote server',()=>{
 const config=JSON.parse(read('ios-shell/capacitor.config.json'));
 assert.match(config.appId,/^com\./);assert.equal(config.webDir,'www');assert.equal(config.server.iosScheme,'capacitor');
 assert.equal(fs.existsSync(path.join(ROOT,'ios-shell/www/index.html')),true);
});
test('V48 independent html bundler embeds all JavaScript and avatars',()=>{
 const builder=read('tools/build_standalone.py');assert.match(builder,/EMBEDDED_AVATARS/);
 assert.match(read('src/app.js'),/avatarURL\(m\.id\)/);
 assert.equal(JSON.parse(read('health.json')).deployed,false);
 assert.match(read('DEPLOY.md'),/https/i);
});
