const test=require('node:test');const a=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const root=path.resolve(__dirname,'..');
const motion=require('../src/motion.js');
for(const id of ['drink','snack','milk','fruit','noodle','frozen'])test('V61 shipped authored '+id+' product vector and PNG',()=>{for(const ext of ['svg','png']){const p=path.join(root,'assets/art/product_'+id+'.'+ext);a.ok(fs.existsSync(p));a.ok(fs.statSync(p).size>500);}});
for(const id of ['plant','flower','lamp','poster','mascot'])test('V61 bundled decoration '+id,()=>{a.ok(fs.existsSync(path.join(root,'assets/art/decor_'+id+'.png')))});
test('V62 cashier uses scan when queue present',()=>{a.equal(motion.classify({role:'cashier',task:'Tính tiền',energy:90},true,[{stage:'queue'}]),'scan');a.equal(motion.classify({role:'cashier',task:'Tính tiền',energy:90},true,[]),'idle');});
test('V62 operator handles customer before stock task when asked',()=>{a.equal(motion.classify({role:'operator',task:'Hỗ trợ khách',energy:80},true,[]),'wave');a.equal(motion.classify({role:'operator',task:'Nhận hàng',energy:80},true,[]),'work');});
test('V62 moving and reduced motion isolated',()=>{a.equal(motion.stride(true,90,0,true),0);a.equal(motion.stride(false,90),0);a.equal(motion.expression(12),'sad');});
test('V63 linked production icon UI and touch affordances',()=>{const ui=fs.readFileSync(path.join(root,'src/app.js'),'utf8');a.match(ui,/product-icon/);const css=fs.readFileSync(path.join(root,'src/style.css'),'utf8');a.match(css,/focus-visible/);});
test('V64 cached static world and touch highlight',()=>{const scene=fs.readFileSync(path.join(root,'src/scene.js'),'utf8');a.match(scene,/cacheWorld\(s\)/);a.match(scene,/tapFeedback/);a.match(scene,/StoreMotion\?\.classify/);});
test('V65 all offline assets cached',()=>{const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');a.match(sw,/mobile-v(?:70|80)/);a.match(sw,/src\/motion\.js/);for(const id of ['product_drink','product_fruit','decor_lamp'])a.ok(sw.includes(id+'.png'));});

test('V65 GLB model atlas decodes typed triangles and renderer uses it for shelves',()=>{
 const atlas=require('../src/model_assets.js');
 a.ok(atlas.isAuthoredGLB);a.ok(atlas.names.length>=18);
 for(const name of ['shelf_drink_full','shelf_fruit_empty','checkout','an_scan']){
  const vertices=atlas.get(name);a.ok(vertices instanceof Float32Array);a.ok(vertices.length>0);a.equal(vertices.length%9,0);
  for(let i=0;i<Math.min(50,vertices.length);i++)a.ok(Number.isFinite(vertices[i]));
 }
 const s=fs.readFileSync(path.join(root,'src/scene3d.js'),'utf8');
 a.match(s,/addAuthoredModel/);a.match(s,/shelf_/);a.match(s,/checkout/);
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');a.match(html,/src\/model_assets\.js/);
});

test('V65 authored staff pose is selected from real operator/cashier task in WebGL',()=>{
 const scene=fs.readFileSync(path.join(root,'src/scene3d.js'),'utf8');
 a.match(scene,/\['an','binh'\]\.includes\(person\.id\)/);
 a.match(scene,/person\.id\+'_'\+pose/);
 a.match(scene,/StoreMotion\?\.classify/);
});
