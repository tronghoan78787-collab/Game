from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];h=(R.parent/'cua_hang_tien_loi_mobile_V55_choi_ngay.html').read_text(encoding='utf8')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width,height,name in [(390,844,'portrait'),(844,390,'landscape')]:
  page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1,is_mobile=True,has_touch=True)
  page.set_content(h);page.evaluate('window.ConvenienceGame.ready')
  if page.locator('.coach-close').is_visible():page.locator('.coach-close').tap()
  page.wait_for_timeout(250)
  page.screenshot(path=str(R/f'V55_SCREEN_{name}.png'))
  page.locator('.mobile-nav-button[data-panel="more"]').tap()
  page.screenshot(path=str(R/f'V55_MENU_{name}.png'))
  page.close()
 browser.close()
