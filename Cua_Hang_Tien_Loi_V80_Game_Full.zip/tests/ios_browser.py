"""Automated iPhone-size Chromium testing of the exact V48 standalone HTML.
No claims of Safari/WebKit device certification. External network and localhost blocked.
"""
import json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
STANDALONE=ROOT.parent/'cua_hang_tien_loi_ios_V48_choi_ngay.html'
assert STANDALONE.exists(),'Run python3 tools/build_standalone.py first'
html=STANDALONE.read_text(encoding='utf-8').replace('<body>','<body><script>window.__CHIBI_QA__=true;</script>',1)
results=[]
with sync_playwright() as pl:
 browser=pl.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
 for w,h,label in [(844,390,'iphone_landscape'),(390,844,'iphone_portrait'),(1280,720,'desktop')]:
  context=browser.new_context(viewport={'width':w,'height':h},has_touch=True,is_mobile=True,accept_downloads=True,locale='vi-VN',service_workers='block')
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load',timeout=25000)
  page.wait_for_function('typeof ConvenienceGame!=="undefined"',timeout=12000)
  page.evaluate('ConvenienceGame.ready')
  initial=page.evaluate('ConvenienceGame.getState()')
  assert initial['cash']==10000000 and len(initial['staff'])==2 and not initial['opened']
  assert '10.000.000' in page.locator('#money').inner_text()
  assert page.locator('.bottom-nav').is_visible()
  assert not page.get_by_text('Hãy xoay điện thoại sang ngang để chơi').count()
  # Save UX + accessibility preferences
  page.locator('nav [data-panel="settings"]').click(force=True)
  assert 'Thêm vào Màn hình chính' in page.locator('.modal-body').inner_text()
  page.locator('[data-action="largeText"]').click(force=True)
  assert page.evaluate('ConvenienceGame.getState().settings.largeText')
  page.locator('[data-action="reduceMotion"]').click(force=True)
  assert page.evaluate('ConvenienceGame.getState().settings.reducedMotion')
  page.locator('select#quality').select_option('low')
  assert page.evaluate('ConvenienceGame.getState().settings.quality')=='low'
  page.locator('.modal-heading .close').click(force=True)
  # Order, restock, open, sell
  page.locator('nav [data-panel="order"]').click(force=True)
  page.locator('[data-buy-order="drink"]').first.click(force=True)
  assert page.evaluate('ConvenienceGame.getState().stats.ordered')>0
  page.locator('.modal-heading .close').click(force=True)
  page.evaluate('ConvenienceGame.advanceForTest(135)')
  assert page.evaluate('ConvenienceGame.getState().stock.drink')>0
  page.evaluate('ConvenienceGame.dispatch({type:"OPEN"})')
  page.evaluate('ConvenienceGame.advanceForTest(350)')
  live=page.evaluate('ConvenienceGame.getState()')
  assert live['stats']['served']>=1 and live['stats']['revenue']>0
  assert len(live['receipts'])>0
  assert all(v>=0 for v in live['stock'].values())
  page.screenshot(path=str(ROOT/f'V48_GAMEPLAY_{label}.png'),full_page=False)
  # UI report and human resources
  page.locator('nav [data-panel="staff"]').click(force=True)
  assert page.locator('[data-role-staff="an"]').count()==1
  page.screenshot(path=str(ROOT/f'V48_STAFF_{label}.png'),full_page=False)
  page.locator('.modal-heading .close').click(force=True)
  page.locator('nav [data-panel="report"]').click(force=True)
  assert 'Doanh thu hôm nay' in page.locator('.modal-body').inner_text()
  page.locator('.modal-heading .close').click(force=True)
  # export import via native HTML file input, preserving exact save contents
  page.locator('nav [data-panel="settings"]').click(force=True)
  snapshot=json.dumps(live,ensure_ascii=False).encode('utf8')
  page.on('dialog',lambda dialog:dialog.accept())
  page.locator('[data-action="reset"]').click(force=True)
  assert page.evaluate('ConvenienceGame.getState().stats.served')==0
  page.locator('nav [data-panel="settings"]').click(force=True)
  page.locator('#importFile').set_input_files({'name':'chibi-save.json','mimeType':'application/json','buffer':snapshot})
  page.wait_for_function('ConvenienceGame.getState().stats.served>0',timeout=7000)
  assert page.evaluate('ConvenienceGame.getState().cash')==live['cash']
  assert not errors,errors
  results.append({'viewport':f'{w}x{h}','device_simulation':label,'served':live['stats']['served'],'revenue':live['stats']['revenue'],'renderer':page.evaluate('ConvenienceGame.renderer()'),'errors':len(errors),'result':'PASS'})
  context.close()
 browser.close()
(ROOT/'QA_V48_BROWSER.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
