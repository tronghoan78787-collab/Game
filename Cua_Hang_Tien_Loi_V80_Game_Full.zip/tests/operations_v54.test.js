/* V49–V54: kiểm thử nghiệp vụ và tính nhất quán, Node 18+, không yêu cầu browser. */
'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
require('../src/engine.js');
require('../src/expansion.js');
require('../src/director.js');
const OPS=require('../src/operations.js');
const E=globalThis.StoreEngine;
const newGame=()=>E.createGame();

test('V49: từ bản V48 chuyển sang V54 vẫn giữ 10 triệu, bốn kệ và 2 nhân viên',()=>{
 const s=newGame();
 assert.equal(s.cash,10000000);assert.equal(s.staff.length,2);
 assert.deepEqual(E.activeCats(s).map(c=>c.id),['drink','snack','milk','fruit']);
 assert.equal(s.operations.finance.openingCash,s.cash);
 assert.equal(E.financeAudit(s).valid,true);
 assert.equal(E.OPERATIONS_RELEASE,54);
});
test('V49: sổ tiền ghi ORDER và khớp số dư',()=>{
 const s=newGame(),before=s.cash;
 assert.equal(E.dispatch(s,{type:'ORDER',id:'drink',qty:24}).ok,true);
 assert.equal(s.cash,before-24*8000);
 const audit=E.financeAudit(s);
 assert.equal(audit.valid,true);assert.equal(audit.entries[0].delta,-192000);
 assert.equal(audit.entries[0].type,'ORDER');
});
test('V49: giao dịch sai không được trừ tiền hoặc tạo bút toán',()=>{
 const s=newGame();const cash=s.cash;
 assert.equal(E.dispatch(s,{type:'ORDER',id:'fruit',qty:0}).ok,false);
 assert.equal(s.cash,cash);assert.equal(E.financeAudit(s).recorded,0);
});
test('V49: kế toán theo dõi lương và giao dịch sau khi sang ngày',()=>{
 const s=newGame();E.dispatch(s,{type:'ORDER',id:'drink',qty:24});
 // Thời gian mở không bắt buộc để thanh toán lương ngày game.
 s.minutes=21*60+58;E.advance(s,()=>.5);
 assert.equal(s.day,2);assert.equal(E.financeAudit(s).valid,true);
 assert.ok(E.financeAudit(s).entries.some(x=>x.type==='DAILY_EXPENSE'));
});
test('V50: định mức được kiểm soát chặt',()=>{
 const s=newGame();
 assert.equal(E.dispatch(s,{type:'SET_REORDER_RULE',id:'fruit',minimum:12,target:24}).ok,true);
 assert.equal(s.operations.reorder.fruit.minimum,12);
 assert.equal(E.dispatch(s,{type:'SET_REORDER_RULE',id:'fruit',minimum:30,target:24}).ok,false);
 assert.equal(E.dispatch(s,{type:'SET_REORDER_RULE',id:'fruit',minimum:-1,target:18}).ok,false);
 assert.equal(E.dispatch(s,{type:'SET_REORDER_RULE',id:'drink',minimum:10,target:23.5}).ok,false);
 assert.equal(s.operations.reorder.fruit.minimum,12);
});
test('V50: trừ tiền dự phòng khi tính lô nhập',()=>{
 const s=newGame();
 assert.equal(E.dispatch(s,{type:'SET_CASH_RESERVE',amount:5000000}).ok,true);
 assert.equal(E.dispatch(s,{type:'SET_CASH_RESERVE',amount:-1}).ok,false);
 const forecast=E.operationsForecast(s);
 assert.ok(forecast.every(r=>r.orderCost<1000000));
 s.cash=5050000; // mô phỏng việc tiền mặt bị chi bởi mô-đun cũ: tạo mốc hợp lệ sau khi tải bản lưu
 s.operations.finance.baseBalance-=4950000;
 assert.ok(E.operationsForecast(s).every(r=>!r.canOrder));
});
test('V50: nhập hàng theo định mức không đặt thêm trùng đơn đang giao',()=>{
 const s=newGame();
 const out=E.dispatch(s,{type:'REPLENISH'});
 assert.equal(out.ok,true);
 const count=s.pending.length,oldCash=s.cash;
 assert.ok(count>=2);
 assert.equal(E.dispatch(s,{type:'REPLENISH'}).ok,false);
 assert.equal(s.cash,oldCash);assert.equal(s.pending.length,count);
 assert.equal(E.financeAudit(s).valid,true);
});
test('V50: hàng tươi nhập tối đa 24 sản phẩm mỗi lần dự báo',()=>{
 const s=newGame();
 E.dispatch(s,{type:'SET_REORDER_RULE',id:'fruit',minimum:45,target:96});
 assert.ok(E.operationsForecast(s).find(r=>r.id==='fruit').pack<=24);
});
test('V51: quy trình cân bằng làm NPC không ưu tiên bonus cố định',()=>{
 const s=newGame();assert.equal(E.dispatch(s,{type:'SET_SERVICE_STANDARD',standard:'balanced'}).ok,true);
 assert.equal(s.priority,'balanced');
 const restored=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(restored.priority,'balanced');
 assert.equal(E.dispatch(s,{type:'SET_SERVICE_STANDARD',standard:'x'}).ok,false);
});
test('V51: chỉ số nhân viên có giới hạn và tồn tại qua lưu game',()=>{
 const s=newGame();
 E.dispatch(s,{type:'ORDER',id:'drink',qty:24});
 for(let i=0;i<24;i++)E.advance(s,()=>.5);
 const reports=E.staffOperationsReport(s);
 assert.equal(reports.length,2);assert.ok(reports.every(r=>r.energy>=0&&r.energy<=100));
 assert.ok(reports.find(x=>x.id==='binh').restocked>=0);
 const loaded=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.deepEqual(E.staffOperationsReport(loaded).map(x=>x.restocked),reports.map(x=>x.restocked));
 assert.equal(E.financeAudit(loaded).valid,true);
});
test('V52: kiểm tra tồn kho và chứng từ luôn phản ánh tình trạng thực',()=>{
 const s=newGame();assert.equal(E.operationsIntegrity(s).valid,true);
 E.dispatch(s,{type:'ORDER',id:'milk',qty:24});
 assert.equal(E.operationsIntegrity(s).valid,true);
 s.pending[0].received=25;
 assert.equal(E.operationsIntegrity(s).valid,false);
 assert.match(E.operationsIntegrity(s).errors.join(' '),/nhiều hơn số đặt/);
});
test('V52: thông tin hóa đơn chỉ thống kê ngành thực bán',()=>{
 const s=newGame();
 s.receipts.push({day:1,items:['drink','drink','snack'],bill:50000});
 const rows=E.operationsForecast(s);
 assert.equal(rows.find(x=>x.id==='drink').receiptUnits,2);
 assert.equal(rows.find(x=>x.id==='snack').receiptUnits,1);
 assert.equal(rows.find(x=>x.id==='milk').receiptUnits,0);
});
test('V53: bản lưu V48 chưa có operations tự nâng cấp không mất tiến độ',()=>{
 const old=newGame();
 E.dispatch(old,{type:'ORDER',id:'drink',qty:12});
 old.name='Cửa hàng thử nghiệm';delete old.operations;
 const restored=E.normalizeSave(JSON.parse(JSON.stringify(old)));
 assert.equal(restored.name,'Cửa hàng thử nghiệm');
 assert.equal(restored.cash,old.cash);
 assert.equal(restored.pending.length,1);
 assert.equal(restored.operations.finance.openingCash,old.cash);
 assert.equal(E.financeAudit(restored).valid,true);
});
test('V53: không chấp nhận ghi sổ giao dịch có số tiền hoặc kiểu sai',()=>{
 const s=newGame();
 s.operations.finance.entries=[{seq:1,type:'X',delta:'abc'}, {seq:2,type:'Y',delta:0}];
 s.operations.finance.baseBalance=s.cash;
 const restored=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(restored.operations.finance.entries.length,1);
 assert.equal(E.financeAudit(restored).valid,true);
});
test('V54: mô phỏng 300 lượt sau nhập hàng không âm kho, sổ tiền khớp, NPC phục vụ',()=>{
 const s=newGame();
 E.dispatch(s,{type:'ORDER',id:'drink',qty:96});
 for(let i=0;i<25;i++)E.advance(s,()=>.5);
 assert.ok(s.stock.drink>0);
 E.dispatch(s,{type:'OPEN'});
 for(let i=0;i<300;i++)E.advance(s,()=>.5);
 assert.ok(s.stats.served>0);
 assert.equal(E.financeAudit(s).valid,true);
 assert.equal(E.operationsIntegrity(s).valid,true);
 for(const c of E.CATEGORIES){assert.ok(s.stock[c.id]>=0);assert.ok(s.warehouse[c.id]>=0);}
});
