/* V24: verify offline asset manifest and cache policy without an external service worker. */
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const ROOT=path.join(__dirname,'..');
test('PWA precache entries all exist in source bundle',()=>{
 const text=fs.readFileSync(path.join(ROOT,'sw.js'),'utf8');
 const match=text.match(/const ASSETS\s*=\s*\[([^\]]+)\]/);assert.ok(match);
 const assets=[...match[1].matchAll(/'([^']+)'/g)].map(x=>x[1]);
 for(const file of assets){if(file==='./')continue;assert.ok(fs.existsSync(path.join(ROOT,file)),`Missing ${file}`);}
 assert.ok(/cua-hang-tien-loi-mobile-v(?:70|80)\.0/.test(text));
});
test('Web manifest supports both mobile orientations',()=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'manifest.webmanifest'),'utf8'));
 assert.equal(manifest.orientation,'any');assert.equal(manifest.display,'standalone');
 for(const icon of manifest.icons)assert.ok(fs.existsSync(path.join(ROOT,icon.src)));
});
test('JavaScript sources do not require external web endpoints',()=>{
 for(const name of ['engine.js','scene.js','scene3d.js','app.js']){
  const code=fs.readFileSync(path.join(ROOT,'src',name),'utf8');
  assert.ok(!/import\s*\(\s*['"]https?:\/\//.test(code));
 }
});
