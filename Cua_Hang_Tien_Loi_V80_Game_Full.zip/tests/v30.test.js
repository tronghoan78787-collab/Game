/** V25–V30 acceptance: no network, deterministic business engine. */
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../src/expansion.js')&&require('../src/engine.js');
const tick=(s,n)=>{for(let i=0;i<n;i++)E.advance(s,()=>.48);};

test('V25 compatible first-launch economic contract',()=>{
 const s=E.createGame();assert.equal(s.cash,10000000);assert.equal(s.staff.length,2);
 assert.equal(E.activeCats(s).length,4);assert.deepEqual(s.staff.map(m=>m.role),['cashier','operator']);
 assert.equal(s.build,30);assert.equal(E.RELEASE_STAGE,30);
});
test('V25 initial category positions are six unique stable slots',()=>{
 const s=E.createGame();assert.equal(new Set(Object.values(s.layout.shelves)).size,6);
 for(const c of E.CATEGORIES)assert.deepEqual(E.categoryPos(s,c),E.SHELF_SLOTS[s.layout.shelves[c.id]]);
});
test('V26 new customers get behavior profiles and some regulars',()=>{
 const s=E.createGame();s.stock.drink=100;E.dispatch(s,{type:'OPEN'});tick(s,115);
 assert.ok(s.stats.visitors>=2);assert.ok(s.service.repeatVisits>=0);
 for(const c of s.customers)assert.equal(typeof c.profile,'string');
});
test('V27 hires require level 2 and charge 450k',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'HIRE'}).ok,false);
 s.level=2;assert.equal(E.dispatch(s,{type:'HIRE'}).ok,true);
 assert.equal(s.staff.length,3);assert.equal(s.cash,9550000);
 assert.equal(s.staff[2].name,'Linh');
});
test('V27 max four staff and no additional charges on failed hire',()=>{
 const s=E.createGame();s.level=3;
 assert.ok(E.dispatch(s,{type:'HIRE'}).ok);assert.ok(E.dispatch(s,{type:'HIRE'}).ok);
 const prior=s.cash;assert.equal(E.dispatch(s,{type:'HIRE'}).ok,false);
 assert.equal(s.cash,prior);assert.equal(s.staff.length,4);
});
test('V27 staff shift and traits are validated and persisted',()=>{
 const s=E.createGame();assert.ok(E.dispatch(s,{type:'SET_SHIFT',staffId:'binh',shift:'evening'}).ok);
 assert.ok(E.dispatch(s,{type:'SET_TRAIT',staffId:'binh',trait:'patient'}).ok);
 assert.equal(E.dispatch(s,{type:'SET_SHIFT',staffId:'an',shift:'never'}).ok,false);
 const loaded=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(loaded.staff[1].shift,'evening');assert.equal(loaded.staff[1].trait,'patient');
});
test('V27 staff hired continue to work and wages include extras',()=>{
 const s=E.createGame();s.level=3;E.dispatch(s,{type:'HIRE'});s.staff[2].role='operator';
 s.minutes=1318;tick(s,1);
 assert.equal(s.history[0].wages,285000);assert.equal(s.staff.length,3);
});
test('V28 cannot rearrange shelves while store open',()=>{
 const s=E.createGame();s.stock.drink=5;E.dispatch(s,{type:'OPEN'});
 assert.equal(E.dispatch(s,{type:'MOVE_SHELF',id:'drink',slot:1}).ok,false);
 assert.equal(s.layout.shelves.drink,0);
});
test('V28 shelf swapping is atomic and no duplicate slots',()=>{
 const s=E.createGame();assert.ok(E.dispatch(s,{type:'MOVE_SHELF',id:'drink',slot:1}).ok);
 assert.equal(s.layout.shelves.drink,1);assert.equal(s.layout.shelves.snack,0);
 assert.equal(new Set(Object.values(s.layout.shelves)).size,6);
});
test('V28 cannot move starter shelves into locked expansion area',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'MOVE_SHELF',id:'drink',slot:4}).ok,false);
 assert.equal(s.layout.shelves.drink,0);
});
test('V28 decor must be owned and positioned at unique slots',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'PLACE_DECOR',id:'flower',slot:2}).ok,false);
 assert.ok(E.dispatch(s,{type:'BUY_DECOR',id:'plant'}).ok);
 assert.equal(s.layout.decor.plant,0);
 assert.ok(E.dispatch(s,{type:'BUY_DECOR',id:'poster'}).ok);
 assert.ok(E.dispatch(s,{type:'PLACE_DECOR',id:'plant',slot:3}).ok);
 assert.equal(E.dispatch(s,{type:'PLACE_DECOR',id:'poster',slot:3}).ok,false);
});
test('V28 malicious saved layout is normalized without overlapping slots',()=>{
 const s=E.createGame();s.layout.shelves.drink=1;s.layout.shelves.snack=1;
 s.layout.decor.plant=20;s.layout.decor.poster=1;
 const loaded=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(new Set(Object.values(loaded.layout.shelves)).size,6);
 assert.deepEqual(loaded.layout.decor,{});
});
test('V29 story chapters require sequence and actual targets',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'CLAIM_STORY',id:'opening'}).ok,false);
 s.stats.ordered=24;s.stats.restocked=16;s.everOpened=true;
 assert.ok(E.dispatch(s,{type:'CLAIM_STORY',id:'opening'}).ok);
 assert.equal(E.dispatch(s,{type:'CLAIM_STORY',id:'opening'}).ok,false);
 assert.equal(E.dispatch(s,{type:'CLAIM_STORY',id:'growth'}).ok,false);
});
test('V29 event and streak update at day transition',()=>{
 const s=E.createGame();s.day=2;s.minutes=1318;s.today.served=4;s.today.revenue=500000;s.today.cogs=100000;
 tick(s,1);assert.equal(s.day,3);assert.equal(s.dailyStreak,1);
 assert.ok(s.activeEvent?.name);assert.equal(s.daysPlayed,1);
});
test('V30 1000-tick simulation with shuffled shelves does not create negative inventory',()=>{
 const s=E.createGame();s.level=3;s.storeLevel=2;E.dispatch(s,{type:'MOVE_SHELF',id:'drink',slot:1});
 for(const c of E.activeCats(s)){s.stock[c.id]=18;s.warehouse[c.id]=20;}
 E.dispatch(s,{type:'OPEN'});tick(s,1000);
 for(const c of E.activeCats(s)){assert.ok(s.stock[c.id]>=0);assert.ok(s.warehouse[c.id]>=0);}
 assert.ok(s.stats.served>0);assert.ok(s.cash>=0);
});
