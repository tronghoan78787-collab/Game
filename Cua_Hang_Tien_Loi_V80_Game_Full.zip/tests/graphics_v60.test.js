// V56-V60 authored visual assets and mobile rendering integration tests.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.join(__dirname,'..');
const scene=fs.readFileSync(path.join(root,'src/scene.js'),'utf8');
const app=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
const engine=fs.readFileSync(path.join(root,'src/engine.js'),'utf8');
const service=fs.readFileSync(path.join(root,'sw.js'),'utf8');
test('V56 four starting categories have image states for empty, low and full shelves',()=>{
  for(const id of ['drink','snack','milk','fruit'])for(const state of ['empty','low','full']){
    const file=`assets/art/${id}_${state}.png`;
    assert.ok(fs.existsSync(path.join(root,file)),file);
    assert.ok(service.includes(file),file+' not cached offline');
  }
});
test('V56 cashier and 2 initial staff animated sprites are bundled',()=>{
  for(const file of ['checkout.png','an_idle_happy.png','an_wave_happy.png','an_scan_happy.png','binh_work_happy.png','binh_idle_sad.png'])
    assert.ok(fs.statSync(path.join(root,'assets/art',file)).size>1000,file);
});
test('V57 shelf sprites are selected from actual stock, never invented quantity',()=>{
  assert.match(scene,/qty<=0\?'empty'/);
  assert.match(scene,/qty<max\*\.37\?'low'/);
  assert.match(scene,/qty\+' \/ '\+max\+' SP'/);
});
test('V58 illustration mode is the default and WebGL remains optional',()=>{
  assert.match(engine,/renderMode:'illustrated'/);
  assert.match(app,/S\.settings\.renderMode==='3d'/);
  assert.match(app,/window\.StoreScene\(/);
  assert.match(engine,/\['illustrated','3d'\]/);
});
test('V59 supports safe sprite-loading fallback and low battery settings',()=>{
  assert.match(scene,/img\.complete/);
  assert.match(scene,/if\(this\.premiumRack\(/);
  assert.match(scene,/settings\?\.quality==='low'/);
  assert.match(scene,/reducedMotion/);
});
test('V60 mobile screen keeps real touchable HUD, no fake image overlay',()=>{
  const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.match(html,/data-panel="order"/);
  assert.match(html,/data-panel="staff"/);
  assert.match(html,/id="categoryQuick"/);
  assert.match(html,/id="scene"/);
  assert.doesNotMatch(html,/position:\s*fixed[^\n]*pointer-events:\s*none[^\n]*background-image/);
});
test('V60 performance settings validate target frame rate and lighting',()=>{
 assert.match(engine,/fpsTarget:30/);assert.match(engine,/\[20,30,45,60\]/);
 assert.match(engine,/lighting:true/);
 assert.match(scene,/1000\/fps/);assert.match(scene,/lighting!==false/);
 assert.match(app,/id="fpsTarget"/);assert.match(app,/data-action="lighting"/);
});
