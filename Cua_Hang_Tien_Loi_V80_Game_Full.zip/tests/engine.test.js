/* Automated deterministic regression tests for economy, NPC simulation and progression. */
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../src/engine.js');
const constant=()=>.5;
function go(state,n){for(let i=0;i<n;i++)E.advance(state,constant);}
test('New player starts exactly 10m, 4 shelves, 2 employees and no starting items',()=>{
 const s=E.createGame();assert.equal(s.cash,10000000);assert.equal(E.activeCats(s).length,4);
 assert.equal(s.staff.length,2);assert.equal(E.stockTotal(s,'stock'),0);assert.equal(E.stockTotal(s,'warehouse'),0);
 assert.equal(s.staff[0].role,'cashier');assert.equal(s.staff[1].role,'operator');
});
test('Store cannot open before shelves are stocked',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'OPEN'}).ok,false);
});
test('Orders deduct cash and require a receiving operator and stocking',()=>{
 const s=E.createGame();const res=E.dispatch(s,{type:'ORDER',id:'drink',qty:24});assert.equal(res.ok,true);
 assert.equal(s.cash,10000000-24*8000);go(s,30);
 assert.equal(s.pending.length,0);assert.ok(s.stock.drink>0);
 assert.equal(s.stats.restocked,24);assert.equal(s.stock.drink+s.warehouse.drink,24);
});
test('Cashier can sell purchased goods, update accounting and gain XP',()=>{
 const s=E.createGame();E.dispatch(s,{type:'ORDER',id:'drink',qty:96});go(s,36);
 assert.equal(E.dispatch(s,{type:'OPEN'}).ok,true);go(s,90);
 assert.ok(s.stats.visitors>0);assert.ok(s.stats.served>0,`served ${s.stats.served}; visitors ${s.stats.visitors}`);
 assert.ok(s.stats.revenue>0);assert.equal(s.stats.revenue>=s.stats.cogs,true);
});
test('No negative cash for spending and warehouse cannot exceed capacity',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'ORDER',id:'milk',qty:96}).ok,true);
 assert.equal(E.dispatch(s,{type:'ORDER',id:'fruit',qty:96}).ok,false);
 assert.equal(E.dispatch(s,{type:'BUY_EQUIPMENT',id:'storage'}).ok,true);
 assert.equal(E.dispatch(s,{type:'ORDER',id:'fruit',qty:96}).ok,true);
 assert.ok(s.cash>=0);
});
test('Role selection controls delivery and stocking; resting recovers energy',()=>{
 const s=E.createGame();E.dispatch(s,{type:'SET_ROLE',staffId:'binh',role:'rest'});
 E.dispatch(s,{type:'ORDER',id:'snack',qty:24});go(s,20);
 assert.equal(s.stock.snack,0);assert.equal(s.warehouse.snack,0);
 assert.equal(s.pending[0].arrived,true);
 E.dispatch(s,{type:'SET_ROLE',staffId:'binh',role:'operator'});go(s,20);
 assert.equal(s.pending.length,0);assert.ok(s.stock.snack>0);
});
test('Promotions alter selling price and persist for two days',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'SET_PROMO',id:'milk',rate:15}).ok,true);
 assert.equal(E.activeDiscount(s,'milk'),15);
 assert.equal(E.dispatch(s,{type:'SET_PROMO',id:'milk',rate:30}).ok,false);
});
test('Equipment and decor are once-only and affect capacities',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'BUY_EQUIPMENT',id:'cold'}).ok,true);
 assert.equal(E.shelfCapacity(s,'drink'),40);assert.equal(E.dispatch(s,{type:'BUY_EQUIPMENT',id:'cold'}).ok,false);
 const before=s.reputation;assert.equal(E.dispatch(s,{type:'BUY_DECOR',id:'plant'}).ok,true);assert.ok(s.reputation>before);
});
test('Mission rewards cannot be claimed twice',()=>{
 const s=E.createGame();E.dispatch(s,{type:'ORDER',id:'drink',qty:24});const before=s.cash;
 assert.equal(E.dispatch(s,{type:'CLAIM_MISSION',id:'order24'}).ok,true);
 assert.equal(s.cash,before+90000);
 assert.equal(E.dispatch(s,{type:'CLAIM_MISSION',id:'order24'}).ok,false);
});
test('Day close posts wage and utility costs exactly once',()=>{
 const s=E.createGame();go(s,420);
 assert.equal(s.day,2);assert.equal(s.stats.wages,190000);assert.equal(s.stats.utilities,42000);
 assert.equal(s.history.length,1);assert.equal(s.history[0].net,-232000);
});
test('Expansion requires level two and funds; adds two categories',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'EXPAND'}).ok,false);
 s.level=2;assert.equal(E.dispatch(s,{type:'EXPAND'}).ok,true);
 assert.equal(E.activeCats(s).length,6);assert.equal(E.dispatch(s,{type:'EXPAND'}).ok,false);
});
test('Invalid or old saves start fresh, valid save keeps settings',()=>{
 assert.equal(E.normalizeSave({version:11,cash:99}).cash,10000000);
 const a=E.createGame();a.cash=9123;a.settings.sound=true;
 const b=E.normalizeSave(JSON.parse(JSON.stringify(a)));
 assert.equal(b.cash,9123);assert.equal(b.settings.sound,true);
});
test('Customer emotions react to waiting and missing products',()=>{
 const s=E.createGame();s.customers.push({id:'test',cat:'drink',x:426,y:300,stage:'needHelp',patience:10,mood:70,wait:0,bag:[],shoppingChance:.1});
 E.dispatch(s,{type:'SET_ROLE',staffId:'binh',role:'rest'});
 go(s,1);assert.ok(s.customers[0].mood<70);
 assert.equal(s.customers[0].patience,9);
});
