/* V13-V16 regression: WebGL geometry and V15 stock aging. */
const test=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
const E=require('../src/engine.js');
test('Inventory audit can only be performed once per game day',()=>{
 const s=E.createGame();assert.equal(E.dispatch(s,{type:'AUDIT'}).ok,true);assert.equal(E.dispatch(s,{type:'AUDIT'}).ok,false);
});
test('Fresh stock expires on due day and spoilage is recorded',()=>{
 const s=E.createGame();s.stock.fruit=6;s.warehouse.fruit=4;s.freshDay.fruit=1;
 for(let i=0;i<4*420;i++)E.advance(s,()=>.5);
 assert.equal(s.stock.fruit+s.warehouse.fruit,0);assert.equal(s.stats.wasteCost,10*11000);
 assert.equal(s.history.reduce((n,d)=>n+(d.wasteCost||0),0)+(s.today.wasteCost||0),110000);
});
test('Fresh stock does not expire before its modeled date',()=>{
 const s=E.createGame();s.stock.milk=12;s.freshDay.milk=1;
 for(let i=0;i<3*420;i++)E.advance(s,()=>.5);
 assert.equal(s.stock.milk,12);
});
test('3D renderer builds triangle meshes, clickable shelf positions and NPCs',()=>{
 const gl={VERTEX_SHADER:1,FRAGMENT_SHADER:2,COMPILE_STATUS:3,LINK_STATUS:4,ARRAY_BUFFER:5,DYNAMIC_DRAW:6,FLOAT:7,TRIANGLES:8,COLOR_BUFFER_BIT:9,DEPTH_BUFFER_BIT:10,DEPTH_TEST:11,
 createShader:()=>({}),shaderSource(){},compileShader(){},getShaderParameter:()=>true,createProgram:()=>({}),attachShader(){},linkProgram(){},getProgramParameter:()=>true,
 getAttribLocation:()=>0,getUniformLocation:()=>({}),createBuffer:()=>({}),viewport(){},clearColor(){},clear(){},enable(){},useProgram(){},bindBuffer(){},bufferData(t,d){this.bytes=d.length;},enableVertexAttribArray(){},vertexAttribPointer(){},uniformMatrix4fv(){},drawArrays(t,first,n){this.count=n;},deleteBuffer(){}};
 const layer={className:'',innerHTML:'',remove(){}};
 const canvas={clientWidth:844,clientHeight:390,parentElement:{appendChild(){}},getContext:()=>gl,addEventListener(){},setPointerCapture(){},getBoundingClientRect:()=>({left:0,top:0,right:844,width:844,height:390})};
 const window={StoreEngine:E,devicePixelRatio:1,addEventListener(){},removeEventListener(){},dispatchEvent(){}};
 const context={window,document:{createElement:()=>layer},devicePixelRatio:1,requestAnimationFrame:()=>1,cancelAnimationFrame(){},matchMedia:()=>({matches:false}),console};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../src/scene3d.js'),'utf8'),context);
 const s=E.createGame(),renderer=new window.StoreScene3D(canvas,()=>s,()=>{});
 renderer.render(s,0);assert.ok(gl.count>1000);assert.equal(renderer.points.filter(x=>x.kind==='shelf').length,4);
 assert.ok(layer.innerHTML.includes('Đồ uống'));renderer.rotateCamera();renderer.adjustZoom(.2);renderer.render(s,50);assert.ok(gl.count>1000);renderer.stop();
});
