from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
p=Path('/mnt/data/CUA_HANG_TIEN_LOI_V70_CHOI_NGAY.html')
with sync_playwright() as w:
 browser=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for name,width,height in [('iphone_portrait',390,844),('iphone_landscape',844,390),('small_landscape',667,375),('iphone_se',375,667),('small_portrait',320,568),('iphone_plus',932,430)]:
  context=browser.new_context(viewport={'width':width,'height':height},is_mobile=True,has_touch=True,device_scale_factor=2)
  context.add_init_script('window.__CHIBI_QA__=true;')
  page=context.new_page();errs=[]; page.on('pageerror',lambda e:errs.append(str(e)))
  page.goto('about:blank');page.set_content(p.read_text(),wait_until='load',timeout=30000)
  page.wait_for_function('window.ConvenienceGame&&window.ConvenienceGame.ready',timeout=15000)
  page.evaluate('()=>window.ConvenienceGame.ready')
  page.wait_for_timeout(350)
  state=page.evaluate('()=>window.ConvenienceGame.getState()'); assert state['cash']==10000000,state['cash']
  page.locator('.mobile-nav-button[data-panel="store"]').tap(timeout=10000)
  starter=page.locator('[data-action="starterPack"]'); assert starter.count()==1,starter.count()
  starter.tap();state=page.evaluate('()=>window.ConvenienceGame.getState()')
  assert len(state['pending'])==4,len(state['pending'])
  assert state['cash']==9484000,state['cash']
  page.locator('.game-modal [data-action="close"]').tap()
  page.evaluate('()=>window.ConvenienceGame.advanceForTest(48)')
  state=page.evaluate('()=>window.ConvenienceGame.getState()')
  print(name,'ordered',state['stats']['ordered'],'stock',sum(state['stock'].values()),'warehouse',sum(state['warehouse'].values()),'pending',len(state['pending']))
  if sum(state['stock'].values())>0:
   page.locator('#openButton').tap()
   st=page.evaluate('()=>window.ConvenienceGame.getState()')
   assert st['opened'],st['opened']
  page.locator('.mobile-nav-button[data-panel="staff"]').tap()
  assert page.locator('.game-modal [data-role-staff]').count()>=2
  page.locator('.game-modal [data-action="close"]').tap()
  page.locator('.mobile-nav-button[data-panel="more"]').tap()
  assert page.locator('.mobile-more-grid button').count()>8
  page.screenshot(path=f'/mnt/data/V70_{name}.png')
  print(name,'errors',errs[:2], 'render',page.evaluate('()=>window.ConvenienceGame.renderer()'))
  assert not errs,errs
  context.close()
 browser.close()
