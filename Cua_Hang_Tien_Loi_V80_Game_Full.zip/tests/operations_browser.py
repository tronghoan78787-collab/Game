"""Chromium smoke test without network or local file URL permissions.
Tests the same standalone HTML as user delivery, using page.set_content().
Does NOT represent Safari/iPhone hardware QA.
"""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
standalone=R.parent/'cua_hang_tien_loi_ios_V54_choi_ngay.html'
html=standalone.read_text(encoding='utf-8')
results=[]
for w,h,label in [(844,390,'iphone_landscape'),(390,844,'iphone_portrait'),(1280,720,'desktop')]:
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
        page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<900,has_touch=w<900)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto('about:blank')
        page.evaluate('window.__CHIBI_QA__=true;')
        page.set_content(html,wait_until='load',timeout=35000)
        page.evaluate('window.ConvenienceGame.ready')
        page.locator('.bottom-nav [data-panel="operations"]').click(force=True)
        assert 'Trung tâm vận hành' in page.locator('.modal-heading').inner_text()
        assert page.locator('[data-rule-min]').count()==4
        page.locator('[data-reserve]').select_option('500000')
        assert page.evaluate('window.ConvenienceGame.getState().operations.reserveCash')==500000
        page.locator('[data-rule-min="fruit"]').select_option('12')
        assert page.evaluate('window.ConvenienceGame.getState().operations.reorder.fruit.minimum')==12
        page.locator('[data-service-standard="balanced"]').click(force=True)
        assert page.evaluate('window.ConvenienceGame.getState().priority')=='balanced'
        page.locator('[data-action="replenishAll"]').click(force=True)
        pending=page.evaluate('window.ConvenienceGame.getState().pending.length')
        assert pending>=1
        assert page.evaluate('window.ConvenienceGame.engine.financeAudit(window.ConvenienceGame.getState()).valid')
        page.locator('[data-panel="finance"]').click(force=True)
        assert 'Sổ dòng tiền' in page.locator('.modal-heading').inner_text()
        assert page.locator('.receipt-card').count()>=1
        page.screenshot(path=str(R/f'QA_V54_{label}.png'),full_page=False)
        page.locator('.close').click(force=True)
        page.evaluate("window.ConvenienceGame.advanceForTest?.(30)")
        # First delivered items are already on shelves after operator restock.
        state=page.evaluate('window.ConvenienceGame.getState()')
        assert sum(state['stock'].values())>0
        opened=page.evaluate("window.ConvenienceGame.dispatch({type:'OPEN'})")
        assert opened['ok']
        page.evaluate('window.ConvenienceGame.advanceForTest?.(210)')
        if label=='iphone_landscape': page.screenshot(path=str(R/'GAMEPLAY_V54.png'),full_page=False)
        state=page.evaluate('window.ConvenienceGame.getState()')
        assert state['stats']['served']>0
        report=page.evaluate('window.ConvenienceGame.engine.operationsIntegrity(window.ConvenienceGame.getState())')
        assert report['valid'],report
        assert not errors,errors
        results.append({'viewport':f'{w}x{h}','label':label,'served':state['stats']['served'],
             'revenue':state['stats']['revenue'],'orders':pending,'errors':errors,
             'financeOk':True,'inventoryOk':True})
        browser.close()
(R/'QA_V54_BROWSER.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
