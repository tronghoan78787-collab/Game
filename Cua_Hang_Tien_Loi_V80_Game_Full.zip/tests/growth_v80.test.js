'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const base=path.join(__dirname,'..');
const E=require('../src/engine.js');
globalThis.STORE_RELEASE_STAGE=30;
require('../src/expansion.js');
require('../src/director.js');
require('../src/operations.js');
globalThis.STORE_COMMERCE_STAGE=75;
require('../src/commerce.js');
globalThis.STORE_GROWTH_STAGE=80;
require('../src/growth_v80.js');
const wealthy=(lev=8)=>{const s=E.createGame();s.level=lev;s.cash=35000000;return s;};
const upgrade=s=>E.dispatch(s,{type:'EXPAND'});

test('V80 begins with ten million, four sections, two workers and 64 square metres',()=>{
 const s=E.createGame();assert.equal(s.cash,10000000);assert.equal(s.staff.length,2);assert.equal(s.storeLevel,1);assert.equal(E.activeCats(s).length,4);assert.equal(E.growthArea(s),64);assert.equal(E.growthStaffLimit(s),2);
});
test('player cannot hire before expanding area',()=>{
 const s=wealthy();assert.equal(E.dispatch(s,{type:'HIRE'}).ok,false);assert.equal(s.staff.length,2);
});
test('level two unlocks original expansion for 2.6m',()=>{
 const s=wealthy(1);assert.equal(upgrade(s).ok,false);s.level=2;const money=s.cash;assert.equal(upgrade(s).ok,true);
 assert.equal(s.cash,money-2600000);assert.equal(s.storeLevel,2);assert.equal(E.growthArea(s),96);assert.equal(E.activeCats(s).length,6);
});
test('cannot build while open or spend more than cash',()=>{
 const s=wealthy();s.opened=true;assert.equal(upgrade(s).ok,false);s.opened=false;s.cash=1;assert.equal(upgrade(s).ok,false);assert.equal(s.storeLevel,1);
});
test('tier two allows Linh and Minh, not more',()=>{
 const s=wealthy();upgrade(s);
 assert.equal(E.dispatch(s,{type:'HIRE'}).ok,true);assert.equal(E.dispatch(s,{type:'HIRE'}).ok,true);
 assert.deepEqual(s.staff.map(x=>x.id),['an','binh','linh','minh']);assert.equal(E.dispatch(s,{type:'HIRE'}).ok,false);
});
test('tier three builds two new retail sections',()=>{
 const s=wealthy(2);upgrade(s);assert.equal(upgrade(s).ok,false);s.level=4;
 const cash=s.cash;assert.equal(upgrade(s).ok,true);assert.equal(s.cash,cash-4800000);
 assert.equal(s.storeLevel,3);assert.equal(E.growthArea(s),144);
 assert.deepEqual(E.activeCats(s).slice(-2).map(x=>x.id),['personal','home']);
 assert.equal(E.warehouseCapacity(s),500);assert.equal(E.shelfCapacity(s,'personal'),38);
});
test('tier three allows six people and rejects seventh',()=>{
 const s=wealthy();upgrade(s);upgrade(s);for(let i=0;i<4;i++)assert.equal(E.dispatch(s,{type:'HIRE'}).ok,true);
 assert.deepEqual(s.staff.map(x=>x.id),['an','binh','linh','minh','thao','phuc']);
 assert.equal(E.dispatch(s,{type:'HIRE'}).ok,false);assert.equal(s.stats.hires,4);
});
test('tier four unlocks ten categories and eight workers',()=>{
 const s=wealthy();upgrade(s);upgrade(s);const cash=s.cash;assert.equal(upgrade(s).ok,true);
 assert.equal(s.cash,cash-8200000);assert.equal(s.storeLevel,4);assert.equal(E.growthArea(s),192);
 assert.deepEqual(E.activeCats(s).slice(-2).map(c=>c.id),['coffee','ready']);
 for(let i=0;i<6;i++)assert.equal(E.dispatch(s,{type:'HIRE'}).ok,true);
 assert.equal(s.staff.length,8);assert.equal(E.dispatch(s,{type:'HIRE'}).ok,false);
 assert.equal(E.warehouseCapacity(s),760);assert.equal(E.shelfCapacity(s,'coffee'),44);
});
test('no extra expansion after four, leaves money untouched',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);const cash=s.cash;
 assert.equal(upgrade(s).ok,false);assert.equal(s.cash,cash);
});
test('previous V75 saves survive migration unchanged',()=>{
 const old=E.createGame();old.storeLevel=2;old.cash=1234567;old.staff.push({id:'linh',name:'Linh',role:'operator',mood:71,energy:85,skill:2,experience:5,task:'Lên kệ',x:330,y:300,bubble:''});
 const after=E.normalizeSave(JSON.parse(JSON.stringify(old)));
 assert.equal(after.cash,1234567);assert.equal(after.staff.length,3);assert.equal(after.storeLevel,2);assert.equal(after.stats.served,old.stats.served);
});
test('eight employees survive serialization/normalization',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 for(let i=0;i<6;i++)E.dispatch(s,{type:'HIRE'});
 s.staff[7].role='cashier';s.staff[7].skill=3;
 const restored=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(restored.staff.length,8);assert.equal(restored.staff[7].id,'tu');assert.equal(restored.staff[7].role,'cashier');assert.equal(restored.staff[7].skill,3);
 assert.equal(restored.storeLevel,4);assert.equal(restored.growth.records.length,2);
});
test('invalid backup does not yield free/unexpected employees',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 s.staff=[{id:'intruder',name:'hack',role:'operator'},...Array.from({length:20},()=>({id:'fake'}))];
 const recovered=E.normalizeSave(s);assert.equal(recovered.staff.length,2);assert.ok(recovered.staff.some(m=>m.id==='an'));
});
test('unique positions remain valid for 10 unlocked shelves',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 const slots=E.activeCats(s).map(c=>s.layout.shelves[c.id]);assert.equal(slots.length,10);assert.equal(new Set(slots).size,10);
 assert.ok(slots.every(n=>Number.isInteger(n)&&n>=0&&n<10));
});
test('new shelf can be swapped with existing shelf when closed',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 const a=s.layout.shelves.personal,b=s.layout.shelves.snack;
 assert.equal(E.dispatch(s,{type:'MOVE_SHELF',id:'personal',slot:b}).ok,true);
 assert.equal(s.layout.shelves.personal,b);assert.equal(s.layout.shelves.snack,a);
 s.opened=true;assert.equal(E.dispatch(s,{type:'MOVE_SHELF',id:'personal',slot:a}).ok,false);
});
test('new categories can be ordered and stocked without negative inventory',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 for(const id of ['personal','home','coffee','ready'])assert.equal(E.dispatch(s,{type:'ORDER',id,qty:12}).ok,true);
 for(let n=0;n<65;n++)E.advance(s,()=>.65);
 for(const id of ['personal','home','coffee','ready']){
  assert.ok(s.stock[id]>=0);assert.ok(s.warehouse[id]>=0);
  assert.ok(s.pending.every(p=>p.cat!==id||p.received<=p.qty));
 }
});
test('completed expansion and hires register mission rewards once only',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 for(let i=0;i<4;i++)E.dispatch(s,{type:'HIRE'});
 assert.equal(E.dispatch(s,{type:'CLAIM_MISSION',id:'area3'}).ok,true);
 assert.equal(E.dispatch(s,{type:'CLAIM_MISSION',id:'area3'}).ok,false);
 assert.equal(E.dispatch(s,{type:'CLAIM_MISSION',id:'team4'}).ok,true);
});
test('save migration repairs duplicate shelf locations for unlocked categories',()=>{
 const s=wealthy();upgrade(s);upgrade(s);upgrade(s);
 for(const c of E.CATEGORIES)s.layout.shelves[c.id]=0;
 const x=E.normalizeSave(JSON.parse(JSON.stringify(s)));
 assert.equal(new Set(Object.values(x.layout.shelves)).size,10);
});
test('new assets and source files exist',()=>{
 for(const id of ['personal','home','coffee','ready'])for(const fill of ['empty','low','full'])assert.ok(fs.existsSync(path.join(base,'assets','art',id+'_'+fill+'.png')));
 for(const id of ['thao','phuc','ha','tu'])assert.ok(fs.existsSync(path.join(base,'assets','avatars',id+'.svg')));
});

test('cash ledger reconciles all three builds and six hires',()=>{
 const s=wealthy();s.operations.finance.baseBalance+=(35000000-10000000);s.operations.finance.openingCash=35000000;for(let i=0;i<3;i++)assert.equal(upgrade(s).ok,true);for(let i=0;i<6;i++)assert.equal(E.dispatch(s,{type:'HIRE'}).ok,true);
 const f=E.financeAudit(s);assert.equal(f.valid,true,JSON.stringify(f));assert.equal(E.operationsIntegrity(s).valid,true);
});
