# Báo cáo kiểm thử V70 (iOS-first web game)

## Phạm vi kiểm thử thực hiện
- `node --test tests/*.test.js` trong mã nguồn V70: **143/143** đạt (sau cập nhật các kỳ vọng tên phiên bản PWA từ V65 sang V70; không bỏ bài test nghiệp vụ).
- Test cảm ứng Chromium Android/iPhone-sized Playwright: **6/6** cấu hình có thể chạm các nút quan trọng, không có lỗi JS được ghi nhận.
- Kích thước: 390×844; 844×390; 667×375; 375×667; 320×568; 932×430.
- Luồng: tạo cửa hàng mới với vốn 10.000.000đ, mở Cửa hàng, đặt gói 4 kệ 48 sản phẩm (516.000đ), Bình nhận và bổ sung hàng sau mô phỏng 48 nhịp, khai trương, mở bảng Nhân viên, mở menu Thêm. Tiền còn 9.484.000đ ngay sau đặt hàng.
- Test bấm dùng `.tap()` với cấu hình `has_touch=True`, không dùng click ép vào nút.
- Đã kiểm tra tệp Lite không có script CSS/JS tải ngoài; ảnh sprite dùng data URI WebP.
- Gói ZIP tạo bằng deflate, có kiểm tra CRC và đường dẫn.

## Chưa kiểm chứng
- Trình duyệt Chromium trong môi trường này **chặn localhost** (`ERR_BLOCKED_BY_ADMINISTRATOR`) nên chưa xác minh hành vi Service Worker/đồng bộ lưu game qua *tải lại cùng URL HTTP*.
- Chưa có kiểm thử Safari/WebKit trên iPhone vật lý, chưa có tên miền HTTPS, chưa chạy đo FPS 30 phút trên thiết bị thật.
- WebGL/GLB không được chứng nhận trên GPU iOS, default là Canvas 2.5D.
- Đăng tải App Store/TestFlight cần Apple Developer/Xcode và ký ứng dụng.

## Mức sẵn sàng
Bản **beta web dành cho iPhone**, sử dụng được trong Chromium mô phỏng. Cần kiểm thử HTTP(S), lưu/khôi phục, toàn bộ chu kỳ bán hàng trên Safari thật trước khi gọi là phát hành thương mại.
