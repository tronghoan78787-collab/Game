# Giai đoạn V66–V70

**Giả định:** Ưu tiên truy cập và chạm được trên iPhone, không mở rộng gameplay vô hạn; giữ lõi mô phỏng V65.

- **V66 – First Play:** một lần nhập 48 sản phẩm cho bốn ngành hàng và nút cảm ứng lớn, bỏ chuyển động nút Khai trương gây khó nhấn.
- **V67 – Lite Runtime:** gom CSS, JS và 80 ảnh WebP thu gọn vào `index.html`, cắt 1,48 MB dữ liệu tam giác 3D khỏi bản Lite.
- **V68 – Save & Recovery UX:** cảnh báo mở `file://`; duy trì localStorage + IndexedDB, tải file sao lưu JSON để chuyển thiết bị/miền.
- **V69 – Hosting & PWA:** website có `index.html` Lite mặc định, `advanced.html` 3D thử nghiệm và service worker versioned.
- **V70 – Regression & QA:** chạy hồi quy Node, 6 kích thước touch Chromium, tạo các gói riêng và thư viện 80 WebP cùng 18 GLB nguồn.

**Chưa có phát hành chính thức:** không xác minh iPhone vật lý hoặc triển khai HTTPS. Không thể tự động triển khai nếu chưa kết nối hosting.
