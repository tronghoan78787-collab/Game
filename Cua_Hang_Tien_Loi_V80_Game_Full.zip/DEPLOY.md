# Hướng dẫn xuất bản website iOS trên HTTPS

**Giả định:** game là web/PWA offline-first, không có backend hoặc tài khoản đám mây. App Store là một đường phát hành tùy chọn, cần Xcode và Apple Developer.

## Phương án 1 — Netlify Drop (miễn phí trong hạn mức)

1. Giải nén gói `cua_hang_tien_loi_ios_V48_website.zip` vào thư mục máy tính.
2. Vào trang Netlify, đăng nhập tài khoản của bạn rồi chọn triển khai website tĩnh thủ công (Deploy manually / Drop).
3. Thả nội dung thư mục chứa `index.html`, `sw.js`, `src/`, `assets/`, `manifest.webmanifest`, `netlify.toml` vào giao diện triển khai.
4. Sau khi Netlify cung cấp URL `https://...`, mở bằng Safari trên iPhone, kiểm tra app và khả năng lưu game. Có thể đặt tên miền riêng sau đó.

## Phương án 2 — GitHub Pages

1. Tạo repository chứa **nội dung** gói website, không chỉ đẩy file ZIP.
2. Trong GitHub > Settings > Pages, chọn GitHub Actions. Workflow `.github/workflows/deploy.yml` sẽ kiểm thử `npm test` trước khi publish.
3. Chờ triển khai hoàn thành rồi vào HTTPS URL do GitHub cung cấp.

## iPhone PWA

- Mở game bằng **Safari**, dùng menu Chia sẻ → Thêm vào Màn hình chính.
- Chạy game từ biểu tượng mới. Màn hình xoay ngang có không gian tốt nhất; nếu cầm dọc, giao diện vẫn tự xoay trong viewport.
- Khi có mạng, đợi game tải hết trước khi kiểm thử chế độ máy bay.
- Vào game → Cài đặt → Xuất bản lưu JSON rồi lưu trong Files/iCloud Drive. Đừng xoá dữ liệu website trước khi làm bước này.
- Bản PWA không có chức năng đồng bộ tiến độ sang các thiết bị khác. Dữ liệu chỉ được lưu trong trình duyệt/cài đặt đang dùng.

## Kiểm tra trước khi đưa người khác chơi

- Mở `health.json`: trường `deployed` trong bộ nguồn là `false` **cho tới khi thực sự xuất bản**.
- Chạy `npm test` và `python3 tests/ios_browser.py` ở môi trường có Chromium.
- Cần thử iPhone thật với Safari: đặt hàng, khai trương, bán hàng, đóng/mở app, cài PWA, chế độ máy bay, âm thanh, đổi hướng và tính đúng tồn kho.
- Chỉ công bố bản chính thức khi đã có URL thực tế, thiết bị đạt mục tiêu 30 FPS, kiểm thử 60 phút và dữ liệu lưu khôi phục chính xác.

**Chưa thực hiện trong phiên làm việc này:** không có tài khoản hosting được cấp quyền nên không thể đưa lên URL công khai; không có thiết bị iPhone vật lý hoặc máy Mac/Xcode để đóng IPA/kiểm thử WKWebView.
