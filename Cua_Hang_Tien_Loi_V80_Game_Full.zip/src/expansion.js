/*
 * CỬA HÀNG TIỆN LỢI — V25–V30 MODULE
 * Giả định: chơi đơn, không mua hàng thật. Bản đồ bố trí có sáu vị trí kệ
 * và tám điểm trang trí an toàn; không cho chắn đường đi hoặc cửa thoát.
 * AI vẫn là mô phỏng dựa trên trạng thái và ưu tiên, không kết nối LLM.
 * V30 là bản beta tự chứa; người dùng cần thử Safari iPhone thực trước khi phát hành.
 */
(function(root,factory){
  const E=root.StoreEngine||(typeof module!=='undefined'?require('./engine.js'):null);
  if(!E)throw Error('StoreEngine must load before expansion.js');
  const api=factory(E,root);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(E,root){
  'use strict';
  const STAGE=Math.max(25,Math.min(30,Number(root.STORE_RELEASE_STAGE)||30));
  const DECOR_SLOTS=[
    {x:352,y:265,label:'Góc thu ngân'}, {x:386,y:407,label:'Gần cửa'},
    {x:744,y:444,label:'Cuối kệ'}, {x:891,y:390,label:'Góc trái cây'},
    {x:830,y:194,label:'Cạnh kho'}, {x:528,y:175,label:'Tường sau'},
    {x:620,y:449,label:'Lối rộng'}, {x:483,y:434,label:'Góc chào khách'}
  ];
  const STORY=[
    {id:'opening',title:'Chương 1 · Ngày khai trương',desc:'Nhập 24 hàng, xếp 16 sản phẩm và khai trương',reward:180000,xp:45,
      ready:s=>s.stats.ordered>=24&&s.stats.restocked>=16&&s.everOpened},
    {id:'community',title:'Chương 2 · Khách quen khu phố',desc:'Phục vụ 25 khách, uy tín đạt 78%',reward:380000,xp:90,
      ready:s=>s.stats.served>=25&&s.reputation>=78},
    {id:'growth',title:'Chương 3 · Cửa hàng phát triển',desc:'Mở rộng cửa hàng và đạt doanh thu 1 triệu',reward:850000,xp:150,
      ready:s=>s.storeLevel>=2&&s.stats.revenue>=1000000},
    {id:'leader',title:'Chương 4 · Cửa hàng kiểu mẫu',desc:'Đạt cấp 5, phục vụ 100 khách và uy tín 90%',reward:1800000,xp:250,
      ready:s=>s.level>=5&&s.stats.served>=100&&s.reputation>=90}
  ];
  const EVENTS=[
    {id:'weekend',icon:'🎊',name:'Ngày hội mua sắm',desc:'Lượng khách đến đông hơn, hãy giữ kệ đầy hàng!',every:3},
    {id:'fresh',icon:'🍎',name:'Ngày hàng tươi',desc:'Khách chú ý đến sữa và trái cây, ưu tiên bổ sung kệ.',every:5},
    {id:'community',icon:'💖',name:'Ngày tri ân',desc:'Phục vụ chu đáo để tăng thiện cảm khách hàng.',every:7}
  ];
  function hydrate(s){
    s.layout??={shelves:{drink:0,snack:1,milk:2,fruit:3,noodle:4,frozen:5},decor:{}};
    s.layout.shelves??={drink:0,snack:1,milk:2,fruit:3,noodle:4,frozen:5};
    s.layout.decor??={};
    const assigned=new Set();for(const c of E.CATEGORIES){let n=s.layout.shelves[c.id];
      if(!Number.isInteger(n)||n<0||n>=E.SHELF_SLOTS.length||assigned.has(n))n=Array.from({length:E.SHELF_SLOTS.length},(_,i)=>i).find(i=>!assigned.has(i));
      s.layout.shelves[c.id]=n;assigned.add(n);
    }
    const used=new Set();for(const [key,v] of Object.entries(s.layout.decor)){
      if(!s.decor.includes(key)||!Number.isInteger(v)||v<0||v>=8||used.has(v))delete s.layout.decor[key];else used.add(v);
    }
    s.service??={vipServed:0,repeatVisits:0};s.service.vipServed=E.clamp(Math.floor(s.service.vipServed||0),0,1000000);
    s.service.repeatVisits=E.clamp(Math.floor(s.service.repeatVisits||0),0,1000000);
    s.storyClaimed=Array.isArray(s.storyClaimed)?s.storyClaimed.filter(x=>STORY.some(m=>m.id===x)):[];
    s.dailyStreak=E.clamp(Math.floor(s.dailyStreak||0),0,3650);
    s.daysPlayed=E.clamp(Math.floor(s.daysPlayed||0),0,36500);
    s.activeEvent=(s.activeEvent&&EVENTS.some(x=>x.id===s.activeEvent.id))?s.activeEvent:null;
    s.reputationLog=Array.isArray(s.reputationLog)?s.reputationLog.slice(-30):[];
    s.staff.forEach(m=>{m.shift=['full','morning','evening'].includes(m.shift)?m.shift:'full';m.trait=['friendly','efficient','patient'].includes(m.trait)?m.trait:'friendly';});
    return s;
  }
  const baseNew=E.createGame,baseLoad=E.normalizeSave,baseDispatch=E.dispatch,baseAdvance=E.advance;
  E.createGame=function(){return hydrate(baseNew());};
  E.normalizeSave=function(saved){return hydrate(baseLoad(saved));};
  E.dispatch=function(s,a){
    hydrate(s);
    if(a?.type==='CLAIM_STORY'&&STAGE>=29){
      const m=STORY.find(x=>x.id===a.id);if(!m)return{ok:false,message:'Không có chương này.'};
      if(s.storyClaimed.includes(m.id))return{ok:false,message:'Bạn đã nhận thưởng chương.'};
      const index=STORY.indexOf(m);if(index>0&&!s.storyClaimed.includes(STORY[index-1].id))return{ok:false,message:'Hãy hoàn thành chương trước.'};
      if(!m.ready(s))return{ok:false,message:'Chưa hoàn thành mục tiêu chương.'};
      s.cash+=m.reward;s.xp+=m.xp;s.storyClaimed.push(m.id);
      while(s.xp>=s.level*140){s.xp-=s.level*140;s.level++;s.reputation=E.clamp(s.reputation+2,0,100);}
      s.log.unshift({id:'story'+m.id,text:'🏅 Hoàn thành '+m.title+' +'+E.money(m.reward),type:'success',at:s.elapsed});
      return{ok:true,message:'Chúc mừng! Nhận '+E.money(m.reward)+' và '+m.xp+' XP.'};
    }
    if(a?.type==='PLACE_DECOR'&&STAGE<28)return{ok:false,message:'Mở khóa từ V28.'};
    if(a?.type==='MOVE_SHELF'&&STAGE<28)return{ok:false,message:'Mở khóa từ V28.'};
    if(a?.type==='HIRE'&&STAGE<27)return{ok:false,message:'Mở khóa từ V27.'};
    if(a?.type==='SET_SHIFT'&&STAGE<27)return{ok:false,message:'Mở khóa từ V27.'};
    const out=baseDispatch(s,a);
    if(out.ok&&a.type==='BUY_DECOR'&&STAGE>=28){
      const used=new Set(Object.values(s.layout.decor));const free=DECOR_SLOTS.findIndex((_,i)=>!used.has(i));
      if(free>=0)s.layout.decor[a.id]=free;
    }
    return out;
  };
  E.advance=function(s,rng=Math.random){
    hydrate(s);const beforeDay=s.day,beforeVisitors=s.stats.visitors,beforeServed=s.stats.served;
    baseAdvance(s,rng);
    if(STAGE>=26){
      // Nhân vật mới nhận một tính cách và nhãn tình huống riêng, tồn tại suốt chuyến mua.
      for(const c of s.customers){
        if(!c.profile){
          c.profile=c.personality==='vội vàng'?'Khách bận rộn':c.personality==='săn ưu đãi'?'Khách thích giảm giá':'Khách thư thả';
          c.vip=(Number(String(c.id).replace(/\D/g,''))||s.stats.visitors)%17===0;
          c.loyal=(Number(String(c.id).replace(/\D/g,''))||s.stats.visitors)%8===0;
          if(c.vip){c.budget+=90000;c.patience+=6;c.mood=Math.min(100,c.mood+5);c.thought='🌟 Khách VIP tìm sản phẩm';}
          if(c.loyal){c.patience+=3;s.service.repeatVisits++;}
        }
        if(c.stage==='needHelp'&&c.patience<5){c.thought='🙋 Cần hỗ trợ gấp!';}
      }
      if(s.stats.served>beforeServed){
        const servedNow=s.stats.served-beforeServed;
        // Định kỳ có khách VIP mua thành công, chỉ ghi nhận một lần trên số giao dịch thực.
        if(s.stats.served%17<servedNow){s.service.vipServed++;s.reputation=E.clamp(s.reputation+.7,0,100);}
      }
    }
    if(STAGE>=29){
      if(s.day!==beforeDay){
        s.daysPlayed++;
        const yesterday=s.history[0];
        s.dailyStreak=(yesterday&&yesterday.served>=3&&yesterday.net>0)?s.dailyStreak+1:0;
        const event=EVENTS.find(e=>s.day%e.every===0);
        s.activeEvent=event?{id:event.id,name:event.name,icon:event.icon,desc:event.desc,day:s.day}:null;
        if(event)s.log.unshift({id:'event'+s.day,text:event.icon+' Sự kiện: '+event.name,type:'success',at:s.elapsed});
      }
      if(s.activeEvent&&s.activeEvent.day===s.day&&s.opened&&s.runtime.spawnIn>5){s.runtime.spawnIn=5;}
    }
    return s;
  };
  E.RELEASE_STAGE=STAGE;
  E.DECOR_SLOTS=DECOR_SLOTS;
  E.STORY=STORY;
  E.EVENTS=EVENTS;
  E.hydrate=hydrate;
  return {STAGE,DECOR_SLOTS,STORY,EVENTS,hydrate};
});
