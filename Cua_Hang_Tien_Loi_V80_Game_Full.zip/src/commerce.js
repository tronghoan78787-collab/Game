/*
 * CỬA HÀNG TIỆN LỢI — V71–V75: ĐIỀU HÀNH SẢN PHẨM VÀ NHU CẦU
 * GIẢ ĐỊNH:
 * - Dữ liệu kho V70 theo NGÀNH HÀNG, không theo SKU. Một 'mặt hàng nổi bật' là
 *   lựa chọn trưng bày và tư vấn trong ngành, KHÔNG phải tồn kho SKU riêng.
 * - Giá bán điều chỉnh theo ngành áp dụng thật cho hóa đơn; không sửa giá nhập.
 * - Sự kiện nhu cầu được tính từ ngày trong game, không phụ thuộc internet.
 * - Không bổ sung tiền thật/giỏ hàng thật. Game chơi đơn offline.
 * - Giữ E.VERSION=12, khóa dữ liệu V12 và không thay đổi dữ liệu V70 khác.
 */
(function(root, factory){
  const E=root.StoreEngine||(typeof module!=='undefined'?require('./engine.js'):null);
  if(!E)throw new Error('commerce.js requires StoreEngine');
  const api=factory(E,root);
  root.StoreCommerce=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(E,root){
 'use strict';
 const STAGE=Math.max(71,Math.min(75,Number(root.STORE_COMMERCE_STAGE)||75));
 const CATALOG=[
  {id:'water',cat:'drink',name:'Nước suối',icon:'💧',kind:'water'},
  {id:'tea',cat:'drink',name:'Trà trái cây',icon:'🧋',kind:'tea'},
  {id:'juice',cat:'drink',name:'Nước cam',icon:'🍊',kind:'juice'},
  {id:'cookies',cat:'snack',name:'Bánh quy',icon:'🍪',kind:'cookies'},
  {id:'chips',cat:'snack',name:'Snack khoai',icon:'🥔',kind:'chips'},
  {id:'candy',cat:'snack',name:'Kẹo trái cây',icon:'🍬',kind:'candy'},
  {id:'freshmilk',cat:'milk',name:'Sữa tươi',icon:'🥛',kind:'milk'},
  {id:'yogurt',cat:'milk',name:'Sữa chua',icon:'🍶',kind:'yogurt'},
  {id:'soymilk',cat:'milk',name:'Sữa đậu nành',icon:'🫘',kind:'soymilk'},
  {id:'apple',cat:'fruit',name:'Táo đỏ',icon:'🍎',kind:'apple'},
  {id:'banana',cat:'fruit',name:'Chuối',icon:'🍌',kind:'banana'},
  {id:'orange',cat:'fruit',name:'Cam tươi',icon:'🍊',kind:'orange'},
  {id:'instantnoodle',cat:'noodle',name:'Mì ly',icon:'🍜',kind:'noodle'},
  {id:'ricesnack',cat:'noodle',name:'Bún ăn liền',icon:'🥡',kind:'rice'},
  {id:'porridge',cat:'noodle',name:'Cháo gói',icon:'🥣',kind:'porridge'},
  {id:'icecream',cat:'frozen',name:'Kem hộp',icon:'🍨',kind:'icecream'},
  {id:'dumpling',cat:'frozen',name:'Há cảo',icon:'🥟',kind:'dumpling'},
  {id:'frozenveg',cat:'frozen',name:'Rau đông lạnh',icon:'🥦',kind:'vegetable'}
 ];
 const EVENTS=[
  {id:'heat',name:'Ngày nắng nóng',icon:'☀️',description:'Khách tìm đồ uống và trái cây nhiều hơn.',weights:{drink:1.7,fruit:1.4,milk:1.0,snack:.85,noodle:.8,frozen:1.1}},
  {id:'family',name:'Ngày mua sắm gia đình',icon:'👨‍👩‍👧',description:'Bánh kẹo và sữa được quan tâm.',weights:{drink:1,snack:1.5,milk:1.45,fruit:1.1,noodle:.9,frozen:1}},
  {id:'rain',name:'Ngày mưa',icon:'🌧️',description:'Mì gói, đồ đông lạnh và sữa có nhu cầu cao.',weights:{drink:.8,snack:1,milk:1.2,fruit:.9,noodle:1.7,frozen:1.35}},
  {id:'normal',name:'Ngày mua sắm thường',icon:'🌤️',description:'Các ngành hàng có nhu cầu cân bằng.',weights:{drink:1,snack:1,milk:1,fruit:1,noodle:1,frozen:1}}
 ];
 const GOALS=[
  {id:'firstFeature',icon:'🪄',title:'Chọn sản phẩm chủ lực',desc:'Chọn ít nhất một sản phẩm nổi bật',reward:65000,xp:18,done:s=>Object.keys(s.commerce.featured).length>=1},
  {id:'healthyMargin',icon:'📈',title:'Tạo lãi gộp 100.000đ',desc:'Tổng doanh thu trừ giá vốn đạt 100.000đ',reward:125000,xp:35,done:s=>s.stats.revenue-s.stats.cogs>=100000},
  {id:'sellFifteen',icon:'😊',title:'Khách tin tưởng',desc:'Phục vụ 15 lượt khách thành công',reward:170000,xp:44,done:s=>s.stats.served>=15},
  {id:'developStore',icon:'🏬',title:'Mở rộng ngành hàng',desc:'Đạt cấp độ cửa hàng 2',reward:240000,xp:55,done:s=>s.storeLevel>=2}
 ];
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const safeInt=(n)=>Number.isFinite(Number(n))?Math.floor(Number(n)):0;
 const getCat=id=>E.CATEGORIES.find(c=>c.id===id);
 const skuValid=(sku,cat)=>CATALOG.some(p=>p.id===sku&&p.cat===cat);
 const basePrice=(id)=>getCat(id)?.price||0;
 function eventOf(day){return STAGE<72?EVENTS[3]:EVENTS[(Math.max(1,safeInt(day))-1)%EVENTS.length];}
 function hydrate(s){
  if(!s||typeof s!=='object')return s;
  const raw=s.commerce&&typeof s.commerce==='object'?s.commerce:{};
  const prices={};for(const c of E.CATEGORIES){
    const original=c.price;
    const val=Number(raw.prices?.[c.id]);
    const min=Math.ceil(original*.8/500)*500,max=Math.floor(original*1.3/500)*500;
    prices[c.id]=Number.isInteger(val)&&val>=min&&val<=max&&val%500===0?val:original;
  }
  const featured={};for(const c of E.CATEGORIES){
    if(skuValid(raw.featured?.[c.id],c.id))featured[c.id]=raw.featured[c.id];
  }
  const count={};for(const c of E.CATEGORIES)count[c.id]=clamp(safeInt(raw.units?.[c.id]),0,100000000);
  s.commerce={prices,featured,units:count,
    claimed:Array.isArray(raw.claimed)?raw.claimed.filter(id=>GOALS.some(g=>g.id===id)).slice(0,GOALS.length):[],
    lastServed:clamp(safeInt(raw.lastServed??s.stats?.served),0,100000000),
    priceChanges:clamp(safeInt(raw.priceChanges),0,99999),
    counter:clamp(safeInt(raw.counter),0,100000000),
    recent: Array.isArray(raw.recent)?raw.recent.slice(0,15).filter(x=>x&&typeof x==='object'):[]};
  return s;
 }
 function effectivePrice(s,id){hydrate(s);return s.commerce.prices[id]||basePrice(id);}
 function demand(s,id){
   const base=eventOf(s.day).weights[id]||1;
   const price=effectivePrice(s,id),standard=basePrice(id);
   const value=base * clamp(1+(standard-price)/standard*.9,.72,1.22);
   return +(value*(STAGE>=73&&s.commerce.featured[id]?1.14:1)).toFixed(2);
 }
 function forecast(s){
   hydrate(s);return E.activeCats(s).map(cat=>{
      const ratio=demand(s,cat.id);const onShelf=s.stock[cat.id]||0;
      const inWarehouse=s.warehouse[cat.id]||0;
      const incoming=s.pending.reduce((q,p)=>q+(p.cat===cat.id?Math.max(0,p.qty-p.received):0),0);
      const needed=Math.ceil(12*ratio*2);
      const shortage=Math.max(0,needed-onShelf-inWarehouse-incoming);
      const price=effectivePrice(s,cat.id);
      return {id:cat.id,name:cat.name,icon:cat.icon,demand:ratio,price,cost:cat.cost,margin:price-cat.cost,
       shelf:onShelf,warehouse:inWarehouse,incoming,target:needed,shortage,featured:s.commerce.featured[cat.id]||null};
   });
 }
 function fixedMultiplier(s,cat){return demand(s,cat);}
 const oldCreate=E.createGame,oldNormalize=E.normalizeSave,oldDispatch=E.dispatch,oldAdvance=E.advance;
 E.createGame=function(){return hydrate(oldCreate());};
 E.normalizeSave=function(raw){return hydrate(oldNormalize(raw));};
 E.dispatch=function(s,action){
   hydrate(s);
   if(action?.type==='SET_PRICE'){
     const cat=getCat(action.id),value=Number(action.price);
     if(!cat||cat.unlock>s.storeLevel)return {ok:false,message:'Ngành hàng chưa mở khóa.'};
     const min=Math.ceil(cat.price*.8/500)*500,max=Math.floor(cat.price*1.3/500)*500;
     if(!Number.isInteger(value)||value%500!==0||value<min||value>max)
       return {ok:false,message:'Giá bán phải là bội số 500đ, trong mức 80–130% giá gốc.'};
     s.commerce.prices[cat.id]=value;s.commerce.priceChanges++;
     return {ok:true,message:`Giá ${cat.name}: ${E.money(value)} / sản phẩm.`};
   }
   if(action?.type==='FEATURE_SKU'){
     if(STAGE<73)return {ok:false,message:'Tính năng mở từ giai đoạn V73.'};
     const cat=getCat(action.id),sku=action.sku;
     if(!cat||cat.unlock>s.storeLevel||!skuValid(sku,cat.id))return {ok:false,message:'Mặt hàng nổi bật không hợp lệ.'};
     s.commerce.featured[cat.id]=sku;
     return {ok:true,message:'Đã trưng bày nổi bật '+CATALOG.find(p=>p.id===sku).name+'.'};
   }
   if(action?.type==='RESET_PRICES'){
     for(const c of E.CATEGORIES)s.commerce.prices[c.id]=c.price;
     return {ok:true,message:'Đã khôi phục toàn bộ giá niêm yết.'};
   }
   if(action?.type==='CLAIM_GROWTH'){
     if(STAGE<74)return {ok:false,message:'Tính năng mở từ giai đoạn V74.'};
     const goal=GOALS.find(g=>g.id===action.id);
     if(!goal)return {ok:false,message:'Nhiệm vụ không hợp lệ.'};
     if(s.commerce.claimed.includes(goal.id))return {ok:false,message:'Đã nhận phần thưởng này.'};
     if(!goal.done(s))return {ok:false,message:'Chưa đạt mục tiêu.'};
     s.commerce.claimed.push(goal.id);s.cash+=goal.reward;s.xp+=goal.xp;
     while(s.xp>=s.level*140){s.xp-=s.level*140;s.level++;s.reputation=clamp(s.reputation+2,0,100);}
     return {ok:true,message:'Nhận '+E.money(goal.reward)+' và '+goal.xp+' XP.'};
   }
   return oldDispatch(s,action);
 };
 E.advance=function(s,rng=Math.random){
   hydrate(s);
   const beforeServed=s.stats.served;
   const previousIds=new Set(s.customers.map(c=>c.id));
   const basePrices=E.CATEGORIES.map(c=>c.price);
   try{
     for(const cat of E.CATEGORIES)cat.price=s.commerce.prices[cat.id];
     oldAdvance(s,rng);
   }finally{
     E.CATEGORIES.forEach((cat,i)=>{cat.price=basePrices[i];});
   }
   // Mỗi khách mới có mong muốn mua sắm riêng theo sự kiện / giá bán / sản phẩm nổi bật.
   for(const customer of s.customers){
     if(previousIds.has(customer.id)||customer.stage!=='browse')continue;
     const choices=E.activeCats(s);const weighted=choices.map(c=>fixedMultiplier(s,c.id));
     const total=weighted.reduce((sum,v)=>sum+v,0);let draw=rng()*total,chosen=choices[0];
     for(let i=0;i<choices.length;i++){draw-=weighted[i];if(draw<=0){chosen=choices[i];break;}}
     customer.cat=chosen.id;customer.thought='Tìm '+chosen.name;
   }
   // Gắn mặt hàng nổi bật (thuộc ngành được bán), không tạo tồn SKU ảo.
   if(s.stats.served>beforeServed&&s.receipts?.length){
     for(let j=0;j<Math.min(5,s.stats.served-beforeServed);j++){
       const receipt=s.receipts[j];if(!receipt)continue;
       receipt.featuredNames=[];
       for(const id of receipt.items||[]){
         s.commerce.units[id]=clamp(s.commerce.units[id]+1,0,100000000);
         const chosen=s.commerce.featured[id];if(chosen)receipt.featuredNames.push(CATALOG.find(p=>p.id===chosen)?.name||chosen);
       }
       s.commerce.recent.unshift({day:s.day,category:receipt.items?.[0]||'',bill:receipt.bill});
     }
     s.commerce.recent=s.commerce.recent.slice(0,15);
   }
   s.commerce.lastServed=s.stats.served;
   return s;
 };
 E.COMMERCE_CATALOG=CATALOG;E.COMMERCE_EVENTS=EVENTS;E.COMMERCE_GOALS=GOALS;
 E.commerceEvent=eventOf;E.commerceDemand=demand;E.commerceForecast=forecast;E.commercePrice=effectivePrice;
 return {STAGE,CATALOG,EVENTS,GOALS,eventOf,hydrate,effectivePrice,demand,forecast};
});
