/*
 * CỬA HÀNG TIỆN LỢI — GAMEPLAY ENGINE V12
 * GIẢ ĐỊNH (giai đoạn 1): game chơi đơn, tiền ảo VNĐ, 1 giây thực = 2 phút game;
 * kinh tế và AI mô phỏng chạy trên thiết bị, không cần API hay máy chủ.
 * Mô-đun thuần JavaScript: dùng được trực tiếp trên trình duyệt và trong Node tests.
 */
(function(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.StoreEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';
  const VERSION = 12;
  const START_CASH = 10000000;
  const BUILD = 30; // V21–V24 tiếp tục tương thích định dạng bản lưu V12.
  const CATEGORIES = [
    {id:'drink',name:'Đồ uống',icon:'🥤',cost:8000,price:14000,color:'#47adff',pos:[426,240],unlock:1},
    {id:'snack',name:'Bánh kẹo',icon:'🍪',cost:10000,price:18000,color:'#ffbd51',pos:[591,217],unlock:1},
    {id:'milk',name:'Sữa',icon:'🥛',cost:14000,price:23000,color:'#72d8d0',pos:[705,299],unlock:1},
    {id:'fruit',name:'Trái cây',icon:'🍎',cost:11000,price:19000,color:'#80cf6a',pos:[827,358],unlock:1},
    {id:'noodle',name:'Mì gói',icon:'🍜',cost:7000,price:13000,color:'#f28764',pos:[510,337],unlock:2},
    {id:'frozen',name:'Đông lạnh',icon:'🧊',cost:16000,price:27000,color:'#8ab7ff',pos:[665,396],unlock:2}
  ];
  const EQUIPMENT = [
    {id:'scanner',name:'Máy quét mã',icon:'🔎',price:650000,desc:'Thu ngân thanh toán nhanh hơn 35%',effect:'cashierSpeed'},
    {id:'cart',name:'Xe đẩy hàng',icon:'🛒',price:480000,desc:'Bổ sung kệ được thêm 8 sản phẩm/lượt',effect:'restockSpeed'},
    {id:'cold',name:'Tủ mát lớn',icon:'🧊',price:1250000,desc:'Sức chứa kệ sữa và đồ uống +16',effect:'shelfCapacity'},
    {id:'storage',name:'Kệ kho',icon:'📦',price:850000,desc:'Sức chứa kho tăng thêm 160 sản phẩm',effect:'warehouseCapacity'},
    {id:'pos',name:'POS hiện đại',icon:'💳',price:1900000,desc:'Nâng tốc độ thanh toán, uy tín +4',effect:'fastCheckout'},
    {id:'express',name:'Hợp đồng giao nhanh',icon:'🚚',price:580000,desc:'Nhà cung cấp giao hàng sau 5 giây thay vì 9 giây',effect:'deliverySpeed'}
  ];
  const DECOR = [
    {id:'plant',name:'Chậu cây',icon:'🪴',price:120000,appeal:2,desc:'Góc xanh dễ chịu'},
    {id:'poster',name:'Poster khuyến mãi',icon:'🖼️',price:180000,appeal:3,desc:'Thu hút khách chú ý chương trình'},
    {id:'flower',name:'Chậu hoa',icon:'🌸',price:260000,appeal:4,desc:'Mang sắc màu cho cửa hàng'},
    {id:'mascot',name:'Linh vật',icon:'🐻',price:520000,appeal:7,desc:'Tăng cảm giác thân thiện'},
    {id:'lamp',name:'Đèn trang trí',icon:'💡',price:340000,appeal:5,desc:'Không gian tươi sáng'}
  ];
  const MISSIONS = [
    {id:'order24',title:'Nhập hàng đầu tiên',desc:'Đặt ít nhất 24 sản phẩm',metric:'ordered',goal:24,reward:90000,xp:30},
    {id:'shelf16',title:'Lấp đầy các kệ',desc:'Đưa 16 sản phẩm lên kệ',metric:'restocked',goal:16,reward:100000,xp:30},
    {id:'open',title:'Khai trương cửa hàng',desc:'Mở cửa và đón khách',metric:'opened',goal:1,reward:60000,xp:25},
    {id:'serve5',title:'Khách hàng thân thiết',desc:'Thanh toán thành công cho 5 khách',metric:'served',goal:5,reward:180000,xp:60},
    {id:'promote',title:'Bán hàng thông minh',desc:'Thiết lập 1 chương trình khuyến mãi',metric:'promotions',goal:1,reward:80000,xp:25},
    {id:'clean',title:'Cửa hàng sạch sẽ',desc:'Nhân viên vệ sinh ít nhất 3 lượt',metric:'cleaned',goal:3,reward:90000,xp:30},
    {id:'decor',title:'Không gian tươi mới',desc:'Mua 1 món đồ trang trí',metric:'decorBought',goal:1,reward:95000,xp:40},
    {id:'sales',title:'Ngày kinh doanh thành công',desc:'Đạt tổng doanh thu 250.000đ',metric:'revenue',goal:250000,reward:200000,xp:75}
  ];
  const ACHIEVEMENTS = [
    {id:'first',title:'Đơn hàng đầu tay',desc:'Phục vụ 1 khách',metric:'served',goal:1,reward:40000},
    {id:'fifty',title:'Chuyên gia bán hàng',desc:'Phục vụ 50 khách',metric:'served',goal:50,reward:500000},
    {id:'million',title:'Triệu phú doanh thu',desc:'Đạt doanh thu 1.000.000đ',metric:'revenue',goal:1000000,reward:250000},
    {id:'happy',title:'Người quản lý tận tâm',desc:'Đạt uy tín 95%',metric:'reputation',goal:95,reward:150000},
    {id:'expand',title:'Chủ cửa hàng lớn',desc:'Mở rộng siêu thị',metric:'expanded',goal:1,reward:350000}
  ];
  // V19: nhiệm vụ thay đổi theo ngày, chỉ trả thưởng một lần mỗi ngày.
  const DAILY_TASKS = [
    {id:'customers',name:'Khách đầu ngày',desc:'Phục vụ 3 khách',metric:'served',goal:3,reward:65000,xp:12},
    {id:'income',name:'Doanh số hôm nay',desc:'Bán 100.000đ hàng hóa',metric:'revenue',goal:100000,reward:85000,xp:16},
    {id:'quality',name:'Cửa hàng sáng bóng',desc:'Giữ độ sạch ít nhất 85%',metric:'cleanliness',goal:85,reward:40000,xp:10},
    {id:'stock',name:'Kệ đầy ắp',desc:'Giữ ít nhất 16 sản phẩm trên kệ',metric:'shelf',goal:16,reward:50000,xp:10}
  ];
  // V21: ngày nhận hàng được lưu theo từng lô cho hàng tươi, dùng FIFO để tránh
  // việc nhập lô mới làm trẻ hóa toàn bộ tồn kho như phiên bản trước.
  const FRESH_LIFE={fruit:3,milk:5};
  const FRESH_IDS=Object.keys(FRESH_LIFE);
  function pushLot(s,place,id,qty,day=s.day){
    if(!FRESH_LIFE[id]||qty<=0)return;
    const lots=s.lots[place][id];
    const last=lots[lots.length-1];
    if(last&&last.day===day)last.qty+=qty;
    else lots.push({day,qty});
  }
  function takeLot(s,place,id,qty){
    if(!FRESH_LIFE[id]||qty<=0)return [];
    const lots=s.lots[place][id],taken=[];let left=qty;
    lots.sort((a,b)=>a.day-b.day);
    while(left>0&&lots.length){
      const current=lots[0],n=Math.min(left,current.qty);
      taken.push({day:current.day,qty:n});current.qty-=n;left-=n;
      if(current.qty===0)lots.shift();
    }
    return taken;
  }
  function shiftFresh(s,id,qty){
    const taken=takeLot(s,'warehouse',id,qty);
    for(const lot of taken)pushLot(s,'stock',id,lot.qty,lot.day);
  }
  function checkFresh(s){
    // Đồng bộ lô chỉ khi gặp dữ liệu lưu cũ / bản mô phỏng test đặt tồn trực tiếp.
    for(const area of ['stock','warehouse'])for(const id of FRESH_IDS){
      const lots=s.lots[area][id];let sum=lots.reduce((v,l)=>v+l.qty,0),actual=s[area][id];
      if(sum<actual)pushLot(s,area,id,actual-sum,Math.min(s.day,s.freshDay[id]||s.day));
      else if(sum>actual)takeLot(s,area,id,sum-actual);
    }
    let count=0,expense=0;
    for(const id of FRESH_IDS){
      for(const area of ['stock','warehouse']){
        const lots=s.lots[area][id],expired=lots.filter(l=>s.day-l.day>=FRESH_LIFE[id]);
        const loss=expired.reduce((n,l)=>n+l.qty,0);
        if(loss){s[area][id]=Math.max(0,s[area][id]-loss);s.lots[area][id]=lots.filter(l=>s.day-l.day<FRESH_LIFE[id]);count+=loss;expense+=loss*getCat(id).cost;}
      }
    }
    if(count){s.stats.wasteCost=(s.stats.wasteCost||0)+expense;s.today.wasteCost=(s.today.wasteCost||0)+expense;
      log(s,'⚠️ Đã hủy '+count+' sản phẩm quá hạn (FIFO) · '+money(expense),'warn');}
    return {count,expense};
  }
  const ROLES = ['cashier','operator','rest'];
  const ROLE_NAMES = {cashier:'Thu ngân',operator:'Vận hành',rest:'Nghỉ giải lao'};
  const clamp = (x,a,b)=>Math.max(a,Math.min(b,x));
  const getCat = id => CATEGORIES.find(c=>c.id===id);
  const categoryPos=(s,cat)=>{const slot=s.layout?.shelves?.[cat.id];return Number.isInteger(slot)&&SHELF_SLOTS[slot]?SHELF_SLOTS[slot]:cat.pos;};
  const SHELF_SLOTS=[[426,240],[591,217],[705,299],[827,358],[510,337],[665,396]];
  const money = x => Math.round(x).toLocaleString('vi-VN')+'đ';
  const randId = (prefix,state)=>prefix+(++state.serial);
  const integer = (x)=>Math.floor(Math.max(0,Number(x)||0));
  const activeCats = s => CATEGORIES.filter(c=>c.unlock<=s.storeLevel);
  const stockTotal = (s,field)=>activeCats(s).reduce((a,c)=>a+(s[field][c.id]||0),0);
  const shelfCapacity = (s,id)=>24 + (s.equipment.includes('cold') && ['drink','milk'].includes(id)?16:0) + (s.storeLevel>=2?8:0)+(s.storeLevel>=3?6:0)+(s.storeLevel>=4?6:0);
  const warehouseCapacity = s => 160 +(s.equipment.includes('storage')?160:0)+(s.storeLevel>=2?120:0)+(s.storeLevel>=3?220:0)+(s.storeLevel>=4?260:0);
  const reputation = s => Math.round(s.reputation);
  const purchasePrice = (cat,qty) => cat.cost*qty;
  const weightedChoice = (options,weight,rng)=>{
    const total=options.reduce((a,v)=>a+Math.max(0,weight(v)),0);
    let r=rng()*total;for (const v of options){r-=Math.max(0,weight(v));if(r<=0)return v;}return options[options.length-1];
  };
  function createGame() {
    const stock={},warehouse={};for (const c of CATEGORIES){stock[c.id]=0;warehouse[c.id]=0;}
    return {
      version:VERSION,serial:0,name:'Tiệm Vui Vẻ',manager:'Cửa hàng trưởng',cash:START_CASH,
      day:1,minutes:8*60,elapsed:0,opened:false,everOpened:false,paused:false,speed:1,
      level:1,xp:0,reputation:76,cleanliness:96,storeLevel:1,
      reviews:[],dailyClaimed:[],eventClock:{lastRushDay:0,lastRushHour:0},build:BUILD,
      stock,warehouse,pending:[],equipment:[],decor:[],freshDay:{},lastAuditDay:0,
      layout:{shelves:{drink:0,snack:1,milk:2,fruit:3,noodle:4,frozen:5},decor:{}},staffLimit:4,
      reputationLog:[],storyClaimed:[],activeEvent:null,eventDay:0,service:{vipServed:0,repeatVisits:0},
      lots:{stock:{fruit:[],milk:[]},warehouse:{fruit:[],milk:[]}}, receipts:[], customerCare:{loyalty:0,complaints:0},
      promo:{cat:null,rate:0,untilDay:0},
      staff:[
        {id:'an',name:'An',role:'cashier',mood:92,energy:92,skill:1,experience:0,task:'Chờ khách thanh toán',x:296,y:382,bubble:''},
        {id:'binh',name:'Bình',role:'operator',mood:90,energy:96,skill:1,experience:0,task:'Kiểm tra kệ hàng',x:770,y:210,bubble:''}
      ],
      customers:[],messages:[],effects:[],questsClaimed:[],achievementsClaimed:[],
      stats:{ordered:0,restocked:0,opened:0,served:0,promotions:0,cleaned:0,decorBought:0,
        revenue:0,cogs:0,wages:0,utilities:0,operatingCosts:0,missed:0,happy:0,visitors:0,expanded:0},
      today:{revenue:0,cogs:0,served:0,missed:0,wages:0,utilities:0},
      history:[],
      tutorial:{phase:0,hidden:false},
      settings:{sound:false,quality:'auto',renderMode:'illustrated',fpsTarget:30,lighting:true,showNames:true,largeText:false,reducedMotion:false},
      runtime:{spawnIn:7,cashierTimer:0,operatorTimer:0,activity:0},
      log:[{id:0,text:'🏪 Chào mừng! Hãy đặt hàng để chuẩn bị khai trương.',type:'info',at:0}]
    };
  }
  function normalizeSave(raw){
    if(!raw || raw.version!==VERSION)return createGame();
    const base=createGame();
    const merged={...base,...raw,stock:{...base.stock,...(raw.stock||{})},warehouse:{...base.warehouse,...(raw.warehouse||{})},
      stats:{...base.stats,...(raw.stats||{})},today:{...base.today,...(raw.today||{})},
      settings:{...base.settings,...(raw.settings||{})},runtime:{...base.runtime,...(raw.runtime||{})},freshDay:{...base.freshDay,...(raw.freshDay||{})},
      tutorial:{...base.tutorial,...(raw.tutorial||{})}};
    merged.reviews=Array.isArray(raw.reviews)?raw.reviews.slice(0,24):[];
    merged.layout={shelves:{...base.layout.shelves,...(raw.layout?.shelves||{})},decor:{...(raw.layout?.decor||{})}};
    merged.storyClaimed=Array.isArray(raw.storyClaimed)?raw.storyClaimed.filter(x=>typeof x==='string'):[];
    merged.service={...base.service,...(raw.service||{})};
    merged.reputationLog=Array.isArray(raw.reputationLog)?raw.reputationLog.slice(0,30):[];
    merged.dailyClaimed=Array.isArray(raw.dailyClaimed)?raw.dailyClaimed:[];
    merged.eventClock={...base.eventClock,...raw.eventClock};
    merged.build=BUILD;
    merged.receipts=Array.isArray(raw.receipts)?raw.receipts.slice(0,40):[];
    merged.customerCare={...base.customerCare,...raw.customerCare};
    merged.lots={stock:{fruit:[],milk:[]},warehouse:{fruit:[],milk:[]}};
    for(const c of CATEGORIES){merged.stock[c.id]=integer(raw.stock?.[c.id]);merged.warehouse[c.id]=integer(raw.warehouse?.[c.id]);}
    // Normal hóa dữ liệu lô: không tin số lượng từ bản lưu nhập vào vượt tổng tồn thực tế.
    for(const place of ['stock','warehouse'])for(const id of FRESH_IDS){
      const quantity=merged[place][id];
      const candidate=Array.isArray(raw.lots?.[place]?.[id])?raw.lots[place][id]:[];
      const good=candidate.filter(l=>Number.isInteger(l.day)&&l.day>0&&l.day<=merged.day&&Number.isInteger(l.qty)&&l.qty>0)
        .map(l=>({day:l.day,qty:l.qty})).sort((a,b)=>a.day-b.day);
      let total=0;
      for(const l of good){const value=Math.min(l.qty,quantity-total);if(value>0)merged.lots[place][id].push({day:l.day,qty:value});total+=value;}
      if(total<quantity)pushLot(merged,place,id,quantity-total,Math.min(merged.day,raw.freshDay?.[id]||merged.day));
    }
    if(!Array.isArray(merged.customers))merged.customers=[];
    if(!Array.isArray(merged.pending))merged.pending=[];
    if(!Array.isArray(merged.staff)||merged.staff.length<2||merged.staff.length>4||!merged.staff.every(m=>m&&typeof m==='object'&&['an','binh','linh','minh'].includes(m.id))||!merged.staff.some(m=>m.id==='an')||!merged.staff.some(m=>m.id==='binh')||new Set(merged.staff.map(m=>m.id)).size!==merged.staff.length)merged.staff=base.staff;
    for(const m of merged.staff){m.shift=['full','morning','evening'].includes(m.shift)?m.shift:'full';m.trait=['friendly','efficient','patient'].includes(m.trait)?m.trait:'friendly';}
    merged.speed=[1,2,3].includes(merged.speed)?merged.speed:1;
    merged.reputation=clamp(Number(merged.reputation)||0,0,100);merged.cleanliness=clamp(Number(merged.cleanliness)||0,0,100);merged.cash=integer(merged.cash);merged.priority=['customer','delivery','shelf','clean'].includes(merged.priority)?merged.priority:'customer';return merged;
  }
  function log(s,text,type='info'){
    s.log.unshift({id:randId('l',s),text,type,at:s.elapsed});
    if(s.log.length>70)s.log.length=70;
  }
  function result(ok,message){return{ok,message};}
  function levelUp(s){
    while(s.xp>=s.level*140){s.xp-=s.level*140;s.level++;s.reputation=clamp(s.reputation+2,0,100);log(s,'🌟 Lên cấp '+s.level+'! Uy tín tăng.','success');}
  }
  const dailyValue=(s,task)=>task.metric==='cleanliness'?Math.floor(s.cleanliness):task.metric==='shelf'?stockTotal(s,'stock'):(s.today[task.metric]||0);
  const activeDailyTasks=(s)=>DAILY_TASKS.filter((_,i)=>(i+s.day)%4!==3).slice(0,3);
  function addReview(s,c,stars,reason){
    if(!s.reviews)s.reviews=[];
    const lines=stars>=4?['Nhân viên nhiệt tình, rất vui!','Quầy thanh toán nhanh, thích lắm!','Mua sắm dễ dàng, sẽ quay lại!']:
      ['Mình phải đợi khá lâu.','Mong lần sau tìm được sản phẩm.','Cửa hàng nên cải thiện dịch vụ.'];
    s.reviews.unshift({id:randId('r',s),day:s.day,stars,reason:reason||'',text:lines[s.stats.visitors%lines.length]});
    if(s.reviews.length>24)s.reviews.length=24;
  }
  function onShift(s,m){const hour=s.minutes/60;return !m.shift||m.shift==='full'||(m.shift==='morning'?hour<15:hour>=15);}
  function staffByRole(s,role){return s.staff.find(x=>x.role===role && !x.autoRest && x.energy>8 && onShift(s,x));}
  function changeMood(member,delta){member.mood=clamp(member.mood+delta,5,100);}
  function improveSkill(s,member,amount){member.experience+=amount;if(member.experience>=member.skill*45&&member.skill<5){member.experience=0;member.skill++;changeMood(member,8);log(s,'🎓 '+member.name+' đạt kỹ năng cấp '+member.skill+'!','success');}}
  function promoActive(s,cat){return s.promo.cat===cat && s.promo.rate>0 && s.promo.untilDay>=s.day;}
  function activeDiscount(s,cat){return promoActive(s,cat)?s.promo.rate:0;}
  function currentMetric(s,k){return k==='reputation'?s.reputation:(s.stats[k]||0);}
  function pendingCount(s){return s.pending.reduce((a,v)=>a+Math.max(0,v.qty-v.received),0);}
  function availableRoom(s){return warehouseCapacity(s)-stockTotal(s,'warehouse')-pendingCount(s);}
  function sendNotification(s,text,kind='info'){log(s,text,kind);}
  function buyItem(s,list,id,key){
    const item=list.find(x=>x.id===id);if(!item)return result(false,'Không tìm thấy vật phẩm.');
    if(s[key].includes(id))return result(false,'Đã sở hữu vật phẩm này.');
    if(s.cash<item.price)return result(false,'Không đủ tiền để mua '+item.name+'.');
    s.cash-=item.price;s[key].push(id);s.stats.operatingCosts+=item.price;
    if(key==='decor'){s.stats.decorBought++;s.reputation=clamp(s.reputation+item.appeal*.35,0,100);}
    else if(id==='pos'){s.reputation=clamp(s.reputation+4,0,100);}
    log(s,(key==='decor'?'🎀 ':'🛠️ ')+'Đã mua '+item.name+' (-'+money(item.price)+')','success');
    return result(true,'Đã mua '+item.name+'.');
  }
  function dispatch(s,action){
    if(!s||!action||typeof action.type!=='string')return result(false,'Thao tác không hợp lệ.');
    const id=action.id;
    switch(action.type){
      case 'ORDER':{
        const cat=getCat(id),qty=integer(action.qty);
        if(!cat||cat.unlock>s.storeLevel)return result(false,'Ngành hàng chưa mở khóa.');
        if(![12,24,48,96].includes(qty))return result(false,'Chọn lô 12, 24, 48 hoặc 96 sản phẩm.');
        if(availableRoom(s)<qty)return result(false,'Kho không còn đủ chỗ trống.');
        const cost=purchasePrice(cat,qty);
        if(s.cash<cost)return result(false,'Số dư không đủ để đặt hàng.');
        s.cash-=cost;s.stats.ordered+=qty;
        s.pending.push({id:randId('p',s),cat:id,qty,arrivesAt:s.elapsed+(s.equipment.includes('express')?5:9),arrived:false,received:0});
        log(s,'🚚 Đã đặt '+qty+' '+cat.name+' · '+money(cost),'success');
        s.tutorial.phase=Math.max(s.tutorial.phase,1);
        return result(true,'Đã đặt '+qty+' '+cat.name+'. Xe giao đến sau '+(s.equipment.includes('express')?5:9)+' giây.');
      }
      case 'CLAIM_DAILY':{
        const task=DAILY_TASKS.find(t=>t.id===id);
        if(!task || !activeDailyTasks(s).includes(task))return result(false,'Nhiệm vụ ngày không hợp lệ.');
        if(s.dailyClaimed.includes(s.day+':'+id))return result(false,'Đã nhận thưởng nhiệm vụ này.');
        if(dailyValue(s,task)<task.goal)return result(false,'Chưa đạt yêu cầu nhiệm vụ.');
        s.dailyClaimed.push(s.day+':'+id);s.cash+=task.reward;s.xp+=task.xp;levelUp(s);
        log(s,'🌞 Hoàn thành '+task.name+' +'+money(task.reward),'success');
        return result(true,'Nhận '+money(task.reward)+' và '+task.xp+' XP.');
      }
      case 'AUDIT':{
        if(s.lastAuditDay===s.day)return result(false,'Hôm nay đã kiểm kê.');
        s.lastAuditDay=s.day;const count=stockTotal(s,'stock')+stockTotal(s,'warehouse');
        log(s,'📋 Kiểm kê ngày '+s.day+': '+count+' sản phẩm. Hàng cận hạn được cảnh báo.','success');
        return result(true,'Đã kiểm kê '+count+' sản phẩm.');
      }
      case 'HIRE':{
        if(s.staff.length>=4)return result(false,'Cửa hàng đã đủ 4 nhân viên.');
        if(s.level<2)return result(false,'Cần cấp 2 để tuyển thêm người.');
        const newId=s.staff.some(m=>m.id==='linh')?'minh':'linh',fee=450000;
        if(s.cash<fee)return result(false,'Cần 450.000đ để tuyển dụng.');
        const person={id:newId,name:newId==='linh'?'Linh':'Minh',role:'operator',mood:86,energy:96,skill:1,experience:0,task:'Chờ phân công',x:380,y:450,bubble:'',shift:'full',trait:'friendly'};
        s.cash-=fee;s.stats.operatingCosts+=fee;s.staff.push(person);log(s,'👥 Tuyển '+person.name+' vào đội ngũ!','success');
        return result(true,'Đã tuyển '+person.name+'!');
      }
      case 'SET_SHIFT':{
        const member=s.staff.find(m=>m.id===action.staffId);if(!member||!['full','morning','evening'].includes(action.shift))return result(false,'Ca làm việc không hợp lệ.');
        member.shift=action.shift;log(s,'🕒 '+member.name+' nhận ca '+action.shift);return result(true,'Đã phân ca.');
      }
      case 'SET_TRAIT':{
        const member=s.staff.find(m=>m.id===action.staffId);if(!member||!['friendly','efficient','patient'].includes(action.trait))return result(false,'Kỹ năng trọng tâm không hợp lệ.');
        member.trait=action.trait;return result(true,'Đã chọn kỹ năng trọng tâm.');
      }
      case 'MOVE_SHELF':{
        const cat=getCat(id),slot=Number(action.slot);
        if(!cat||cat.unlock>s.storeLevel||!Number.isInteger(slot)||slot<0||slot>=SHELF_SLOTS.length)return result(false,'Vị trí kệ không hợp lệ.');
        if(s.opened)return result(false,'Tạm đóng cửa trước khi đổi bố cục.');
        const occupied=Object.keys(s.layout.shelves).find(k=>k!==id && s.layout.shelves[k]===slot);
        if(occupied&&getCat(occupied).unlock>s.storeLevel)return result(false,'Ô này dành cho khu mở rộng.');
        const old=s.layout.shelves[id];s.layout.shelves[id]=slot;if(occupied)s.layout.shelves[occupied]=old;
        log(s,'🛠️ Đã bố trí lại kệ '+cat.name,'success');return result(true,'Đổi vị trí kệ thành công.');
      }
      case 'PLACE_DECOR':{
        if(!s.decor.includes(id))return result(false,'Cần mua vật phẩm trước khi đặt.');
        const slot=Number(action.slot);if(!Number.isInteger(slot)||slot<0||slot>=8)return result(false,'Vị trí trang trí không hợp lệ.');
        const occupant=Object.keys(s.layout.decor).find(k=>k!==id&&s.layout.decor[k]===slot);
        if(occupant)return result(false,'Ô trang trí đã có đồ vật.');
        s.layout.decor[id]=slot;return result(true,'Đã sắp xếp vật phẩm!');
      }
      case 'SET_ROLE':{
        const member=s.staff.find(x=>x.id===action.staffId);
        if(!member||!ROLES.includes(action.role))return result(false,'Chức vụ không hợp lệ.');
        member.role=action.role;member.autoRest=false;member.task=action.role==='rest'?'Đang nghỉ ngơi':'Đang nhận nhiệm vụ';
        member.bubble='';log(s,'👥 Phân công '+member.name+': '+ROLE_NAMES[action.role]);
        return result(true,'Đã phân công '+member.name+'.');
      }
      case 'SET_PROMO':{
        const cat=getCat(id),rate=Number(action.rate);
        if(!cat || cat.unlock>s.storeLevel || ![0,5,10,15].includes(rate))return result(false,'Khuyến mãi không hợp lệ.');
        s.promo={cat:rate>0?id:null,rate,untilDay:rate>0?s.day+1:0};
        if(rate>0){s.stats.promotions++;log(s,'🏷️ Giảm '+rate+'% '+cat.name+' trong 2 ngày','success');}
        else log(s,'🏷️ Đã tắt khuyến mãi.');
        return result(true,rate>0?'Khuyến mãi đã áp dụng.':'Đã tắt khuyến mãi.');
      }
      case 'BUY_EQUIPMENT':return buyItem(s,EQUIPMENT,id,'equipment');
      case 'BUY_DECOR':return buyItem(s,DECOR,id,'decor');
      case 'CLAIM_MISSION':{
        const mission=MISSIONS.find(x=>x.id===id);
        if(!mission||s.questsClaimed.includes(id))return result(false,'Không có phần thưởng để nhận.');
        if(currentMetric(s,mission.metric)<mission.goal)return result(false,'Bạn chưa hoàn thành nhiệm vụ.');
        s.cash+=mission.reward;s.xp+=mission.xp;s.questsClaimed.push(id);levelUp(s);
        log(s,'🎯 Hoàn thành '+mission.title+' +'+money(mission.reward),'success');
        return result(true,'Nhận '+money(mission.reward)+' và '+mission.xp+' XP!');
      }
      case 'CLAIM_ACHIEVEMENT':{
        const ach=ACHIEVEMENTS.find(x=>x.id===id);
        if(!ach||s.achievementsClaimed.includes(id)||currentMetric(s,ach.metric)<ach.goal)return result(false,'Chưa đủ điều kiện nhận thưởng.');
        s.achievementsClaimed.push(id);s.cash+=ach.reward;
        log(s,'🏆 Thành tựu '+ach.title+' +'+money(ach.reward),'success');
        return result(true,'Đã nhận '+money(ach.reward)+'.');
      }
      case 'STAFF_BONUS':{
        const member=s.staff.find(x=>x.id===action.staffId),bonus=50000;
        if(!member)return result(false,'Không tìm thấy nhân viên.');
        if(s.cash<bonus)return result(false,'Không đủ tiền để thưởng nhân viên.');
        if(member.mood>=98)return result(false,'Nhân viên đang rất vui.');
        s.cash-=bonus;s.stats.wages+=bonus;s.today.wages+=bonus;
        changeMood(member,20);member.energy=clamp(member.energy+5,0,100);
        log(s,'🎁 Thưởng '+money(bonus)+' cho '+member.name+' để động viên làm việc.','success');
        return result(true,'Đã thưởng '+member.name+'!');
      }
      case 'TRAIN':{
        const member=s.staff.find(x=>x.id===action.staffId);const cost=240000;
        if(!member ||member.skill>=5)return result(false,'Nhân viên đã đạt cấp tối đa.');
        if(s.cash<cost)return result(false,'Không đủ tiền đào tạo.');
        s.cash-=cost;s.stats.operatingCosts+=cost;improveSkill(s,member,45*member.skill);
        return result(true,'Đã đào tạo '+member.name+'.');
      }
      case 'EXPAND':{
        if(s.storeLevel>=2)return result(false,'Cửa hàng đã mở rộng trong phiên bản này.');
        if(s.level<2)return result(false,'Cần đạt cấp 2 để mở rộng.');
        if(s.cash<2600000)return result(false,'Cần 2.600.000đ để mở rộng.');
        s.cash-=2600000;s.stats.operatingCosts+=2600000;s.storeLevel=2;s.stats.expanded=1;
        log(s,'🎉 Mở thêm 2 khu vực: Mì gói và Đông lạnh!','success');
        return result(true,'Mở rộng thành công: thêm 2 khu vực bán hàng!');
      }
      case 'PRIORITY':{
        const allowed=['customer','delivery','shelf','clean'];
        if(!allowed.includes(id))return result(false,'Không nhận diện được ưu tiên.');
        s.priority=id;
        log(s,'📋 Ưu tiên vận hành: '+({customer:'Hỗ trợ khách',delivery:'Nhận hàng',shelf:'Bổ sung kệ',clean:'Vệ sinh'}[id]));
        return result(true,'Đã đổi ưu tiên công việc.');
      }
      case 'OPEN':{
        if(s.opened)return result(false,'Cửa hàng đang mở.');
        if(stockTotal(s,'stock')===0)return result(false,'Hãy nhập hàng và bổ sung ít nhất một kệ trước khi mở.');
        s.opened=true;s.everOpened=true;s.stats.opened=1;s.tutorial.phase=Math.max(s.tutorial.phase,3);
        log(s,'🎊 Cửa hàng khai trương! Khách bắt đầu ghé mua.','success');
        return result(true,'Chúc mừng khai trương!');
      }
      case 'CLOSE':{
        if(!s.opened)return result(false,'Cửa hàng đã đóng cửa.');
        s.opened=false;log(s,'🔒 Tạm đóng cửa. Khách còn lại sẽ hoàn tất lượt mua.');
        return result(true,'Cửa hàng tạm đóng.');
      }
      case 'SET_SPEED':{
        if(![1,2,3].includes(Number(action.speed)))return result(false,'Tốc độ không hợp lệ.');
        s.speed=Number(action.speed);return result(true,'Đặt tốc độ ×'+s.speed+'.');
      }
      case 'TOGGLE_PAUSE':s.paused=!s.paused;return result(true,s.paused?'Đã tạm dừng.':'Đã tiếp tục.');
      case 'RENAME':{
        const name=String(action.name||'').trim().slice(0,25);
        if(!name)return result(false,'Tên không được để trống.');
        s.name=name;return result(true,'Đã đổi tên cửa hàng.');
      }
      case 'SETTING':{
        if(!['sound','showNames','quality','renderMode','fpsTarget','lighting','largeText','reducedMotion'].includes(action.key))return result(false,'Cài đặt không hợp lệ.');
        if(action.key==='quality'&&!['auto','high','low'].includes(action.value))return result(false,'Chất lượng không hợp lệ.');
        if(action.key==='renderMode'&&!['illustrated','3d'].includes(action.value))return result(false,'Chế độ vẽ không hợp lệ.');
        if(action.key==='fpsTarget'&&![20,30,45,60].includes(Number(action.value)))return result(false,'Giới hạn khung hình không hợp lệ.');
        if(!['quality','renderMode','fpsTarget'].includes(action.key)&&typeof action.value!=='boolean')return result(false,'Giá trị cài đặt không hợp lệ.');
        s.settings[action.key]=action.key==='fpsTarget'?Number(action.value):action.value;return result(true,'Đã lưu cài đặt.');
      }
      case 'SKIP_TUTORIAL':s.tutorial.hidden=true;return result(true,'Đã ẩn hướng dẫn.');
      case 'RESUME_TUTORIAL':s.tutorial.hidden=false;return result(true,'Đã hiển thị hướng dẫn.');
      default:return result(false,'Chức năng chưa được hỗ trợ.');
    }
  }
  // V18: A* theo ô lối đi, tránh kệ hàng. Hệ thống xử lý trên bản đồ logic 2D.
  // Giả định: x,y tính theo tọa độ ảo như V12; mọi đích cho phép tiếp cận từ các lối đi.
  const OBSTACLES=[[426,240,53,34],[591,217,53,34],[705,299,53,34],[827,358,53,34],
                   [510,337,53,34],[665,396,53,34],[296,382,45,31],[824,171,35,30]];
  const CELL=32,X0=175,Y0=105,WIDTH=25,HEIGHT=15;
  const inBounds=(x,y)=>x>=0&&y>=0&&x<WIDTH&&y<HEIGHT;
  const cell=(x,y)=>[clamp(Math.round((x-X0)/CELL),0,WIDTH-1),clamp(Math.round((y-Y0)/CELL),0,HEIGHT-1)];
  function blocked(ix,iy,goal){if(ix===goal[0]&&iy===goal[1])return false;
    const x=X0+ix*CELL,y=Y0+iy*CELL;
    return OBSTACLES.some(([cx,cy,rx,ry])=>Math.abs(x-cx)<rx&&Math.abs(y-cy)<ry);
  }
  function route(start,goal){const [sx,sy]=cell(...start),[gx,gy]=cell(...goal),startKey=sx+sy*WIDTH,targetKey=gx+gy*WIDTH;
    if(startKey===targetKey)return [goal];
    const open=[startKey],known=new Set(open),prev=new Map(),gScore=new Map([[startKey,0]]);let found=false;
    while(open.length){open.sort((a,b)=>{
      const h=v=>Math.abs(v%WIDTH-gx)+Math.abs(Math.floor(v/WIDTH)-gy);
      return (gScore.get(a)+h(a))-(gScore.get(b)+h(b));});
      const cur=open.shift();known.delete(cur);if(cur===targetKey){found=true;break;}
      const cx=cur%WIDTH,cy=Math.floor(cur/WIDTH);
      for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
        const nx=cx+dx,ny=cy+dy;if(!inBounds(nx,ny)||blocked(nx,ny,[gx,gy]))continue;
        const key=nx+ny*WIDTH,nd=gScore.get(cur)+1;
        if(nd<(gScore.get(key)??Infinity)){prev.set(key,cur);gScore.set(key,nd);if(!known.has(key)){known.add(key);open.push(key);}}
      }
    }
    if(!found)return [goal];
    const reverse=[];let cur=targetKey,limit=WIDTH*HEIGHT;
    while(cur!==startKey&&limit-->0){reverse.push([X0+(cur%WIDTH)*CELL,Y0+Math.floor(cur/WIDTH)*CELL]);cur=prev.get(cur);if(cur===undefined)return [goal];}
    reverse.reverse();reverse.push(goal);return reverse;
  }
  function moveToward(entity,x,y,step){
    const finalDistance=Math.hypot(x-entity.x,y-entity.y);
    if(finalDistance<4){entity.x=x;entity.y=y;entity._route=[];return true;}
    const key=Math.round(x/12)+':'+Math.round(y/12);
    if(entity._routeTarget!==key||!Array.isArray(entity._route)||entity._route.length===0){
      entity._routeTarget=key;entity._route=route([entity.x,entity.y],[x,y]);
    }
    let left=step;
    while(left>0&&entity._route.length){
      const point=entity._route[0],dx=point[0]-entity.x,dy=point[1]-entity.y,d=Math.hypot(dx,dy);
      if(d<=left){entity.x=point[0];entity.y=point[1];left-=d;entity._route.shift();}
      else{entity.x+=dx/d*left;entity.y+=dy/d*left;left=0;}
    }
    if(Math.hypot(x-entity.x,y-entity.y)<4){entity.x=x;entity.y=y;entity._route=[];return true;}
    return false;
  }
  function addCustomer(s,rng){
    const choices=activeCats(s);
    const cat=weightedChoice(choices,c=>1+(promoActive(s,c.id)?1.5:0)+(s.stock[c.id]>0?.2:0),rng);
    const styles=['#60bce0','#ffc562','#a58aec','#f490a4','#76cb98','#fd995a'];
    s.customers.push({id:randId('c',s),cat:cat.id,x:498,y:554,stage:'browse',patience:14+Math.floor(rng()*12),mood:65+Math.floor(rng()*30),
      wait:1,bag:[],bagLots:[],personality:['kiên nhẫn','vội vàng','săn ưu đãi'][Math.floor(rng()*3)],budget:20000+Math.floor(rng()*7)*10000,skin:['#eab28d','#ffd2ae','#c88e6f'][Math.floor(rng()*3)],shirt:styles[Math.floor(rng()*styles.length)],
      hair:['#3d302d','#79513d','#453c59'][Math.floor(rng()*3)],thought:'Tìm '+cat.name,shoppingChance:rng()});
    s.stats.visitors++;
  }
  function customerLeaves(s,c,reason){
    c.stage='leave';c.thought=reason==='happy'?'Cảm ơn! 😊':'Tiếc quá 😞';
    if(reason!=='happy'){
      if(c.bag.length){for(const [index,id] of c.bag.entries()){
        s.stock[id]++;
        const age=c.bagLots?.[index];if(age&&FRESH_LIFE[id])pushLot(s,'stock',id,1,age);
      }c.bag=[];c.bagLots=[];}
      addReview(s,c,Math.max(1,Math.round(c.mood/28)),reason);
      s.stats.missed++;s.today.missed++;s.customerCare.complaints++;s.reputation=clamp(s.reputation-1.35,0,100);
      if(s.stats.missed<=5||s.stats.missed%5===0)log(s,'😞 Khách bỏ về: '+(reason==='wait'?'chờ thanh toán lâu':'không tìm thấy hàng'),'warn');
    }
  }
  function actOperator(s,op){
    if(op.energy<13){op.task='Mệt, cần nghỉ giải lao';op.bubble='😓';changeMood(op,-.16);return;}
    const help=s.customers.find(c=>c.stage==='needHelp');
    const arrived=s.pending.find(p=>p.arrived&&p.received<p.qty);
    let low=activeCats(s).filter(c=>s.warehouse[c.id]>0&&s.stock[c.id]<shelfCapacity(s,c.id))
      .sort((a,b)=>(s.stock[a.id]/shelfCapacity(s,a.id))-(s.stock[b.id]/shelfCapacity(s,b.id)))[0];
    const needsClean=s.cleanliness<80;
    const emphasis=s.priority||'customer';
    const urgency={help:help?85+(20-Math.min(help.patience,20))*3+(emphasis==='customer'?25:0):-1,
      delivery:arrived?80+(emphasis==='delivery'?28:0):-1,
      shelf:low?58+Math.round((1-s.stock[low.id]/shelfCapacity(s,low.id))*35)+(emphasis==='shelf'?22:0):-1,
      clean:needsClean?45+(80-s.cleanliness)*1.3+(emphasis==='clean'?22:0):-1};
    const decision=Object.entries(urgency).sort((a,b)=>b[1]-a[1])[0][0];
    if(decision==='help'&&help){
      op.task='Hỗ trợ khách tìm '+getCat(help.cat).name;op.bubble='💬 Hỗ trợ khách';
      if(moveToward(op,help.x-26,help.y+16,105+(op.trait==='efficient'?12:0))){
        if(s.stock[help.cat]>0){help.stage='browse';help.wait=0;help.patience+=7+(op.trait==='patient'?4:0);help.mood=clamp(help.mood+12+(op.trait==='friendly'?3:0),0,100);help.thought='Đã tìm được!';}
        else if(s.warehouse[help.cat]>0){
          const n=Math.min(8+(s.equipment.includes('cart')?8:0),s.warehouse[help.cat],shelfCapacity(s,help.cat)-s.stock[help.cat]);
          shiftFresh(s,help.cat,n);s.warehouse[help.cat]-=n;s.stock[help.cat]+=n;s.stats.restocked+=n;help.stage='browse';help.wait=0;
          help.patience+=6;help.mood=clamp(help.mood+14,0,100);help.thought='Có hàng rồi! 😊';
          log(s,'💬 '+op.name+' hỗ trợ khách và bổ sung '+getCat(help.cat).name,'success');
        }else{
          const alt=activeCats(s).find(c=>s.stock[c.id]>0&&c.id!==help.cat);
          if(alt && help.shoppingChance>.34){help.cat=alt.id;help.stage='browse';help.wait=0;help.thought='Thử '+alt.name;}
          else{help.mood=clamp(help.mood-20,0,100);customerLeaves(s,help,'out');}
        }
        op.energy=clamp(op.energy-1.7,0,100);changeMood(op,.38);improveSkill(s,op,2);
      }
    } else if(decision==='delivery'&&arrived){
      op.task='Nhận hàng từ nhà cung cấp';op.bubble='📦 Nhận hàng';
      if(moveToward(op,824,171,100)){
        const n=Math.min(12+(s.equipment.includes('cart')?8:0),arrived.qty-arrived.received,
          warehouseCapacity(s)-stockTotal(s,'warehouse'));
        if(n>0){s.warehouse[arrived.cat]+=n;pushLot(s,'warehouse',arrived.cat,n);s.freshDay[arrived.cat]=s.day;arrived.received+=n;op.energy=clamp(op.energy-1.6,0,100);
          if(arrived.received===arrived.qty)log(s,'✅ '+op.name+' nhận đủ '+arrived.qty+' '+getCat(arrived.cat).name,'success');
        }
        if(n<=0)op.task='Kho đã đầy';
      }
    } else if(decision==='shelf'&&low){
      op.task='Bổ sung kệ '+low.name;op.bubble='🛒 Lên kệ';
      if(moveToward(op,categoryPos(s,low)[0]+30,categoryPos(s,low)[1]+66,105+(op.trait==='efficient'?12:0))){
        const n=Math.min(7+(s.equipment.includes('cart')?8:0)+op.skill*2,s.warehouse[low.id],shelfCapacity(s,low.id)-s.stock[low.id]);
        if(n>0){shiftFresh(s,low.id,n);s.warehouse[low.id]-=n;s.stock[low.id]+=n;s.stats.restocked+=n;
          op.energy=clamp(op.energy-1.2,0,100);improveSkill(s,op,1);
          if(s.stats.restocked<=20||s.stats.restocked%30===0)log(s,'🛒 '+op.name+' bổ sung '+n+' '+low.name);
        }
      }
    } else if(decision==='clean'&&needsClean){
      op.task='Vệ sinh cửa hàng';op.bubble='🧹 Vệ sinh';
      if(moveToward(op,650,465,105)){
        s.cleanliness=clamp(s.cleanliness+16,0,100);s.stats.cleaned++;
        op.energy=clamp(op.energy-2.1,0,100);changeMood(op,.5);improveSkill(s,op,1);
        if(s.stats.cleaned<=4)log(s,'🧹 '+op.name+' đã vệ sinh khu vực bán hàng.');
      }
    } else {op.task='Kiểm tra hình ảnh cửa hàng';op.bubble='✅ Kiểm tra';
      moveToward(op,745,438,65);op.energy=clamp(op.energy+.06,0,100);}
  }
  function actCashier(s,cashier,rng){
    if(cashier.energy<12){cashier.task='Mệt, cần nghỉ giải lao';cashier.bubble='😓';changeMood(cashier,-.3);return;}
    const waiting=s.customers.filter(c=>c.stage==='queue' && Math.hypot(c.x-285,c.y-425)<120).sort((a,b)=>a.patience-b.patience);
    if(waiting.length){
      cashier.task='Ưu tiên '+waiting.length+' khách chờ thanh toán';cashier.bubble='💳 Thanh toán';
      moveToward(cashier,300,369,120);
      const target=waiting[0];
      const faster=(s.equipment.includes('scanner')?1:0)+(s.equipment.includes('pos')?1:0)+(cashier.skill>=3?1:0)+(cashier.trait==='efficient'?.5:0);
      s.runtime.cashierTimer+=1+faster*.55;
      if(s.runtime.cashierTimer >= (s.equipment.includes('pos')?1.7:3.2)){
        s.runtime.cashierTimer=0;
        let bill=0,cogs=0;const soldItems=[...target.bag];
        for(const id of target.bag){const cat=getCat(id);bill+=Math.round(cat.price*(1-activeDiscount(s,id)/100));cogs+=cat.cost;}
        // Advice / upsell: only when another promotion is running and stock is available.
        const promoCat=s.promo.cat;
        if(promoCat && promoActive(s,promoCat) && s.stock[promoCat]>0 && target.budget>=bill+Math.round(getCat(promoCat).price*(1-s.promo.rate/100)) && rng()<(.17+cashier.skill*.065+(target.personality==='săn ưu đãi'?.2:0)+(cashier.trait==='friendly'?.07:0))){
          s.stock[promoCat]--;takeLot(s,'stock',promoCat,1);soldItems.push(promoCat);const p=getCat(promoCat);bill+=Math.round(p.price*(1-s.promo.rate/100));cogs+=p.cost;
          cashier.bubble='🏷️ Tư vấn KM';target.thought='Được tư vấn giảm giá!';target.mood=clamp(target.mood+9,0,100);
          log(s,'🏷️ '+cashier.name+' tư vấn '+p.name+' giảm '+s.promo.rate+'%','success');
        }
        s.cash+=bill;s.stats.revenue+=bill;s.stats.cogs+=cogs;s.stats.served++;
        s.today.revenue+=bill;s.today.cogs+=cogs;s.today.served++;
        s.reputation=clamp(s.reputation+(target.patience>6?.34:.1),0,100);
        if(target.mood>=60&&target.patience>5){s.stats.happy++;changeMood(cashier,.36);}else changeMood(cashier,-.12);
        cashier.energy=clamp(cashier.energy-1.35,0,100);improveSkill(s,cashier,2);
        addReview(s,target,target.mood>=75?5:target.mood>=55?4:3,'happy');
        s.receipts.unshift({day:s.day,time:s.minutes,customer:target.personality,qty:soldItems.length,items:soldItems,bill,cogs,discount:s.promo.rate||0,stars:target.mood>=75?5:target.mood>=55?4:3});
        if(s.receipts.length>40)s.receipts.length=40;
        s.customerCare.loyalty+=target.mood>=78?1:0;
        target.bag=[];target.bagLots=[];customerLeaves(s,target,'happy');s.xp+=4;levelUp(s);
        if(s.stats.served<=5||s.stats.served%10===0)log(s,'🧾 Đơn #'+s.stats.served+' · '+money(bill)+' · khách hài lòng','success');
        s.effects.push({id:randId('e',s),text:'+'+money(bill),x:330,y:294,until:s.elapsed+3});
      }
    }else{
      cashier.task='Chào khách và giới thiệu ưu đãi';cashier.bubble=promoActive(s,s.promo.cat)?'🏷️ KM '+s.promo.rate+'%':'😊 Xin chào!';
      s.runtime.cashierTimer=0;moveToward(cashier,300,369,100);cashier.energy=clamp(cashier.energy+.14,0,100);
    }
  }
  function endDay(s){
    const wage=95000*s.staff.length;
    const utilities=42000+(s.storeLevel-1)*18000;
    s.cash=Math.max(0,s.cash-wage-utilities);
    s.stats.wages+=wage;s.stats.utilities+=utilities;s.today.wages+=wage;s.today.utilities+=utilities;
    // V21: tuổi hàng được kiểm tra khi chuyển sang ngày mới.
    const net=s.today.revenue-s.today.cogs-s.today.wages-s.today.utilities-(s.today.wasteCost||0);
    s.history.unshift({day:s.day,revenue:s.today.revenue,cogs:s.today.cogs,served:s.today.served,missed:s.today.missed,wages:s.today.wages,utilities:s.today.utilities,wasteCost:s.today.wasteCost||0,net});
    if(s.history.length>20)s.history.length=20;
    log(s,'📊 Kết thúc ngày '+s.day+': DT '+money(s.today.revenue)+' · LN '+money(net),'info');
    s.day++;s.minutes=8*60;s.eventClock.lastRushHour=0;
    s.dailyClaimed=s.dailyClaimed.filter(k=>k.startsWith(s.day+':')); s.today={revenue:0,cogs:0,served:0,missed:0,wages:0,utilities:0,wasteCost:0};
    checkFresh(s);
    s.cleanliness=clamp(s.cleanliness+6,0,100);
    s.staff.forEach(m=>{m.energy=clamp(m.energy+30,0,100);changeMood(m,10);});
    if(s.promo.untilDay<s.day)s.promo={cat:null,rate:0,untilDay:0};
    // Automatic overnight closing avoids endless customers after hours.
    if(s.opened){log(s,'🌄 Ngày '+s.day+' bắt đầu. Cửa hàng tự mở cửa.','success');}
  }
  function advance(s,rng=Math.random){
    if(s.paused)return s;
    s.elapsed++;s.minutes+=2;
    if(s.minutes>=22*60)endDay(s);
    // Deliveries are only counted into warehouse after operator acknowledges them.
    s.pending.forEach(p=>{if(!p.arrived && s.elapsed>=p.arrivesAt){p.arrived=true;log(s,'🚚 Xe chở '+getCat(p.cat).name+' đã đến! Chờ nhân viên nhận hàng.');}});
    s.pending=s.pending.filter(p=>p.received<p.qty);
    for(const m of s.staff){
      if(m.role==='rest'){
        m.task='Nghỉ giải lao';m.bubble='☕ Nghỉ ngơi';m.energy=clamp(m.energy+3.8,0,100);changeMood(m,.55);
        moveToward(m,382+m.id.length*20,470,100);
      }else{
        // Tạm nghỉ tự động khi kiệt sức, tự quay lại vị trí được phân công sau khi hồi phục.
        if(!onShift(s,m)){m.task='Ngoài giờ làm';m.bubble='🌙 Hết ca';m.energy=clamp(m.energy+1.5,0,100);changeMood(m,.1);continue;}
        if(m.energy<14)m.autoRest=true;
        if(m.autoRest){m.task='Nghỉ hồi sức';m.bubble='☕ Hồi sức';m.energy=clamp(m.energy+2.4,0,100);changeMood(m,.2);
          if(m.energy>=42){m.autoRest=false;m.task='Quay lại vị trí';}}
      }
    }
    const operators=s.staff.filter(m=>m.role==='operator'&&!m.autoRest&&m.energy>8&&onShift(s,m));
    operators.forEach(op=>actOperator(s,op));
    const cashiers=s.staff.filter(m=>m.role==='cashier'&&!m.autoRest&&m.energy>8&&onShift(s,m));
    cashiers.forEach(cashier=>actCashier(s,cashier,rng));
    // Periodic visitors: reputation, promotions and decoration influence arrivals.
    if(s.opened){
      s.runtime.spawnIn--;
      // Giờ cao điểm đúng 12:00 và 18:00 (mỗi ngày tối đa 2 đợt).
      const hour=Math.floor(s.minutes/60);
      if((hour===12||hour===18)&&s.eventClock.lastRushHour!==hour){
        s.eventClock.lastRushHour=hour;s.eventClock.lastRushDay=s.day;
        s.runtime.spawnIn=1;log(s,'📣 Giờ cao điểm '+hour+':00 — khách sẽ đến đông hơn!','info');
      }
      if(s.runtime.spawnIn<=0 && s.customers.filter(c=>c.stage!=='leave').length<10){
        addCustomer(s,rng);
        const appeal=s.decor.reduce((a,id)=>a+(DECOR.find(x=>x.id===id)?.appeal||0),0);
        const base=11-Math.floor(s.reputation/26)-Math.floor(appeal/7)-(s.promo.rate?1:0);
        s.runtime.spawnIn=clamp(base+Math.floor(rng()*4),3,14);
      }
    }
    for(const c of s.customers){
      if(c.stage==='browse'){
        const cat=getCat(c.cat),pos=categoryPos(s,cat);const reached=moveToward(c,pos[0]+32,pos[1]+66,86);
        if(reached){
          c.wait--;
          if(c.wait<=0){
            if(s.stock[c.cat]>0){
              const wanted=(c.shoppingChance>.76 && s.stock[c.cat]>=2 && c.budget>=getCat(c.cat).price*2)?2:1;
              for(let n=0;n<wanted;n++){
                if(s.stock[c.cat]<=0)break;
                s.stock[c.cat]--;c.bag.push(c.cat);
                const age=takeLot(s,'stock',c.cat,1)[0];c.bagLots??=[];c.bagLots.push(age?.day||s.day);
              }
              c.stage='queue';c.mood=clamp(c.mood+5,0,100);c.patience=15+Math.floor(rng()*8);c.thought='Đến thanh toán';
            }else{c.stage='needHelp';c.patience+=3;c.thought='Không thấy '+cat.name+'!';}
          }
        }
      }else if(c.stage==='needHelp'){
        c.patience--;c.mood=clamp(c.mood-1.5,0,100);
        if(c.patience<=0)customerLeaves(s,c,'out');
      }else if(c.stage==='queue'){
        moveToward(c,235+((s.customers.indexOf(c)%3)*25),415+((s.customers.indexOf(c)%3)*24),85);
        c.patience-=c.personality==='vội vàng'?2:1;c.mood=clamp(c.mood-(c.personality==='vội vàng'?1.4:.7),0,100);
        if(c.patience<=0)customerLeaves(s,c,'wait');
      }else if(c.stage==='leave')moveToward(c,497,553,115);
    }
    s.customers=s.customers.filter(c=>c.stage!=='leave'||Math.hypot(c.x-497,c.y-553)>8);
    s.cleanliness=clamp(s.cleanliness-(s.opened?.23:.045)-(s.customers.length*.016),8,100);
    if(s.cleanliness<40 && s.elapsed%8===0)s.reputation=clamp(s.reputation-.4,0,100);
    s.effects=s.effects.filter(x=>x.until>s.elapsed);
    if(s.elapsed%15===0){
      for(const m of s.staff)if(m.role!=='rest'){
        if(m.energy<40)changeMood(m,-.7);else changeMood(m,.1);
      }
    }
    return s;
  }
  function nextTip(s){
    if(s.stats.ordered<24)return {title:'1. Nhập hàng đầu tiên',text:'Chạm 📦 Đặt hàng, mua ít nhất 24 sản phẩm.',panel:'order'};
    if(s.pending.length || stockTotal(s,'warehouse')>0 || stockTotal(s,'stock')===0){
      if(stockTotal(s,'stock')<16)return {title:'2. Chờ Bình lên kệ',text:'Nhân viên vận hành sẽ nhận hàng và tự bổ sung kệ. Chạm Nhân sự để xem nhiệm vụ.',panel:'staff'};
    }
    if(!s.everOpened)return {title:'3. Khai trương',text:'Kệ đã có hàng. Chạm nút KHAI TRƯƠNG để đón khách!',panel:'store'};
    if(s.stats.served<5)return {title:'4. Đón khách đầu tiên',text:'An tự thu ngân, Bình hỗ trợ khách và lên kệ. Thử cài khuyến mãi để tăng sức mua.',panel:'promo'};
    return {title:'🎉 Bạn đã làm chủ cửa hàng!',text:'Hoàn thành nhiệm vụ, mua trang thiết bị và mở rộng để phát triển kinh doanh.',panel:'missions'};
  }
  function inventoryAudit(s){
    return activeCats(s).map(c=>({id:c.id,name:c.name,shelf:s.stock[c.id],warehouse:s.warehouse[c.id],
      shelfCap:shelfCapacity(s,c.id),cost:c.cost,stockValue:(s.stock[c.id]+s.warehouse[c.id])*c.cost,
      batches:FRESH_LIFE[c.id]?[...s.lots.stock[c.id].map(l=>({...l,area:'Kệ'})),...s.lots.warehouse[c.id].map(l=>({...l,area:'Kho'}))].sort((a,b)=>a.day-b.day):[]}));
  }
  const dailyNet=s=>s.today.revenue-s.today.cogs-s.today.wages-s.today.utilities-(s.today.wasteCost||0);
  return {VERSION,BUILD,START_CASH,SHELF_SLOTS,categoryPos,CATEGORIES,EQUIPMENT,DECOR,MISSIONS,ACHIEVEMENTS,DAILY_TASKS,activeDailyTasks,dailyValue,ROLES,ROLE_NAMES,
    createGame,normalizeSave,dispatch,advance,activeCats,stockTotal,shelfCapacity,warehouseCapacity,
    availableRoom,activeDiscount,promoActive,currentMetric,nextTip,dailyNet,inventoryAudit,money,clamp,reputation};
});
