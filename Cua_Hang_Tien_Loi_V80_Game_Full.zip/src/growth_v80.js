/*
 * CỬA HÀNG TIỆN LỢI — V76–V80: Diện tích & tuyển dụng.
 * GIẢ ĐỊNH: chơi đơn, VNĐ ảo; bốn khu là khởi đầu, tối đa 10 ngành hàng và 8 nhân viên.
 * Cấp khu 2 giữ đúng giá/điều kiện V75 để bản lưu cũ không mất quyền lợi.
 * Mỗi khu mở thêm 2 kệ; chỉ xây khi cửa hàng đóng; không hoàn tiền cho khoản đầu tư.
 * Sử dụng kho ngành hàng V75; đây KHÔNG phải mô phỏng SKU riêng lẻ.
 */
(function(root,factory){
 const E=root.StoreEngine||(typeof module!=='undefined'?require('./engine.js'):null);
 if(!E)throw Error('Growth module requires engine.js');
 const api=factory(E,root);
 root.StoreGrowth=api;
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(E,root){
 'use strict';
 const STAGE=Math.min(80,Math.max(76,Number(root.STORE_GROWTH_STAGE)||80));
 const TIERS=[
  {tier:1,label:'Tiệm khởi nghiệp',icon:'🏪',area:64,shelves:4,level:1,cost:0},
  {tier:2,label:'Gian hàng mở rộng',icon:'🏬',area:96,shelves:6,level:2,cost:2600000},
  {tier:3,label:'Siêu thị mini',icon:'🏗️',area:144,shelves:8,level:4,cost:4800000},
  {tier:4,label:'Trung tâm tiện lợi',icon:'🌟',area:192,shelves:10,level:6,cost:8200000}
 ];
 const EXTRA_CATS=[
  {id:'personal',name:'Chăm sóc cá nhân',icon:'🧴',cost:17000,price:29000,color:'#c49be9',pos:[1025,305],unlock:3},
  {id:'home',name:'Gia dụng',icon:'🧻',cost:13000,price:24000,color:'#80b9d5',pos:[1050,402],unlock:3},
  {id:'coffee',name:'Cà phê',icon:'☕',cost:13000,price:25000,color:'#b89c77',pos:[223,464],unlock:4},
  {id:'ready',name:'Ăn nhanh',icon:'🥪',cost:17000,price:31000,color:'#f89c80',pos:[896,518],unlock:4}
 ];
 const EXTRA_POS=[[1025,305],[1050,402],[223,464],[896,518]];
 const NEW_MERCH=[
  {id:'shampoo',cat:'personal',name:'Dầu gội',icon:'🧴',kind:'shampoo'},
  {id:'soap',cat:'personal',name:'Sữa tắm',icon:'🧼',kind:'soap'},
  {id:'toothpaste',cat:'personal',name:'Kem đánh răng',icon:'🪥',kind:'toothpaste'},
  {id:'tissue',cat:'home',name:'Giấy vệ sinh',icon:'🧻',kind:'tissue'},
  {id:'detergent',cat:'home',name:'Nước giặt',icon:'🧺',kind:'detergent'},
  {id:'cleaner',cat:'home',name:'Nước lau sàn',icon:'🫧',kind:'cleaner'},
  {id:'latte',cat:'coffee',name:'Cà phê sữa',icon:'☕',kind:'latte'},
  {id:'blackcoffee',cat:'coffee',name:'Cà phê đen',icon:'🥤',kind:'blackcoffee'},
  {id:'cappuccino',cat:'coffee',name:'Cappuccino',icon:'🍵',kind:'cappuccino'},
  {id:'sandwich',cat:'ready',name:'Bánh sandwich',icon:'🥪',kind:'sandwich'},
  {id:'riceball',cat:'ready',name:'Cơm nắm',icon:'🍙',kind:'riceball'},
  {id:'salad',cat:'ready',name:'Salad hộp',icon:'🥗',kind:'salad'}
 ];
 const SKUS=E.COMMERCE_CATALOG||[];
 for(const sku of NEW_MERCH){
   if(!E.CATEGORIES.some(c=>c.id===sku.cat)||SKUS.some(x=>x.id===sku.id))continue;
   SKUS.push(sku);
 }

 for(const cat of EXTRA_CATS){if((cat.unlock===3&&STAGE>=76)||(cat.unlock===4&&STAGE>=78)){
   if(!E.CATEGORIES.find(x=>x.id===cat.id))E.CATEGORIES.push(cat);
 }}
 for(let i=0;i<EXTRA_POS.length;i++)if(!E.SHELF_SLOTS[i+6])E.SHELF_SLOTS.push(EXTRA_POS[i]);
 const ROSTER=[
  {id:'an',name:'An',specialty:'Thu ngân'},
  {id:'binh',name:'Bình',specialty:'Vận hành'},
  {id:'linh',name:'Linh',specialty:'Tư vấn'},
  {id:'minh',name:'Minh',specialty:'Bổ sung hàng'},
  {id:'thao',name:'Thảo',specialty:'Chăm sóc khách'},
  {id:'phuc',name:'Phúc',specialty:'Nhận hàng'},
  {id:'ha',name:'Hà',specialty:'Thu ngân nhanh'},
  {id:'tu',name:'Tú',specialty:'Trưng bày'}
 ];
 const VALID_IDS=new Set(ROSTER.map(x=>x.id));
 const money=E.money;
 const limitAt=tier=>tier<=1?2:tier===2?4:tier===3?(STAGE>=77?6:4):(STAGE>=79?8:6);
 const staffLimit=s=>limitAt(s.storeLevel);
 const hireCost=s=>s.staff.length<4?450000:s.staff.length<6?650000:800000;
 const area=s=>(TIERS[Math.min(Math.max(Math.floor(s.storeLevel||1),1),4)-1]?.area)||64;
 const nextTier=s=>TIERS.find(x=>x.tier===s.storeLevel+1&&((x.tier<=3&&STAGE>=76)||(x.tier===4&&STAGE>=78)))||null;
 const number=(v,min,max,d)=>Number.isFinite(Number(v))?E.clamp(Number(v),min,max):d;
 const int=(v,min,max,d)=>Math.floor(number(v,min,max,d));
 function normalizeRoster(raw,base){
  if(!Array.isArray(raw))return base;
  const valid=[];
  for(const p of raw){
   if(!p||!VALID_IDS.has(p.id)||valid.some(m=>m.id===p.id))continue;
   const ref=ROSTER.find(x=>x.id===p.id);
   valid.push({id:p.id,name:ref.name,role:E.ROLES.includes(p.role)?p.role:(p.id==='an'?'cashier':'operator'),
      mood:number(p.mood,5,100,88),energy:number(p.energy,0,100,90),
      skill:int(p.skill,1,5,1),experience:int(p.experience,0,999,0),
      task:String(p.task||'Chờ phân công').slice(0,55),
      x:number(p.x,0,1180,ref.id==='an'?296:770),y:number(p.y,0,580,ref.id==='an'?382:210),
      bubble:String(p.bubble||'').slice(0,60),shift:['full','morning','evening'].includes(p.shift)?p.shift:'full',
      trait:['friendly','efficient','patient'].includes(p.trait)?p.trait:'friendly',autoRest:!!p.autoRest});
  }
  if(valid.length<2||valid.length>8||!valid.some(m=>m.id==='an')||!valid.some(m=>m.id==='binh'))return base;
  // Tránh tạo nhân viên miễn phí qua bản lưu. Chỉ giữ số nhân sự phù hợp số khu đã mở.
  return valid.slice(0,8);
 }
 function hydrate(s,raw){
  s.storeLevel=int(s.storeLevel,1,4,1);
  if(!s.layout||typeof s.layout!=='object')s.layout={shelves:{},decor:{}};
  s.layout.shelves??={};s.layout.decor??={};
  const assigned=new Set();
  for(let index=0;index<E.CATEGORIES.length;index++){
   const c=E.CATEGORIES[index];let slot=Number(s.layout.shelves[c.id]);
   if(!Number.isInteger(slot)||slot<0||slot>=E.SHELF_SLOTS.length||assigned.has(slot))slot=Array.from({length:E.SHELF_SLOTS.length},(_,i)=>i).find(i=>!assigned.has(i));
   s.layout.shelves[c.id]=slot;assigned.add(slot);
   if(!Number.isInteger(s.stock[c.id]))s.stock[c.id]=0;
   if(!Number.isInteger(s.warehouse[c.id]))s.warehouse[c.id]=0;
  }
  s.growth={
   expansionCount:Math.max(0,s.storeLevel-1),
   records:Array.isArray((raw||s).growth?.records)?(raw||s).growth.records.filter(r=>r&&Number.isInteger(r.tier)&&r.tier>=2&&r.tier<=4&&Number.isFinite(r.cost)&&r.cost>=0).slice(-3):[]
  };
  s.stats.hires=Math.max(int(s.stats.hires,0,8,0),Math.max(0,s.staff.length-2));
  s.staffLimit=staffLimit(s);
  return s;
 }
 const baseCreate=E.createGame,baseNormalize=E.normalizeSave,baseDispatch=E.dispatch,baseAdvance=E.advance;
 E.createGame=function(){return hydrate(baseCreate());};
 E.normalizeSave=function(saved){
  const result=baseNormalize(saved);
  if(saved&&typeof saved==='object'&&Array.isArray(saved.staff)&&saved.staff.length>4){
    result.staff=normalizeRoster(saved.staff,result.staff);
  }
  // Unlocked expansion of a preexisting newer save must remain even if the stage is reloaded.
  return hydrate(result,saved);
 };
 function log(s,message){s.log.unshift({id:'growth-'+s.elapsed+'-'+s.serial++,text:message,type:'success',at:s.elapsed});s.log=s.log.slice(0,70);}
 E.dispatch=function(s,a){
  hydrate(s);
  if(a?.type==='EXPAND'){
    const next=nextTier(s);
    if(!next)return {ok:false,message:'Bạn đã mở toàn bộ diện tích hiện có.'};
    if(s.opened)return {ok:false,message:'Hãy đóng cửa trước khi sửa chữa và mở rộng.'};
    if(s.level<next.level)return {ok:false,message:'Cần đạt cấp quản lý '+next.level+' để mở khu mới.'};
    if(s.cash<next.cost)return {ok:false,message:'Cần '+money(next.cost)+' để xây dựng.'};
    // Keep legacy level-2 action in the original engine to preserve older quest counters.
    if(next.tier===2){const r=baseDispatch(s,a);if(r.ok)hydrate(s);return r;}
    E.financeAudit?.(s); // Fix opening balance before a new growth investment.
    s.cash-=next.cost;s.stats.operatingCosts+=next.cost;s.storeLevel=next.tier;
    s.stats.expanded=Math.max(s.stats.expanded,next.tier-1);
    hydrate(s);s.growth.records.push({tier:next.tier,day:s.day,cost:next.cost});
    const justOpened=E.CATEGORIES.filter(c=>c.unlock===next.tier).map(c=>c.name).join(' và ');
    E.recordFinancialChange?.(s,'EXPAND',-next.cost,'Mở rộng cấp '+next.tier);
    log(s,'🏗️ Đã mở rộng lên '+next.area+'m²! Mở khóa '+justOpened);
    return{ok:true,message:'Đã mở khu mới '+next.area+'m²! Thêm 2 kệ: '+justOpened+'.'};
  }
  if(a?.type==='HIRE'){
    const cap=staffLimit(s);
    if(s.staff.length>=cap)return{ok:false,message:'Đã đủ '+cap+' nhân viên. Hãy mở rộng để tuyển thêm.'};
    const fee=hireCost(s);
    if(s.cash<fee)return{ok:false,message:'Cần '+money(fee)+' để tuyển dụng.'};
    // Preserve level-2 legacy hires (Linh, Minh) from the original dispatch.
    if(s.staff.length<4){const r=baseDispatch(s,a);if(r.ok){s.stats.hires=(s.stats.hires||0)+1;}return r;}
    const choice=ROSTER[s.staff.length];
    if(!choice)return{ok:false,message:'Không có ứng viên phù hợp.'};
    const member={id:choice.id,name:choice.name,role:s.staff.filter(m=>m.role==='cashier').length<2?'cashier':'operator',
      mood:86,energy:95,skill:1,experience:0,task:'Chờ giao công việc',
      x:430+(s.staff.length%3)*95,y:340+(s.staff.length%2)*65,bubble:'',shift:'full',trait:'friendly'};
    E.financeAudit?.(s);
    s.cash-=fee;s.stats.operatingCosts+=fee;s.stats.hires=(s.stats.hires||0)+1;s.staff.push(member);
    E.recordFinancialChange?.(s,'HIRE',-fee,'Tuyển '+choice.name);
    log(s,'👥 Đã tuyển '+choice.name+' — '+choice.specialty+' ('+money(fee)+')');
    return {ok:true,message:'Chào mừng '+choice.name+'! Vào Nhân sự để phân công.'};
  }
  return baseDispatch(s,a);
 };
 E.advance=function(s,rng){hydrate(s);return baseAdvance(s,rng);};
 // Commerce from V75 stores price by category and its hydrate is applied on load; extend it to new areas.
 if(E.COMMERCE_CATALOG?.length){
   // Optional compatibility helper; the shipping commerce.js still keeps its original catalog.
 }
 if(STAGE>=76&&Array.isArray(E.MISSIONS)){
   for(const mission of [
    {id:'area3',title:'🏗️ Xây khu siêu thị mini',desc:'Nâng cấp diện tích lên 144m².',metric:'expanded',goal:2,reward:360000,xp:90},
    {id:'area4',title:'🌟 Trung tâm tiện lợi',desc:'Nâng cấp diện tích lên 192m².',metric:'expanded',goal:3,reward:650000,xp:160},
    {id:'team4',title:'👥 Đội ngũ đông vui',desc:'Tuyển được 4 nhân viên mới.',metric:'hires',goal:4,reward:240000,xp:80}
   ]){if(!E.MISSIONS.some(m=>m.id===mission.id))E.MISSIONS.push(mission);}
 }
 Object.assign(E,{
   GROWTH_STAGE:STAGE,GROWTH_TIERS:TIERS,GROWTH_ROSTER:ROSTER,
   growthStaffLimit:staffLimit,growthStaffLimitAt:limitAt,
   growthHireCost:hireCost,growthArea:area,nextGrowthTier:nextTier,growthHydrate:hydrate
 });
 return {STAGE,TIERS,ROSTER,EXTRA_CATS,hydrate,staffLimit,hireCost,nextTier};
});
