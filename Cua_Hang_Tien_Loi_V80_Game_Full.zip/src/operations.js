/*
 * CỬA HÀNG TIỆN LỢI — V49–V54, CORE OPERATIONS
 * Giả định:
 * - Chơi đơn offline, mọi tiền và doanh thu đều là tiền ảo, không có giao dịch thật.
 * - Giữ StoreEngine.VERSION=12 và khóa lưu V12 để đọc tiến độ người chơi V48.
 * - Không thay đổi giá, luật khai trương hay cơ chế NPC hiện có.
 * - Chỉ bảo đảm tính nhất quán của giao dịch từ lúc nâng cấp; dữ liệu lịch sử cũ
 *   được làm mốc kế toán, KHÔNG dựng ra giao dịch đã xảy ra trước đó.
 * - Dự báo dựa trên bán hàng mô phỏng, không dùng AI ngôn ngữ hoặc API online.
 */
(function(root,factory){
  const E=root.StoreEngine||(typeof module!=='undefined'?require('./engine.js'):null);
  if(!E)throw Error('Cần nạp engine.js trước operations.js');
  const api=factory(E,root);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(E,root){
  'use strict';
  const STAGE=Math.max(49,Math.min(54,Number(root.STORE_OPERATIONS_STAGE)||54));
  const MAX_ENTRIES=160;
  const FRESH_LIFE={milk:5,fruit:3};
  const safeNumber=(v,max=1e12)=>Number.isFinite(Number(v))?Math.max(0,Math.min(max,Math.round(Number(v)))):0;
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const knownCat=id=>E.CATEGORIES.find(c=>c.id===id);
  const stockUnits=(s,id)=>(s.stock[id]||0)+(s.warehouse[id]||0);
  const pendingUnits=(s,id)=>(s.pending||[]).reduce((n,p)=>n+(p.cat===id?Math.max(0,p.qty-p.received):0),0);
  function hydrate(s){
    if(!s||typeof s!=='object')return s;
    if(!s.operations||typeof s.operations!=='object')s.operations={};
    const o=s.operations;
    if(!o.reorder||typeof o.reorder!=='object')o.reorder={};
    for(const c of E.CATEGORIES){
      const r=o.reorder[c.id];
      const def=['milk','fruit'].includes(c.id)?{minimum:6,target:18}:{minimum:10,target:36};
      if(!r||typeof r!=='object'){o.reorder[c.id]=def;continue;}
      r.minimum=clamp(safeNumber(r.minimum),0,72);
      r.target=clamp(safeNumber(r.target||def.target),12,96);
      r.minimum=Math.min(r.minimum,r.target);
    }
    o.reserveCash=clamp(safeNumber(o.reserveCash??1200000),0,5000000);
    o.serviceStandard=['customer','balanced','shelf'].includes(o.serviceStandard)?o.serviceStandard:'customer';
    if(o.serviceStandard==='balanced'&&s.priority!=='balanced')s.priority='balanced';
    if(!o.staffMetrics||typeof o.staffMetrics!=='object')o.staffMetrics={};
    for(const m of s.staff||[]){
      let p=o.staffMetrics[m.id];if(!p||typeof p!=='object')p=o.staffMetrics[m.id]={};
      for(const k of ['checkouts','restocked','cleaned','supportTicks'])p[k]=safeNumber(p[k],1e8);
    }
    const f=o.finance&&typeof o.finance==='object'?o.finance:{};
    f.entries=Array.isArray(f.entries)?f.entries.filter(e=>e&&Number.isInteger(e.delta)&&typeof e.type==='string'&&Number.isInteger(e.seq)).slice(-MAX_ENTRIES):[];
    // Khóa chốt mốc nếu nâng cấp từ bản lưu không có sổ dòng tiền.
    if(!Number.isSafeInteger(f.openingCash))f.openingCash=safeNumber(s.cash);
    if(!Number.isSafeInteger(f.baseBalance))f.baseBalance=safeNumber(s.cash)-f.entries.reduce((a,e)=>a+e.delta,0);
    f.nextSeq=Number.isSafeInteger(f.nextSeq)?Math.max(f.nextSeq,Math.max(0,...f.entries.map(e=>e.seq))+1):Math.max(1,...f.entries.map(e=>e.seq+1));
    f.openingDay=safeNumber(f.openingDay||s.day,1000000);
    o.finance=f;
    o.version=STAGE;
    return s;
  }
  function record(s,type,delta,detail){
    const f=hydrate(s).operations.finance;
    if(!delta)return;
    const n=Math.trunc(delta);
    f.entries.push({seq:f.nextSeq++,day:s.day,minute:s.minutes,type:String(type).slice(0,32),delta:n,detail:String(detail||'').slice(0,100)});
    while(f.entries.length>MAX_ENTRIES){const oldest=f.entries.shift();f.baseBalance+=oldest.delta;}
  }
  function financeAudit(s){
    const f=hydrate(s).operations.finance;
    const change=f.entries.reduce((a,e)=>a+e.delta,0);
    const expected=f.baseBalance+change;
    return {actual:s.cash,expected,difference:s.cash-expected,valid:s.cash===expected,openingCash:f.openingCash,
      firstDay:f.openingDay,recorded:f.entries.length,entries:f.entries.slice().reverse()};
  }
  function invoiceAnalysis(s){
    const invoices=(s.receipts||[]);
    const byCat={};
    for(const c of E.CATEGORIES)byCat[c.id]={units:0,revenue:0,avg:0};
    for(const inv of invoices){
      const ids=Array.isArray(inv.items)?inv.items.filter(id=>byCat[id]):[];
      if(!ids.length)continue;
      const share=(Number(inv.bill)||0)/ids.length;
      for(const id of ids){byCat[id].units++;byCat[id].revenue+=share;}
    }
    for(const v of Object.values(byCat))v.avg=v.units?Math.round(v.revenue/v.units):0;
    return byCat;
  }
  function forecast(s){
    hydrate(s);
    const entries=invoiceAnalysis(s);
    // Chỉ sử dụng tối đa 3 ngày dữ liệu hóa đơn gần nhất, tránh xu hướng cũ chi phối quá lâu.
    const freshReceipts=(s.receipts||[]).filter(x=>Number(x.day)>=s.day-2);
    const soldRecent={};for(const r of freshReceipts)for(const id of r.items||[])soldRecent[id]=(soldRecent[id]||0)+1;
    const days=Math.min(3,Math.max(1,Math.min(s.day,3)));
    return E.activeCats(s).map(c=>{
      const rule=s.operations.reorder[c.id];
      const onHand=stockUnits(s,c.id),incoming=pendingUnits(s,c.id);
      const usable=onHand+incoming;
      const observed=(soldRecent[c.id]||0)/days;
      const lifetime=(s.director?.salesByCat?.[c.id]||0)/Math.max(1,s.day);
      const dailyVelocity=Math.max(1,Math.ceil(.65*observed+.35*lifetime));
      const shelfTarget=Math.max(rule.minimum,Math.min(rule.target,dailyVelocity*2));
      const shortage=Math.max(0,shelfTarget-usable);
      let pack=[12,24,48,96].find(q=>q>=shortage)||96;
      if(shortage===0||usable>rule.minimum)pack=0;
      if(FRESH_LIFE[c.id]&&pack>24)pack=24; // Giảm nguy cơ lãng phí hàng tươi.
      const room=E.availableRoom(s);
      const affordable=Math.max(0,s.cash-s.operations.reserveCash);
      const feasible=pack>0&&pack<=room&&pack*c.cost<=affordable;
      const nearExpiry=FRESH_LIFE[c.id]?(s.lots?.stock?.[c.id]||[]).concat(s.lots?.warehouse?.[c.id]||[])
        .filter(l=>s.day-l.day>=FRESH_LIFE[c.id]-1).reduce((n,l)=>n+l.qty,0):0;
      return {id:c.id,name:c.name,icon:c.icon,minimum:rule.minimum,target:rule.target,onHand,incoming,usable,
        soldRecent:soldRecent[c.id]||0,receiptUnits:entries[c.id].units,dailyVelocity,shelfTarget,shortage,
        pack,orderCost:pack*c.cost,canOrder:feasible,nearExpiry,
        reason:!pack?'Đủ tồn kho hoặc chưa tới ngưỡng nhập':!feasible?'Cần thêm tiền dự phòng hoặc chỗ trống kho':'Đề xuất nhập '+pack+' sản phẩm'};
    });
  }
  function staffReport(s){
    hydrate(s);
    return s.staff.map(m=>{
      const k=s.operations.staffMetrics[m.id];
      const onShift=m.role!=='rest'&&!m.autoRest;
      let focus='Hoạt động tốt';
      if(m.role==='rest')focus='Đang nghỉ giải lao';
      else if(m.energy<25)focus='Cần nghỉ hồi phục';
      else if(m.mood<45)focus='Tâm trạng thấp, nên quan tâm';
      else if(m.role==='cashier'&&!s.staff.some(x=>x.id!==m.id&&x.role==='cashier')&&s.customers.filter(c=>c.stage==='queue').length>=3)focus='Quầy thu ngân quá tải';
      return {id:m.id,name:m.name,role:m.role,skill:m.skill,mood:Math.round(m.mood),energy:Math.round(m.energy),onShift,focus,
        checkouts:k.checkouts,restocked:k.restocked,cleaned:k.cleaned,supportTicks:k.supportTicks};
    });
  }
  function integrityReport(s){
    hydrate(s);const errors=[],warnings=[];
    if(!Number.isSafeInteger(s.cash)||s.cash<0)errors.push('Số dư tiền ảo không hợp lệ.');
    if(s.staff.length<2||s.staff.length>(E.growthStaffLimit?.(s)||4))errors.push('Số lượng nhân viên ngoài giới hạn cấp cửa hàng.');
    if(new Set(s.staff.map(m=>m.id)).size!==s.staff.length)errors.push('Có mã nhân viên trùng.');
    for(const c of E.CATEGORIES){
      for(const location of ['warehouse','stock']){
        const value=s[location]?.[c.id];
        if(!Number.isInteger(value)||value<0)errors.push('Tồn '+location+' không hợp lệ: '+c.id);
      }
      if(FRESH_LIFE[c.id])for(const location of ['warehouse','stock']){
        const lots=s.lots?.[location]?.[c.id]||[];
        const total=lots.reduce((n,l)=>n+(Number(l.qty)||0),0);
        if(total!==s[location][c.id])warnings.push('Số lượng lô không khớp tồn '+c.name+' ('+location+').');
      }
    }
    if(!financeAudit(s).valid)errors.push('Chênh lệch sổ tiền mặt.');
    const seen=new Set();for(const p of s.pending){if(seen.has(p.id))errors.push('Đơn mua hàng bị trùng mã.');seen.add(p.id);if(p.received>p.qty)errors.push('Đã nhận nhiều hơn số đặt.');}
    if(s.customers.some(c=>!['browse','needHelp','queue','leave'].includes(c.stage)))warnings.push('Có khách hàng ở trạng thái không xác định.');
    return {valid:errors.length===0,errors,warnings,checkedAt:{day:s.day,minute:s.minutes}};
  }
  const originalCreate=E.createGame,originalNormalize=E.normalizeSave,originalDispatch=E.dispatch,originalAdvance=E.advance;
  E.createGame=function(){return hydrate(originalCreate());};
  E.normalizeSave=function(raw){return hydrate(originalNormalize(raw));};
  E.dispatch=function(s,action){
    hydrate(s);
    if(!action||typeof action.type!=='string')return{ok:false,message:'Yêu cầu không hợp lệ.'};
    if(action.type==='SET_REORDER_RULE'){
      if(STAGE<50)return{ok:false,message:'Tính năng sẽ mở trong V50.'};
      const c=knownCat(action.id),min=Number(action.minimum),target=Number(action.target);
      if(!c||c.unlock>s.storeLevel||!Number.isInteger(min)||!Number.isInteger(target)||min<0||min>72||target<12||target>96||min>target)return{ok:false,message:'Định mức phải nguyên: tối thiểu 0–72, mục tiêu 12–96 và tối thiểu không vượt mục tiêu.'};
      s.operations.reorder[c.id]={minimum:min,target};
      return{ok:true,message:'Đã đặt định mức cho '+c.name+'.'};
    }
    if(action.type==='SET_CASH_RESERVE'){
      if(STAGE<50)return{ok:false,message:'Tính năng sẽ mở trong V50.'};
      if(!Number.isInteger(action.amount)||action.amount<0||action.amount>5000000||action.amount%50000!==0)return{ok:false,message:'Dự phòng phải từ 0–5 triệu, bước 50.000đ.'};
      s.operations.reserveCash=action.amount;
      return{ok:true,message:'Đã cập nhật mức tiền dự phòng.'};
    }
    if(action.type==='SET_SERVICE_STANDARD'){
      if(STAGE<51)return{ok:false,message:'Tính năng sẽ mở trong V51.'};
      if(!['customer','balanced','shelf'].includes(action.standard))return{ok:false,message:'Quy trình vận hành không hợp lệ.'};
      s.operations.serviceStandard=action.standard;
      s.priority=action.standard==='balanced'?'balanced':action.standard==='shelf'?'shelf':'customer';
      return{ok:true,message:'Đã áp dụng quy trình phục vụ mới.'};
    }
    if(action.type==='REPLENISH'){
      if(STAGE<50)return{ok:false,message:'Tính năng sẽ mở trong V50.'};
      const options=forecast(s).filter(r=>r.pack>0&&(!action.id||r.id===action.id));
      let count=0,total=0;
      for(const r of options){
        if(!r.canOrder)continue;
        if(s.cash-r.orderCost<s.operations.reserveCash||E.availableRoom(s)<r.pack)continue;
        const out=originalDispatch(s,{type:'ORDER',id:r.id,qty:r.pack});
        if(out.ok){count++;total+=r.orderCost;}
      }
      const message=count?'Đã đặt '+count+' ngành hàng theo định mức · '+E.money(total)+'.':'Không có ngành cần đặt hoặc chưa đủ vốn/kho.';
      if(count)record(s,'REPLENISH',-total,message);
      return{ok:count>0,message};
    }
    const before=s.cash;const response=originalDispatch(s,action);
    if(response?.ok&&s.cash!==before)record(s,action.type,s.cash-before,response.message);
    return response;
  };
  E.advance=function(s,rng=Math.random){
    hydrate(s);
    const before=s.cash,served=s.stats.served,restocked=s.stats.restocked,cleaned=s.stats.cleaned;
    originalAdvance(s,rng);
    const delta=s.cash-before;if(delta)record(s,delta>0?'SALES_OR_REWARD':'DAILY_EXPENSE',delta,'Tự động cập nhật dòng tiền trong game');
    const metrics=s.operations.staffMetrics;
    const split=(role,count,key)=>{
      const group=s.staff.filter(m=>m.role===role&&!m.autoRest&&m.energy>0);
      if(!group.length||count<=0)return;
      const portion=Math.floor(count/group.length);
      group.forEach((m,i)=>{metrics[m.id][key]+=portion+(i<count%group.length?1:0);});
    };
    split('cashier',s.stats.served-served,'checkouts');
    split('operator',s.stats.restocked-restocked,'restocked');
    split('operator',s.stats.cleaned-cleaned,'cleaned');
    const help=s.customers.filter(c=>c.stage==='needHelp').length;
    if(help)split('operator',1,'supportTicks');
    return s;
  };
  E.operationsForecast=forecast;
  E.financeAudit=financeAudit;
  E.recordFinancialChange=record;
  E.staffOperationsReport=staffReport;
  E.operationsIntegrity=integrityReport;
  E.operationsHydrate=hydrate;
  E.OPERATIONS_RELEASE=STAGE;
  return {STAGE,hydrate,forecast,financeAudit,staffReport,integrityReport};
});
