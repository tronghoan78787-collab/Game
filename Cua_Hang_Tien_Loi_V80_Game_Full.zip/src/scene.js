/*
 * CỬA HÀNG TIỆN LỢI — CHIBI SCENE RENDERER
 * GIẢ ĐỊNH (giai đoạn 3): isometric 2.5D được vẽ procedural bằng Canvas 2D để chạy
 * offline trên iPhone; đây không phải mô hình WebGL 3D hay ảnh tĩnh giả lập gameplay.
 */
(function(root){
'use strict';
const E=root.StoreEngine;
const WW=1200,HH=600;
const colorHex = (c,alpha) => c+(Math.round(alpha*255).toString(16).padStart(2,'0'));
class GameScene {
  constructor(canvas,getState,onHit){
    this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:false});this.getState=getState;this.onHit=onHit;
    this.sizeW=0;this.sizeH=0;this.scale=1;this.base=1;this.ox=0;this.oy=0;this.zoom=window.innerWidth<window.innerHeight?1.55:1;this.panX=0;this.panY=0;
    this.drag=null;this.touches=new Map();this.pinch=null;this.visuals=new Map();this.running=true;this.lastFrame=0;this.tapFeedback=null;this.staticLayer=null;this.fps=0;this.frameCounter=0;this.fpsMark=0;
    this.sprites=Object.create(null);this.merchSprites=Object.create(null);this.loadedSprites=0;this.loadIllustrations();
    canvas.addEventListener('pointerdown',e=>this.pointerDown(e));
    canvas.addEventListener('pointermove',e=>this.pointerMove(e));
    canvas.addEventListener('pointerup',e=>this.pointerUp(e));
    canvas.addEventListener('pointercancel',e=>{this.touches.delete(e.pointerId);this.drag=null;this.pinch=null;});
    canvas.addEventListener('wheel',e=>{e.preventDefault();this.adjustZoom(e.deltaY>0?-.08:.08);},{passive:false});
    window.addEventListener('resize',()=>this.resize());
    window.addEventListener('orientationchange',()=>{this.resize();setTimeout(()=>this.resize(),150);});
    if(typeof ResizeObserver!=='undefined')this.observer=new ResizeObserver(()=>this.resize()),this.observer.observe(canvas);
    this.resize();this.frame=window.requestAnimationFrame(t=>this.animate(t));
  }
  // V56: offline sprite atlas. Real PNG graphics, no network calls or external CDN.
  // V65: demand-driven sprite loading limits decoded bitmap memory on iPhone.
  // Newly recruited staff, unlocked categories, and alternate moods load when first visible.
  loadIllustrations(){
    const current=this.getState();const categories=E.activeCats(current).map(c=>c.id);
    const keys=['checkout',...categories.flatMap(c=>['empty','low','full'].map(n=>c+'_'+n)),
      ...['an','binh'].flatMap(n=>['idle','wave','work','scan'].map(a=>n+'_'+a+'_happy')),
      'customer_a_idle_happy'];
    for(const key of keys)this.queueSprite(key);
  }
  queueSprite(key){
    if(this.sprites[key])return;
    const image=new Image();this.sprites[key]=image;
    image.onload=()=>{this.loadedSprites++};
    image.onerror=()=>{image.failed=true};
    image.src=root.EMBEDDED_SPRITES?.[key]||'assets/art/'+key+'.png';
  }
  sprite(key,x,y,width,height){
    if(!this.sprites[key]){this.queueSprite(key);return false;}
    const img=this.sprites[key];if(!img.complete||img.failed||!img.naturalWidth)return false;
    this.ctx.drawImage(img,x,y,width,height);return true;
  }
  // V74: Mặt hàng được chọn hiển thị trên kệ đang có hàng, không tạo tồn kho SKU ảo.
  merchSprite(id,x,y,width,height){
    if(!id)return false;
    if(!this.merchSprites[id]){
      const image=new Image();this.merchSprites[id]=image;
      image.onerror=()=>{image.failed=true};
      image.src=root.EMBEDDED_MERCH?.[id]||'assets/merch/'+id+'.png';
    }
    const image=this.merchSprites[id];if(!image.complete||image.failed||!image.naturalWidth)return false;
    this.ctx.drawImage(image,x,y,width,height);return true;
  }
  resize(){
    const rect=this.canvas.getBoundingClientRect();
    // Both orientations now use untransformed viewport coordinates.
    this.sizeW=this.canvas.clientWidth||rect.width||900;this.sizeH=this.canvas.clientHeight||rect.height||430;
    const quality=this.getState()?.settings.quality||'auto';
    const dpr= Math.min(window.devicePixelRatio||1,quality==='low'?1.25:quality==='high'?2:1.65);
    this.canvas.width=Math.max(1,Math.round(this.sizeW*dpr));
    this.canvas.height=Math.max(1,Math.round(this.sizeH*dpr));this.dpr=dpr;
    this.base=Math.min(this.sizeW/WW,this.sizeH/HH);
    this.calculateTransform();
  }
  calculateTransform(){this.scale=this.base*this.zoom;this.ox=(this.sizeW-WW*this.scale)/2+this.panX;this.oy=(this.sizeH-HH*this.scale)/2+this.panY;}
  adjustZoom(delta){this.zoom=E.clamp(this.zoom+delta,.78,1.7);this.panX=E.clamp(this.panX,-180,180);this.panY=E.clamp(this.panY,-110,110);this.calculateTransform();}
  // V40: kéo bản đồ và chụm hai ngón trong Canvas giống WebGL.
  pointerDown(e){
    if(e.button!==0&&e.pointerType==='mouse')return;
    this.touches.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(this.touches.size>=2){this.pinch=this.pinchLength();if(this.drag)this.drag.moved=true;}
    else this.drag={x:e.clientX,y:e.clientY,panX:this.panX,panY:this.panY,moved:false};
    if(this.canvas.setPointerCapture)try{this.canvas.setPointerCapture(e.pointerId)}catch(_){}
  }
  pinchLength(){const a=[...this.touches.values()];if(a.length<2)return 0;return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);}
  pointerMove(e){
    if(!this.touches.has(e.pointerId))return;
    this.touches.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(this.touches.size>=2){
      const distance=this.pinchLength();if(this.pinch&&distance){this.adjustZoom(E.clamp((distance-this.pinch)/240,-.07,.07));}
      this.pinch=distance;if(this.drag)this.drag.moved=true;return;
    }
    if(!this.drag)return;
    let dx=e.clientX-this.drag.x,dy=e.clientY-this.drag.y;
    if(Math.abs(dx)+Math.abs(dy)>9)this.drag.moved=true;
    if(this.drag.moved){this.panX=E.clamp(this.drag.panX+dx,-180,180);this.panY=E.clamp(this.drag.panY+dy,-115,115);this.calculateTransform();}
  }
  pointerUp(e){
    this.touches.delete(e.pointerId);
    if(this.touches.size){this.pinch=null;return;}
    const data=this.drag;this.drag=null;this.pinch=null;
    if(!data||data.moved)return;
    const r=this.canvas.getBoundingClientRect();let sx=e.clientX-r.left,sy=e.clientY-r.top;
    const x=(sx-this.ox)/this.scale,y=(sy-this.oy)/this.scale;
    const s=this.getState();let hit='store',cat;
    for(const c of E.activeCats(s)){if(Math.abs(x-E.categoryPos(s,c)[0])<75&&Math.abs(y-(E.categoryPos(s,c)[1]+10))<81){hit='shelf';cat=c.id;break;}}
    if(x<380&&y>315&&y<515)hit='staff';
    else if(x>770&&y<252)hit='order';
    if(x>485&&x<590&&y>480)hit='store';
    this.tapFeedback={x,y,until:performance.now()+850};this.onHit(hit,cat);
  }
  animate(time){if(!this.running)return;const state=this.getState();const quality=state?.settings.quality||'auto';const fps=Number(state?.settings?.fpsTarget)||30;const frameGap=quality==='low'?Math.max(48,1000/fps):1000/fps;
    if(time-this.lastFrame>=frameGap){this.draw(state?.settings?.reducedMotion?0:time,state);this.lastFrame=time;
      this.frameCounter++;if(!this.fpsMark)this.fpsMark=time;
      if(time-this.fpsMark>=1000){this.fps=Math.round(this.frameCounter*1000/(time-this.fpsMark));this.frameCounter=0;this.fpsMark=time;}
    }
    this.frame=window.requestAnimationFrame(t=>this.animate(t));
  }
  stop(){this.running=false;cancelAnimationFrame(this.frame);this.observer?.disconnect();this.staticLayer=null;}
  poly(points,fill,stroke=null,width=1.5){const c=this.ctx;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.lineWidth=width;c.strokeStyle=stroke;c.stroke();}}
  rounded(x,y,w,h,r,fill,stroke=null,width=1.5){const c=this.ctx;c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=fill;c.fill();if(stroke){c.lineWidth=width;c.strokeStyle=stroke;c.stroke();}}
  ellipse(x,y,rx,ry,fill){const c=this.ctx;c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=fill;c.fill();}
  text(txt,x,y,size=13,color='#fff',stroke='#375475',align='center'){
    const c=this.ctx;c.font='900 '+size+'px ui-rounded, system-ui, sans-serif';c.textAlign=align;c.textBaseline='middle';
    if(stroke){c.lineWidth=Math.max(2,size*.23);c.lineJoin='round';c.strokeStyle=stroke;c.strokeText(txt,x,y);}
    c.fillStyle=color;c.fillText(txt,x,y);
  }
  emoji(e,x,y,size=20){const c=this.ctx;c.font=size+'px system-ui, "Apple Color Emoji", sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(e,x,y);}
  trace(line,stroke,width=2,dash=[]){const c=this.ctx;c.beginPath();line.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle=stroke;c.lineWidth=width;c.setLineDash(dash);c.stroke();c.setLineDash([]);}
  screenBackground(t){const c=this.ctx;const bg=c.createLinearGradient(0,0,0,this.sizeH);bg.addColorStop(0,'#94d6ee');bg.addColorStop(.45,'#d2ecba');bg.addColorStop(1,'#8cc780');c.setTransform(this.dpr,0,0,this.dpr,0,0);c.fillStyle=bg;c.fillRect(0,0,this.sizeW,this.sizeH);
    c.save();c.globalAlpha=.3;this.ellipse(this.sizeW*.8,50,115,32,'white');this.ellipse(this.sizeW*.13,25,130,28,'white');c.restore();}
  cacheWorld(s){
    if(this.staticLayer)return;
    const layer=document.createElement('canvas');layer.width=WW;layer.height=HH;
    const original=this.ctx;this.ctx=layer.getContext('2d');
    try{this.drawGround(0);this.drawStoreBase(s,0);}finally{this.ctx=original;}
    this.staticLayer=layer;
  }
  draw(time,s){if(!s || !this.sizeW)return;const c=this.ctx;this.screenBackground(time);c.save();c.translate(this.ox,this.oy);c.scale(this.scale,this.scale);
    this.cacheWorld(s);c.drawImage(this.staticLayer,0,0);
    this.drawContents(s,time);
    this.drawSigns(s,time);
    this.drawAtmosphere(s,time);
    if(s.settings?.lighting!==false)this.drawRetailEffects(s,time);
    c.restore();}
  drawGround(time){
    const c=this.ctx;
    this.poly([[0,0],[820,0],[0,412]],'#82b8b6');
    this.poly([[0,27],[820,0],[778,35],[0,439]],'#777b83');
    this.poly([[0,0],[748,0],[0,380]],'#72767c');
    this.trace([[0,171],[400,-22]],'#e4dbc0',4,[28,28]);
    for(let i=0;i<7;i++){this.poly([[i*95-58,281-i*46],[i*95-19,260-i*46],[i*95-16,270-i*46],[i*95-56,290-i*46]],'#f7f3df');}
    this.poly([[0,385],[755,12],[813,50],[43,425]],'#bdc5bd','#a3aca5',2);
    this.poly([[0,401],[768,24],[782,40],[24,416]],'#e4dbbb');
    // paving slabs
    for(let i=0;i<15;i++)this.trace([[i*67,403-i*33],[i*67+39,419-i*33]],'#b3afa0',1);
    const grass=c.createLinearGradient(150,270,1060,600);grass.addColorStop(0,'#a4d88e');grass.addColorStop(1,'#86c76a');
    this.poly([[100,298],[550,52],[1155,327],[688,581]],grass,'#81b36a',2);
    this.poly([[25,454],[311,301],[385,344],[90,504]],'#87c36a');
    this.tree(102,529,.85);this.tree(1075,241,.95);this.tree(1054,481,1.12);this.tree(956,526,.53);
    for(let i=0;i<22;i++){const x=70+((i*239)%1080),y=260+((i*127)%320);if(x<260||x>946){this.ellipse(x,y,3,1.8,i%2?'#f9e4a1':'#e8f4a5');}}
    this.parkBench(1010,360);
    // tiny neighborhood elements
    this.rounded(89,134,90,58,7,'#fff6da','#bf996e',3);this.poly([[80,141],[134,99],[186,135],[182,145],[134,113],[91,152]],'#ed8068','#bc6359',2);
    this.rounded(107,154,34,31,2,'#b0dff2','#608faa',2);this.rounded(153,154,19,31,2,'#91a7b2','#658799',2);
    this.text('TIỆM HOA',134,151,10,'#e36e4b','#fff7d8');
    // parked bicycle near park
    this.ellipse(1008,438,15,15,'#294e64');this.ellipse(1072,437,15,15,'#294e64');
    this.ellipse(1008,438,11,11,'#cdebf1');this.ellipse(1072,437,11,11,'#cdebf1');
    this.trace([[1008,438],[1037,408],[1072,437],[1042,437],[1037,408]],'#5a7799',3);this.trace([[1037,408],[1035,396],[1025,392]],'#325a72',2.3);
  }
  tree(x,y,size){const c=this.ctx;c.save();c.translate(x,y);c.scale(size,size);this.ellipse(3,13,48,17,'#56845b51');this.rounded(-9,-67,18,83,5,'#ab8056','#805f3f',2);
    for(const [dx,dy,r,co] of [[-32,-84,34,'#5aa65a'],[29,-85,39,'#65b366'],[2,-109,43,'#75c777'],[-11,-131,30,'#80d17b']]){
      this.ellipse(dx,dy,r,r*.85,co);this.ellipse(dx-r*.12,dy-r*.20,r*.49,r*.28,'#a5e59a77');}
    c.restore();}
  parkBench(x,y){this.ellipse(x,y+13,56,15,'#608c6260');this.rounded(x-44,y-16,87,14,4,'#d6a76c','#946945',2);this.rounded(x-40,y-30,79,12,4,'#e3b878','#9c7045');this.rounded(x-34,y-5,7,23,1,'#4e6b78');this.rounded(x+28,y-5,7,23,1,'#4e6b78');}
  drawStoreBase(s,time){
    const c=this.ctx;
    this.poly([[163,290],[554,77],[977,268],[570,507]],'#52685253');
    // building shadow and front framing
    this.poly([[166,286],[566,77],[983,278],[581,508]],'#d3bba2','#af947b',4);
    this.poly([[173,287],[566,84],[974,279],[579,499]],'#f8e9ce','#cfb99b',2);
    this.poly([[193,293],[565,96],[954,280],[579,478]],'#f8e6ca','#e3c69c',1.8);
    // patterned tiles diamond lines clipped to floor
    c.save();c.beginPath();[[193,293],[565,96],[954,280],[579,478]].forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.clip();
    for(let i=-12;i<48;i++){
      this.trace([[i*34,45],[i*34+460,610]],'#dfc9a6',.85);
      this.trace([[i*40,600],[i*40+650,0]],'#e3d0b3',.85);
    }
    this.ellipse(486,217,275,140,'#fffdf047');c.restore();
    // tall rear walls, with top trim
    this.poly([[175,286],[565,80],[565,8],[175,209]],'#fff2db','#d6b992',3);
    this.poly([[565,80],[968,273],[968,193],[565,8]],'#f3e7d4','#ccad8c',3);
    this.poly([[174,212],[565,10],[968,196],[968,209],[565,24],[174,225]],'#f6a75e','#b5734e',2);
    this.poly([[175,225],[565,24],[968,209],[968,217],[565,32],[175,234]],'#fff3ce');
    // store signage back wall
    this.rounded(264,157,168,45,9,'#faf7e9','#e59e57',3);
    this.text('TIỆM VUI VẺ',348,175,18,'#ed6d51','#fff');this.text('MINI MART',349,191,10,'#3caab4','#fff');
    // V57 illustrated lighting and retail posters, independent of stock state.
    this.rounded(215,238,77,50,5,'#fce8a8','#d9a369',3);
    this.emoji('☕',253,260,26);this.text('GIẢM GIÁ',253,279,10,'#d65d52','#fff8d3');
    this.rounded(902,233,41,36,5,'#ecf4ee','#82a49b',2);
    this.emoji('🌿',922,247,19);
    this.rounded(440,61,76,8,4,'#efdfbd','#b9aa8b',2);
    for(const lx of [452,474,496]){
      this.ellipse(lx,79,14,5,'#fffbd2a6');this.trace([[lx,68],[lx,75]],'#af9480',2);
    }
    // shelf-like back wall cabinets
    this.rounded(585,95,135,66,5,'#a9e3ed','#70a6ba',3);
    for(let i=0;i<4;i++)this.rounded(596+i*28,103,19,46,3,i%2?'#72bbda':'#c5f2ed','#7bb5c5');
    this.text('TỦ MÁT',653,88,11,'#fff','#3581a1');
    // delivery zone
    this.rounded(781,180,121,70,4,'#d5b68a','#9e7859',3);
    this.rounded(796,192,50,55,3,'#a88b6e','#755b49',2);
    this.rounded(855,201,34,45,2,'#d1bc9d','#8c7056');
    this.text('KHO',841,177,18,'#fff','#8c603c');
    this.rounded(860,204,18,24,2,'#7a95aa','#effaff',2);
    // front glass entrance
    this.poly([[225,323],[288,356],[288,418],[225,387]],'#c1f6f088','#60b4cf',3);
    this.poly([[288,356],[351,385],[351,445],[288,418]],'#b1e9f988','#5b9eb5',3);
    this.trace([[288,356],[288,418]],'#4e97b5',4);
    this.text('OPEN',287,398,14,'#ffe88a','#377296');
    // front curb path
    this.poly([[361,465],[579,528],[760,440],[579,502]],'#d9c09e','#bfa989',2);
    for(let i=0;i<4;i++)this.poly([[432+i*26,489+i*9],[469+i*26,504+i*9],[481+i*26,501+i*9],[443+i*26,484+i*9]],'#f9ecd6');
    // decorative rainbow arch
    this.trace([[363,319],[369,293],[408,284]],'#f5a966',8);
    this.trace([[363,319],[369,293],[408,284]],'#fff4cd',3);
    // opening sale banners
    this.rounded(915,289,44,67,8,'#ec6573','#ad3d57',2);this.text('SALE',937,308,11);this.text('GIÁ',937,327,11);this.text('TỐT',937,345,11);
    this.ellipse(911,363,31,11,'#739d6f4d');
  }
  premiumRack(x,y,cat,qty,max,time){
    if(!this.sprites||this.getState()?.settings?.quality==='low')return false;
    const fullness=qty<=0?'empty':qty<max*.37?'low':'full';
    if(!this.sprite(cat.id+'_'+fullness,x-84,y-96,170,160))return false;
    const c=this.ctx;
    this.rounded(x-48,y+58,96,21,10,'#fffaf0','#d7d4a7',2);
    this.text(qty+' / '+max+' SP',x,y+68,12,qty<=0?'#cf7656':'#328e78',null);
    if(qty>0&&this.sprites['product_'+cat.id])this.sprite('product_'+cat.id,x+43,y+22,28,28);
    const featured=this.getState()?.commerce?.featured?.[cat.id];
    if(featured&&qty>0){this.rounded(x-83,y-104,44,44,12,'#fffbec','#f0c36a',2);this.merchSprite(featured,x-81,y-102,40,40);}

    if(qty<=4){
      this.rounded(x+55,y-87,27,26,12,'#f77971','#ffffff',2);
      this.text('!',x+68,y-74,18,'#fff','#ad414b');
    }else if(qty>max*.6){
      this.ellipse(x+71,y-57,13,13,'#6dd496');this.text('✓',x+71,y-57,16,'#fff','#2f9a66');
    }
    return true;
  }
  rack(x,y,cat,qty,max,now){
    if(this.premiumRack(x,y,cat,qty,max,now))return;
    const c=this.ctx,w=112,h=84;
    this.ellipse(x+6,y+56,74,17,'#6d5a4d42');
    this.poly([[x-w/2,y-23],[x,y-50],[x+w/2,y-24],[x,y+3]],'#ecdbb1','#a98359',2);
    this.poly([[x-w/2,y-23],[x,y+3],[x,y+h-18],[x-w/2,y+51]],'#c9a57d','#9e7c54',2);
    this.poly([[x,y+3],[x+w/2,y-24],[x+w/2,y+50],[x,y+h-18]],'#e6c79d','#aa8155',2);
    this.poly([[x-w/2+6,y+2],[x,y+26],[x+w/2-6,y+1],[x,y-17]],'#fff4dd','#e1ba7d',2);
    this.poly([[x-w/2+6,y+25],[x,y+48],[x+w/2-6,y+25],[x,y+7]],'#fff0d0','#cfac77',1.5);
    // bright header
    this.rounded(x-58,y-64,116,29,7,cat.color,'#fff9dd',3);
    this.text(cat.icon+' '+cat.name.toUpperCase(),x,y-49,12,'#fff','#4b6171');
    if(qty>0){
      const count=Math.min(qty,12);for(let i=0;i<count;i++){
        const row=i<6?0:1,col=i%6;
        const px=x-41+col*17+(row?2:0),py=y-13+col*3.1+row*23;
        const palette=[cat.color,'#ff9d72','#f8d467','#8bcfda','#a0b3f5','#8acb80'];
        this.rounded(px-4.6,py-10,11,17,2,palette[i%palette.length],'#ffffffad',1);
        this.rounded(px-3.4,py-4,8.2,5,1,'#fefefa');
        this.rounded(px-2,py-7,4,2,1,'#9faad4');
      }
    }else{this.text('KỆ TRỐNG',x,y+13,13,'#fa9777','#fff0d7');}
    this.rounded(x-39,y+59,78,16,8,'#fff6e4','#d8c296',1);
    this.text(qty+'/'+max+' sản phẩm',x,y+67,10,qty<6?'#d45e43':'#519383',null);
    if(qty<=5){this.rounded(x+43,y-78,26,25,11,'#f77668','#fff',2);this.text('!',x+56,y-65,17);}
    const featured=this.getState()?.commerce?.featured?.[cat.id];if(featured&&qty>0){this.rounded(x-74,y-105,41,41,12,'#fffbeb','#e9c16e',2);this.merchSprite(featured,x-72,y-103,37,37);}
    if(cat.id==='fruit'&&qty>0){this.emoji('🍌',x-12,y+2,17);this.emoji('🍎',x+13,y+13,17);}
    if(cat.id==='frozen')this.rounded(x-52,y+12,104,8,3,'#97dceb','#ecffff');
  }
  checkout(s,time){
    const x=302,y=383;
    if(s.settings?.quality!=='low'&&this.sprite('checkout',x-108,y-121,212,183))return;
    this.ellipse(x,y+33,100,22,'#4e626260');
    this.poly([[x-94,y-34],[x-10,y-75],[x+78,y-36],[x-9,y+9]],'#f3faf7','#7fa0a8',3);
    this.poly([[x-94,y-34],[x-9,y+9],[x-9,y+56],[x-94,y+9]],'#5c9fae','#41778d',3);
    this.poly([[x-9,y+9],[x+78,y-36],[x+78,y+12],[x-9,y+56]],'#82c4d1','#46899d',3);
    this.poly([[x-94,y-34],[x-10,y-75],[x+78,y-36],[x-9,y+9]],'#f1eee4','#bcb8a8',2);
    this.rounded(x+10,y-99,47,31,4,'#405d8a','#e7fdff',3);
    this.rounded(x+14,y-95,39,23,3,'#80d7f0','#446b91');
    this.text('₫',x+33,y-84,16,'#fff','#448aaf');
    this.rounded(x+26,y-69,16,9,2,'#c7d9ea');
    this.emoji('🛍️',x-54,y-40,25);
    this.text('THU NGÂN',x-14,y+29,13,'#fff','#4b8998');
    if(s.equipment.includes('scanner')){this.rounded(x-12,y-66,10,25,3,'#36708d','#b8ecf0');this.ellipse(x-7,y-63,4,2,'#ff6968');}
    if(s.equipment.includes('pos'))this.emoji('💳',x+59,y-48,22);
  }
  props(s,time){
    // expansion area, warehouse, product cartons, decoration;
    this.ellipse(813,225,60,21,'#8c77604a');
    for(let i=0;i<2;i++){this.poly([[772+i*30,185],[796+i*30,173],[821+i*30,186],[796+i*30,199]],'#e6c08b','#ac875a',1.5);
      this.poly([[772+i*30,185],[796+i*30,199],[796+i*30,231],[772+i*30,216]],'#bf9661','#9a6e47');
      this.poly([[796+i*30,199],[821+i*30,186],[821+i*30,215],[796+i*30,231]],'#d7a875','#a77b52');
      this.text('↑',798+i*30,215,14,'#fff','#b47e4c');}
    if(s.pending.some(x=>x.arrived)){
      this.emoji('🚚',929,162,49);
      this.text('HÀNG ĐẾN!',938,113,13,'#fff','#de7737');
    }
    // palette accents
    this.rounded(398,415,52,22,7,'#e0ad74','#a27750');this.emoji('🧺',423,411,25);
    this.rounded(510,467,68,17,7,'#e2c793','#b39266');
    // V28: vị trí trang trí điều khiển từ bản bố trí. Tọa độ chọn trước tránh lối đi.
    for(const id of s.decor){
      const spot=E.DECOR_SLOTS?.[s.layout?.decor?.[id]];
      if(!spot)continue;
      const sym={plant:'🪴',poster:'🖼️',flower:'🌸',mascot:'🐻',lamp:'💡'}[id]||'🎀';
      this.ellipse(spot.x,spot.y+3,24,9,'#4e71462b');
      if(!this.sprite('decor_'+id,spot.x-24,spot.y-52,48,48))this.emoji(sym,spot.x,spot.y-17,34);
    }
    if(s.equipment.includes('storage'))this.emoji('🗄️',917,251,33);
    if(s.equipment.includes('cold'))this.emoji('🧊',718,150,33);
  }
  drawContents(s,time){
    const objects=[];
    objects.push({y:265,render:()=>this.props(s,time)});
    objects.push({y:375,render:()=>this.checkout(s,time)});
    for(const cat of E.activeCats(s))objects.push({y:E.categoryPos(s,cat)[1]+24,render:()=>this.rack(E.categoryPos(s,cat)[0],E.categoryPos(s,cat)[1],cat,s.stock[cat.id],E.shelfCapacity(s,cat.id),time)});
    for(const member of s.staff){const p=this.smooth(member.id,member.x,member.y,.17);objects.push({y:p.y+8,render:()=>this.character(p.x,p.y,member.name==='An'?'#f1caac':'#edb895',member.role==='rest'?'#a5b6c4':'#e95a52',member.id==='an'?'#53382e':'#343640',member.name,time,member.bubble,member.mood,member.role,member.id)});}
    for(const person of s.customers){const p=this.smooth(person.id,person.x,person.y,.19);objects.push({y:p.y+8,render:()=>this.character(p.x,p.y,person.skin,person.shirt,person.hair,'',time,person.stage==='needHelp'?'❓ '+person.thought:person.stage==='queue'?'🛒 Thanh toán':person.stage==='leave'?'😊':(s.elapsed%13<3?person.thought:null),person.mood,'customer',person.id)});}
    objects.sort((a,b)=>a.y-b.y);
    for(const o of objects)o.render();
    // particle text when a cashier has completed a sale
    s.effects.forEach(e=>{const f=1-(e.until-s.elapsed)/3;this.text(e.text,e.x,e.y-f*20,13,'#fff', '#24a86f');});
    for(let i=0;i<8;i++){const x=94+i*151,y=522+(Math.sin(time/900+i)*5);if(i%3===0)this.emoji('🌼',x,y,13);}
    if(this.tapFeedback&&performance.now()<this.tapFeedback.until){const r=25+16*(1-(this.tapFeedback.until-performance.now())/850);const c=this.ctx;c.save();c.globalAlpha=Math.max(0,(this.tapFeedback.until-performance.now())/850);c.beginPath();c.arc(this.tapFeedback.x,this.tapFeedback.y,r,0,Math.PI*2);c.strokeStyle='#fffce8';c.lineWidth=3;c.stroke();c.restore();}
  }
  smooth(id,x,y,factor){let v=this.visuals.get(id);if(!v){v={x,y,moving:false};this.visuals.set(id,v);}
    const dx=x-v.x,dy=y-v.y;v.moving=Math.hypot(dx,dy)>2;
    v.x+=dx*factor;v.y+=dy*factor;return v;}
  premiumCharacter(x,y,skin,shirt,hair,name,t,bubble,mood,role,id){
    if(!this.sprites||this.getState()?.settings?.quality==='low')return false;
    const isStaff=role!=='customer';
    const n=isStaff?(name==='An'?'an':name==='Bình'?'binh':name==='Linh'?'linh':name==='Minh'?'minh':String(id||'binh')):
      (['customer_a','customer_b','customer_c'][(String(id||'customer').split('').reduce((n,c)=>n+c.charCodeAt(0),0))%3]);
    const state=this.getState();const person=isStaff?state.staff.find(m=>m.id===id):state.customers.find(m=>m.id===id);
    const action=root.StoreMotion?.classify(person||{role,mood},isStaff,state.customers)||'idle';
    const expression=root.StoreMotion?.expression(mood)||(Number(mood||65)<38?'sad':'happy');
    const visual=this.visuals.get(id);const moving=!!visual?.moving;
    const bob=root.StoreMotion?.stride(moving,t,(String(id||'').length*.65),this.getState()?.settings?.reducedMotion)||0;
    const w=isStaff?67:58,h=isStaff?91:82;
    this.ellipse(x,y+6,isStaff?19:17,6,'#466a7670');
    // Footstep lean only while moving. The NPC must not walk in place while waiting.
    const c=this.ctx;c.save();c.translate(x,y);c.rotate(moving&&!this.getState()?.settings?.reducedMotion?Math.sin(t*.011+String(id||'').length)*.028:0);
    const ok=this.sprite(n+'_'+action+'_'+expression,-w/2,-h+10+bob,w,h);c.restore();if(!ok)return false;
    if(isStaff&&this.getState()?.settings?.showNames)this.text(name,x,y+17,11,'#ffffff','#38779d');
    if(bubble){
      let text=String(bubble);if(text.length>26)text=text.slice(0,23)+'…';
      const width=Math.min(155,Math.max(58,text.length*6.4+20));const by=y-h-21+bob;
      this.rounded(x-width/2,by,width,27,12,'#fffdf1','#86b5c9',2);
      this.poly([[x-5,by+24],[x+4,by+24],[x-2,by+31]],'#fffdf1');
      this.text(text,x,by+13,10,'#48728d',null);
    }
    return true;
  }
  character(x,y,skin,shirt,hair,name,t,bubble,mood,role,id){
    if(this.premiumCharacter(x,y,skin,shirt,hair,name,t,bubble,mood,role,id))return;
    const c=this.ctx;c.save();c.translate(x,y);const bob=role==='rest'?.2:Math.sin(t/230+x*.15)*1.7;c.translate(0,bob);
    const s=role==='customer'?.9:1.05;c.scale(s,s);
    this.ellipse(0,8,18,8,'#4a594a4d');
    this.rounded(-12,-21,10,29,5,'#425c7d','#34516e',1.5);this.rounded(3,-21,10,29,5,'#405c7c','#34516e',1.5);
    this.rounded(-14,-34,28,34,8,shirt,'#7a6260',1.5);
    this.rounded(-18,-31,7,22,3,skin,'#bd8976',1);this.rounded(11,-31,7,22,3,skin,'#bd8976',1);
    this.ellipse(0,-48,20,22,hair);this.ellipse(0,-44,17.5,18,skin);this.ellipse(-14,-43,3.5,5,skin);this.ellipse(14,-43,3.5,5,skin);
    this.ellipse(-8,-58,13,6,hair);this.ellipse(10,-56,10,7,hair);
    this.ellipse(-6,-46,2,2.7,'#3a3945');this.ellipse(6,-46,2,2.7,'#3a3945');
    this.trace([[-9,-51],[-4,-52]],'#795952',1);this.trace([[3,-52],[9,-51]],'#795952',1);
    this.ellipse(-5.6,-46.4,.7,.8,'#fff');this.ellipse(6.4,-46.4,.7,.8,'#fff');
    this.ellipse(-10,-39,4,2,'#ffb0a68e');this.ellipse(10,-39,4,2,'#ffb0a68e');
    const happy=Number(mood)>=45;c.beginPath();c.arc(0,-39,4,happy?0:Math.PI,Math.PI*(happy?1:2));c.strokeStyle='#b46a68';c.lineWidth=1.4;c.stroke();
    if(role!=='customer'){
      this.rounded(-3,-31,6,15,2,'#fff8eb');this.ellipse(0,-26,1.2,1.2,'#eaa74c');this.ellipse(0,-20,1.2,1.2,'#eaa74c');
      this.rounded(-18,-66,36,10,5,role==='rest'?'#9bafce':'#ef565c','#faf3e7',2);
      this.rounded(-1,-63,25,6,3,role==='rest'?'#94accf':'#d8494e');
      this.rounded(-6,-22,12,11,3,'#fff7e8','#c3bd9c',1);
      if(this.getState().settings.showNames)this.text(name,0,20,12,'#fff','#276a9d');
    }
    c.restore();
    if(bubble && s>.9){
      let text=String(bubble);if(text.length>24)text=text.slice(0,22)+'…';
      const fontSize=11;const w=Math.min(158,Math.max(70,text.length*6.7+20));const bx=x-w/2,by=y-105;
      this.rounded(bx,by,w,27,12,'#fffcf2','#adc8d8',2);
      this.poly([[x-6,by+25],[x+5,by+25],[x-4,by+32]],'#fffcf2');
      this.text(text,x,by+13,fontSize,'#506981',null);
    }
  }
  // V37: nền sinh động và hiệu ứng ánh sáng/biểu cảm dùng Canvas, không tải tài nguyên ngoài.
  drawAtmosphere(s,time){
    const ctx=this.ctx;
    const hour=(s.minutes||480)/60;
    if(hour>=18.5 && s.settings?.lighting!==false){
      ctx.save();ctx.globalAlpha=Math.min(.22,(hour-18.5)*.035);
      const dusk=ctx.createLinearGradient(0,0,1200,600);dusk.addColorStop(0,'#162958');dusk.addColorStop(1,'#403568');
      ctx.fillStyle=dusk;ctx.fillRect(0,0,1200,600);ctx.restore();
    }
    // Giới hạn số hạt để điện thoại tiết kiệm GPU/CPU.
    if(s.settings?.lighting!==false)for(let i=0;i<9;i++){
      const x=275+i*73+(i%3)*11,y=130+(i*57)%320;
      const twinkle=(Math.sin(time*.002+i*1.7)+1)*.5;
      ctx.save();ctx.globalAlpha=.18+twinkle*.5;ctx.lineWidth=1.5;ctx.strokeStyle=i%2?'#ffe9a1':'#ffffff';
      ctx.beginPath();ctx.moveTo(x-3,y);ctx.lineTo(x+3,y);ctx.moveTo(x,y-3);ctx.lineTo(x,y+3);ctx.stroke();ctx.restore();
    }
    if(s.opened&&s.stats.served>0&&s.elapsed%18<4){
      const drift=(time%1300)/1300;ctx.save();ctx.globalAlpha=.65*(1-drift);
      this.text('💚 CẢM ƠN BẠN!',326,264-drift*36,13,'#ffffff','#25a782');ctx.restore();
    }
  }
  drawRetailEffects(s,time){
    // Small sparkling promotions and store signs without obstructing touch targets.
    if(this.getState()?.settings?.reducedMotion)return;
    const c=this.ctx;c.save();
    const spots=[[372,193],[624,188],[764,283],[904,321]];
    for(let i=0;i<spots.length;i++){
      const [x,y]=spots[i];const a=.35+.25*Math.sin(time/630+i*2.6);
      c.globalAlpha=a;c.strokeStyle='#fff3c8';c.lineWidth=1.8;
      c.beginPath();c.moveTo(x-5,y);c.lineTo(x+5,y);c.moveTo(x,y-5);c.lineTo(x,y+5);c.stroke();
    }
    c.restore();
  }
  drawSigns(s,time){
    if(!s.opened){this.rounded(510,476,175,40,11,'#fff0d4','#e8bd83',3);this.text('CHỜ KHAI TRƯƠNG',597,497,17,'#fa8a5b','#fff');}
    else {
      this.rounded(485,489,100,27,9,'#70cd8d','#fff',2);this.text('ĐANG MỞ CỬA',535,502,12,'#fff','#328d5f');
    }
    if(s.promo.cat&&s.promo.untilDay>=s.day){
      this.rounded(642,118,116,32,9,'#fa6b69','#fff7d7',2);this.text('SALE -'+s.promo.rate+'%',700,134,15,'#fff','#d34f48');
    }
    this.text('KÉO ĐỂ DI CHUYỂN • CHẠM KỆ ĐỂ QUẢN LÝ',603,560,12,'#fff','#5e9769');
  }
}
root.StoreScene=GameScene;
})(typeof globalThis!=='undefined'?globalThis:this);
