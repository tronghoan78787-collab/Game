/* V62: deterministic NPC motion rules; no network or large language model. */
(function(root){'use strict';
const classify=(person,isStaff,customers=[])=>{
 const task=String(person.task||'').toLowerCase();
 const mode=String(person.role||'');
 if(person.energy!==undefined&&person.energy<12)return 'idle';
 if(isStaff){
   if(mode==='rest'||/nghỉ|hồi sức/.test(task))return 'idle';
   if(/tư vấn|hỗ trợ|chỉ dẫn|chăm sóc|hướng dẫn/.test(task))return 'wave';
   if(mode==='cashier'&&(/thanh toán|tính tiền|thu ngân|quét mã/.test(task))&&customers.some(c=>/queue|pay/i.test(String(c.stage||''))))return 'scan';
   if(mode==='operator'&&/nhận hàng|sắp xếp|lên kệ|vệ sinh|dọn|bổ sung/.test(task))return 'work';
   return 'idle';
 }
 if(/needhelp/i.test(String(person.stage||'')))return 'wave';
 if(/queue|pay/.test(String(person.stage||'')))return 'work';
 return 'idle';
};
const expression=mood=>Number(mood||65)<38?'sad':'happy';
const stride=(moving,time,phase=0,reduced=false)=>reduced||!moving?0:Math.sin(time*.012+phase)*2.4;
root.StoreMotion={classify,expression,stride};
if(typeof module!=='undefined'&&module.exports)module.exports=root.StoreMotion;
})(typeof globalThis!=='undefined'?globalThis:this);
