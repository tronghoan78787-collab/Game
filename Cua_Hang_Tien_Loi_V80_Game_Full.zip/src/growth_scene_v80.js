/*
 * V79/V80 — additions to 2.5D isometric map. All geometry is drawn in the
 * original world coordinate system; upgrade changes staticLayer cache key.
 * Expanded wings are rendered only when the upgrade is owned by the player.
 */
(function(root){
 'use strict';
 const proto=root.StoreScene?.prototype;
 if(!proto)return;
 const baseCache=proto.cacheWorld,baseStore=proto.drawStoreBase,baseSigns=proto.drawSigns;
 proto.cacheWorld=function(state){
   if(this.cachedStoreLevel!==state.storeLevel){this.cachedStoreLevel=state.storeLevel;this.staticLayer=null;}
   return baseCache.call(this,state);
 };
 function wing(ctx,points,fill,accent){
   ctx.poly(points,fill,'#bd9a70',4);
   ctx.poly(points.map(([x,y])=>[x,y-8]),accent,'#ffeccd',1.2);
   const [a,b,c,d]=points;
   // Isometric grid lines kept inside the new room polygon.
   ctx.ctx.save();ctx.ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.ctx.lineTo(x,y):ctx.ctx.moveTo(x,y));ctx.ctx.closePath();ctx.ctx.clip();
   for(let i=-8;i<=15;i++){
     ctx.trace([[a[0]+i*34,a[1]-80],[c[0]+i*34,c[1]+95]],'#ffffff72',1);
     ctx.trace([[a[0]+i*36,c[1]+100],[c[0]+i*36,a[1]-120]],'#be986344',1);
   }
   ctx.ctx.restore();
 }
 proto.drawStoreBase=function(s,t){
   baseStore.call(this,s,t);
   if(s.storeLevel>=3){
     wing(this,[[856,314],[1016,232],[1190,327],[1034,419]],'#eacbb4','#fff0db');
     this.poly([[1022,233],[1178,322],[1178,265],[1022,184]],'#f3eee0','#caa887',2);
     this.poly([[1016,191],[1178,271],[1178,283],[1016,203]],'#f59b68','#b8755f',1.5);
     this.rounded(1030,218,97,24,7,'#cfb0e5','#fff2eb',2);
     this.text('KHU MỚI',1079,230,11,'#fff','#8d5baf');
     this.rounded(1070,380,90,19,7,'#fff9e5','#bd9b7a',2);
     this.text('MỞ RỘNG +48m²',1115,389,10,'#548e77','#fff');
   }
   if(s.storeLevel>=4){
     wing(this,[[90,420],[285,325],[477,423],[274,530]],'#ebd5b8','#fdf3dd');
     wing(this,[[714,463],[873,388],[1081,501],[907,595]],'#e7d5b9','#fdf2de');
     this.poly([[91,421],[285,330],[285,270],[91,365]],'#fff3dc','#c7a17d',3);
     this.poly([[95,363],[284,269],[284,283],[95,375]],'#7ec9ba','#fff3de',2);
     this.rounded(127,374,89,24,7,'#70b7dd','#fff5e7',2);
     this.text('KHU VIP',172,386,11,'#fff','#407da0');
   }
 };
 proto.drawSigns=function(s,t){baseSigns.call(this,s,t);
   if(s.storeLevel>1){this.rounded(700,46,186,31,13,'#fff9dc','#87d5ae',2);this.text('🏬 '+(root.StoreEngine.growthArea(s))+'m² · '+root.StoreEngine.activeCats(s).length+' KỆ',793,62,14,'#368a79','#fffaf1');}
 };
 // New hired staff use their original art asset instead of defaulting to Bình's sprite.
 const p=proto.premiumCharacter.toString();
 // premiumCharacter implementation is patched in scene.js, because in-method
 // sprite selection cannot be intercepted without copying the entire renderer.
 if(root.StoreScene3D?.prototype?.build){
   const b=root.StoreScene3D.prototype.build;
   root.StoreScene3D.prototype.build=function(s,t){
     b.call(this,s,t);
     if(s.storeLevel>=3){
       this.addBox(9.6,-.065,1.2,6.6,.12,7,'#f0d8c3');
       this.addBox(9.6,.06,1.2,6.6,.12,7,'#f7e8d1');
     }
     if(s.storeLevel>=4){
       this.addBox(-7.4,-.06,3.3,5.3,.12,6.8,'#e7d0b0');
       this.addBox(5.6,-.06,5.4,6.0,.12,3.2,'#ead6bd');
     }
   };
 }
})(typeof window!=='undefined'?window:globalThis);
