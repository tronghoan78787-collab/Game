/*
 * V17 — Cảnh 3D chibi WebGL không thư viện ngoài.
 * Giả định: smartphone GPU/WebGL1 là mức hỗ trợ thấp nhất; mô hình dựng bằng mesh
 * thủ tục, không tải texture hay gửi dữ liệu qua mạng. Canvas 2D vẫn là fallback.
 * V18 bổ sung hoạt ảnh bước chân, cảm xúc, biểu tượng suy nghĩ và vị trí tương tác.
 * V20 giới hạn tần suất dựng mesh, DPR và hỗ trợ chụm hai ngón / safe-area.
 */
(function(root){'use strict';
const E=root.StoreEngine;const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const colors={cream:'#fff4df',tile:'#f6e7cc',wood:'#ac7552',road:'#65737f',wall:'#fff4df',blue:'#45a7f2',mint:'#84d7ae',pink:'#ff899c',shadow:'#7f96a0'};
const rgb=h=>{let k=parseInt(String(h||'#ffffff').replace('#','').slice(0,6),16);return [(k>>16&255)/255,(k>>8&255)/255,(k&255)/255];};
const vertexShader=`attribute vec3 aPosition;attribute vec3 aNormal;attribute vec3 aColor;uniform mat4 uMatrix;varying vec3 vColor;void main(){float shade=.68+max(0.,dot(normalize(aNormal),normalize(vec3(.25,.85,.65))))*.32;vColor=aColor*shade;gl_Position=uMatrix*vec4(aPosition,1.);}`;
const fragmentShader=`precision mediump float;varying vec3 vColor;uniform float uSun;void main(){vec3 night=vec3(.40,.52,.78);vec3 tint=mix(night,vec3(1.,1.,1.),uSun);gl_FragColor=vec4(vColor*tint,1.);}`;
const faces=[[[0,1,2],[0,2,3],[0,0,1]],[[4,6,5],[4,7,6],[0,0,-1]],[[0,4,5],[0,5,1],[0,-1,0]],[[3,2,6],[3,6,7],[0,1,0]],[[1,5,6],[1,6,2],[1,0,0]],[[0,3,7],[0,7,4],[-1,0,0]]];
const verts=[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,-1,-1]];
// Correct final vertex of unit cube is (-1,1,-1).
verts[7]=[-1,1,-1];
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],unit=a=>{const n=Math.hypot(...a)||1;return a.map(v=>v/n);};
function cameraMatrix(yaw,zoom,aspect,pan){const eye=[Math.sin(yaw)*19,22,Math.cos(yaw)*19];const f=unit(sub([0,0,0],eye)),r=unit(cross(f,[0,1,0])),u=cross(r,f);const top=8.9/zoom,right=top*aspect;
 return [r[0]/right,u[0]/top,-f[0]/38,0,r[1]/right,u[1]/top,-f[1]/38,0,r[2]/right,u[2]/top,-f[2]/38,0,-dot(r,eye)/right-pan[0]/right,-dot(u,eye)/top+pan[1]/top,dot(f,eye)/38,1];}
function compile(gl,type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){const message=gl.getShaderInfoLog(s);gl.deleteShader(s);throw Error(message);}return s;}
class Scene3D{
 constructor(canvas,getState,onHit){this.canvas=canvas;this.getState=getState;this.onHit=onHit;this.gl=canvas.getContext('webgl',{alpha:false,antialias:true,powerPreference:'low-power',preserveDrawingBuffer:false})||canvas.getContext('experimental-webgl');if(!this.gl)throw Error('WebGL unavailable');
  const gl=this.gl;const p=gl.createProgram();const vs=compile(gl,gl.VERTEX_SHADER,vertexShader),fs=compile(gl,gl.FRAGMENT_SHADER,fragmentShader);gl.attachShader(p,vs);gl.attachShader(p,fs);gl.linkProgram(p);gl.deleteShader?.(vs);gl.deleteShader?.(fs);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error('Cannot link WebGL shaders.');this.program=p;
  this.loc={position:gl.getAttribLocation(p,'aPosition'),normal:gl.getAttribLocation(p,'aNormal'),color:gl.getAttribLocation(p,'aColor'),matrix:gl.getUniformLocation(p,'uMatrix'),sun:gl.getUniformLocation(p,'uSun')};this.buffer=gl.createBuffer();this.labelLayer=document.createElement('div');this.labelLayer.className='world-label-layer';canvas.parentElement.appendChild(this.labelLayer);
  this.zoom=1;this.yaw=-.77;this.pan=[0,0];this.visuals=new Map();this.running=true;this.frame=0;this.last=0;this.points=[];this.pointers=new Map();this.gesture=null;this.touchMoved=false;this.usedGesture=false;this.fps=0;this.maxVertices=0;this.slowFrames=0;
  this.resize=()=>this.resizeIfNeeded(true);window.addEventListener('resize',this.resize,{passive:true});this.resize();
  this.down=e=>{canvas.setPointerCapture?.(e.pointerId);this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY});if(this.pointers.size===1){this.touchMoved=false;this.usedGesture=false;}if(this.pointers.size===2){this.gesture=this.gestureInfo();this.usedGesture=true;}};
  this.move=e=>{const pt=this.pointers.get(e.pointerId);if(!pt)return;const dx=e.clientX-pt.x,dy=e.clientY-pt.y;pt.x=e.clientX;pt.y=e.clientY;if(Math.abs(pt.x-pt.startX)+Math.abs(pt.y-pt.startY)>9)this.touchMoved=true;
    if(this.pointers.size===2){const g=this.gestureInfo();if(this.gesture){this.zoom=clamp(this.zoom*(g.distance/Math.max(5,this.gesture.distance)),.65,2.1);this.yaw+=g.angle-this.gesture.angle;}this.gesture=g;}
    else if(this.pointers.size===1&&this.touchMoved){this.pan[0]=clamp(this.pan[0]+dx*.012,-4,4);this.pan[1]=clamp(this.pan[1]-dy*.012,-3,3);}};
  this.up=e=>{const wasMoved=this.touchMoved||this.usedGesture;this.pointers.delete(e.pointerId);if(this.pointers.size<2)this.gesture=null;if(this.pointers.size===0){this.touchMoved=false;this.usedGesture=false;}if(wasMoved)return;
    const b=canvas.getBoundingClientRect();let x=e.clientX-b.left,y=e.clientY-b.top;
    const nx=x/(canvas.clientWidth||b.width)*2-1,ny=1-y/(canvas.clientHeight||b.height)*2;let nearest,dist=Infinity;for(const point of this.points){const d=(point.x-nx)**2+(point.y-ny)**2;if(d<dist){dist=d;nearest=point;}}if(nearest&&dist<.045)this.onHit(nearest.kind,nearest.id);else this.onHit('store');};
  canvas.addEventListener('pointerdown',this.down);canvas.addEventListener('pointermove',this.move);canvas.addEventListener('pointerup',this.up);canvas.addEventListener('pointercancel',e=>{this.pointers.delete(e.pointerId);this.gesture=null;});canvas.addEventListener('wheel',e=>{e.preventDefault();this.adjustZoom(e.deltaY>0?-.1:.1);},{passive:false});
  this.lost=e=>{e.preventDefault();this.stop();root.dispatchEvent(new CustomEvent('store3dfailed'));};canvas.addEventListener('webglcontextlost',this.lost);
  this.raf=requestAnimationFrame(t=>this.animate(t));
 }
 gestureInfo(){const a=[...this.pointers.values()];if(a.length<2)return null;return {distance:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),angle:Math.atan2(a[1].y-a[0].y,a[1].x-a[0].x)};}
 adjustZoom(delta){this.zoom=clamp(this.zoom+delta,.65,2.1);}
 rotateCamera(){this.yaw+=Math.PI/8;}
 addTriangle(a,b,c,color){const n=unit(cross(sub(b,a),sub(c,a)));for(const v of [a,b,c]){this.pos.push(...v);this.norm.push(...n);this.cols.push(...rgb(color));}}
 addBox(x,y,z,w,h,d,color){const list=[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1]];
  for(const [a,b,normal] of faces)for(const i of [...a,...b]){const v=list[i];this.pos.push(x+v[0]*w/2,y+v[1]*h/2,z+v[2]*d/2);this.norm.push(...normal);this.cols.push(...rgb(color));}}
 addSphere(x,y,z,rx,ry,rz,color,rings=6,segments=9){for(let j=0;j<rings;j++){const a=j/rings*Math.PI-Math.PI/2,b=(j+1)/rings*Math.PI-Math.PI/2;for(let i=0;i<segments;i++){const c=i/segments*2*Math.PI,d=(i+1)/segments*2*Math.PI;const at=(p,q)=>[x+rx*Math.cos(p)*Math.cos(q),y+ry*Math.sin(p),z+rz*Math.cos(p)*Math.sin(q)];const p=at(a,c),q=at(b,c),r=at(b,d),s=at(a,d);this.addTriangle(p,q,r,color);this.addTriangle(p,r,s,color);}}}
 addCylinder(x,y,z,r,h,color,sides=8){const a=y-h/2,b=y+h/2;for(let i=0;i<sides;i++){const t=i/sides*Math.PI*2,u=(i+1)/sides*Math.PI*2;const p=[x+Math.cos(t)*r,a,z+Math.sin(t)*r],q=[x+Math.cos(u)*r,a,z+Math.sin(u)*r],r1=[p[0],b,p[2]],s=[q[0],b,q[2]];this.addTriangle(p,s,q,color);this.addTriangle(p,r1,s,color);this.addTriangle([x,b,z],s,r1,color);}}
 addCone(x,y,z,r,h,color){const a=y-h/2;for(let i=0;i<9;i++){const t=i/9*Math.PI*2,u=(i+1)/9*Math.PI*2;this.addTriangle([x+Math.cos(t)*r,a,z+Math.sin(t)*r],[x+Math.cos(u)*r,a,z+Math.sin(u)*r],[x,y+h/2,z],color);}}
 mapPos(x,y){return [(x-585)/57,(y-320)/42];}
 project(x,y,z){const m=this.m;return {x:m[0]*x+m[4]*y+m[8]*z+m[12],y:m[1]*x+m[5]*y+m[9]*z+m[13]};}
 addCharacter(x,z,person,t,isStaff){
  // V65: posed GLB-authored chibi models for the two initial employees in WebGL.
  // Switch whole-mesh poses by actual task, not skeletal interpolation.
  if(isStaff && this.getState()?.settings?.quality!=='low' && ['an','binh'].includes(person.id)){
    const action=root.StoreMotion?.classify(person,true,this.getState()?.customers||[])||'idle';
    const pose=action==='wave'?'wave':action==='scan'&&person.id==='an'?'scan':action==='work'&&person.id==='binh'?'stock':'idle';
    if(this.addAuthoredModel(person.id+'_'+pose,x,z))return;
  }
  const mood=person.mood||70;const moving=person.motion>0.08;const stride=moving?Math.sin(t*.009+(person.id?.length||0))*0.14:Math.sin(t*.002)*.018;const energy=person.energy??80;
  this.addSphere(x,.065,z,.43,.06,.30,'#aeafa2',4,9); // soft contact shadow
  // V32: chuyển động nhấp nhô độc lập, mô phỏng chibi, không có rig nhập khẩu.
  const moodIdle=Math.sin(t*.0019+(String(person.id).length||1))*.02;
  const top=isStaff?'#e95e5d':person.shirt||'#70aee7';const skin=person.skin||'#ffceb0',hair=person.hair||'#70442e';
  this.addSphere(x,.7+Math.abs(stride)*.14,z,.34,.42,.28,top,7,10);this.addSphere(x,1.34+Math.abs(stride)*.08+moodIdle,z,.48,.46,.43,skin,8,12);
  this.addSphere(x,1.65,z-.07,.50,.23,.44,hair,5,11);this.addSphere(x-.42,1.34,z-.06,.12,.30,.22,hair,5,8);this.addSphere(x+.42,1.34,z-.06,.12,.27,.22,hair,5,8);
  if(isStaff){this.addCylinder(x,1.82,z,.40,.12,'#e5444e',12);this.addBox(x,1.85,z+.14,.62,.07,.32,'#bb2435');this.addBox(x,.70,z+.27,.20,.35,.07,'#ffffff');}
  // large kawaii eyes, brows and smile, all face toward positive Z
  for(const k of [-1,1]){this.addSphere(x+k*.18,1.37,z+.395,.058,.092,.029,'#272e41',5,7);this.addSphere(x+k*.18-.016,1.41,z+.42,.017,.025,.012,'#ffffff',4,6);this.addSphere(x+k*.31,1.20,z+.34,.07,.043,.024,'#ff9f9b',4,6);}
  const blink=(Math.floor(t/3100+(String(person.id).length%7)*.38)%5===0)&&(t%3100<120);
  if(blink){for(const k of [-1,1])this.addBox(x+k*.18,1.37,z+.435,.13,.027,.015,'#382d40');}
  this.addSphere(x,1.18,z+.43,.095,mood<35?.018:.04,.017,mood>55?'#ad5360':'#6d5460',4,7);
  // Nhân viên đang phục vụ giơ tay, còn nhân viên đang xếp kệ cầm sản phẩm.
  if(isStaff && (/Tư vấn|Hỗ trợ|hướng dẫn/i).test(person.task||'')){
    this.addSphere(x+.52,.98+Math.sin(t*.008)*.10,z+.19,.15,.23,.14,skin,5,8);
  }
  if(person.role==='cashier'&&(/thu ngân|tính tiền|thanh toán/i).test(person.task||'')){
    this.addBox(x+.38,.48,z+.39,.20,.09,.27,'#5fa7d4');
    this.addBox(x+.36,.54,z+.45,.12,.045,.15,'#d6f9e7');
  }
  if(person.role==='operator'&&(/Vệ sinh|dọn|lau/i).test(person.task||'')){
    this.addCylinder(x+.42,.46,z+.22,.035,.9,'#9f754e',5);
    this.addBox(x+.42,.05,z+.22,.51,.09,.25,'#73bbce');
  }
  this.addSphere(x-.42,.68+stride/2,z,.13,.29,.13,skin,5,8);this.addSphere(x+.42,.68-stride/2,z,.13,.29,.13,skin,5,8);
  this.addSphere(x-.16,.23+stride/2,z,.14,.26,.15,'#435578',5,8);this.addSphere(x+.16,.23-stride/2,z,.14,.26,.15,'#435578',5,8);
  this.addBox(x-.16,.06+stride/2,z+.10,.26,.12,.36,'#f4f0ed');this.addBox(x+.16,.06-stride/2,z+.10,.26,.12,.36,'#f4f0ed');
  if(person.bag?.length){this.addBox(x+.48,.53,z+.05,.31,.38,.33,'#c28e55');this.addBox(x+.48,.79,z+.05,.23,.09,.08,'#e9cb97');}
  if(person.role==='operator'&&person.task?.includes('Nhận hàng'))this.addBox(x+.42,.42,z+.20,.48,.45,.48,'#cb9666');
  if(energy<25)this.addSphere(x,2.05,z,.18,.13,.15,'#9cdafa',5,8);
 }
 addTree(x,z,scale=1){this.addCylinder(x,.42*scale,z,.13*scale,.86*scale,'#95653d',7);this.addSphere(x,1.15*scale,z,.71*scale,.64*scale,.67*scale,'#53aa68');this.addSphere(x-.27*scale,1.42*scale,z,.44*scale,.44*scale,.43*scale,'#70c77a');}
 addAuthoredModel(name,x,z){
  const data=root.StoreModelAtlas?.get?.(name);if(!data)return false;
  for(let i=0;i<data.length;i+=9){this.pos.push(x+data[i],data[i+1],z+data[i+2]);
   this.norm.push(data[i+3],data[i+4],data[i+5]);this.cols.push(data[i+6],data[i+7],data[i+8]);}
  return true;
 }
 addShelf(cat,s,t){const [x,z]=this.mapPos(...E.categoryPos(s,cat));const qty=s.stock[cat.id]||0,fruit=cat.id==='fruit',cold=['drink','milk','frozen'].includes(cat.id);
  if(['drink','snack','milk','fruit'].includes(cat.id)&&this.addAuthoredModel('shelf_'+cat.id+'_'+(qty>0?'full':'empty'),x,z)){
    this.points.push({kind:'shelf',id:cat.id,...this.project(x,1.1,z)});return;
  }
  this.addBox(x,.45,z,2.25,.90,.78,cold?'#a6dbea':fruit?'#e2b16d':'#c2926d');this.addBox(x,.97,z,2.36,.13,.89,'#fff4db');this.addBox(x,1.23,z-.34,2.45,.40,.21,cat.color);this.addBox(x,.42,z+.40,2.22,.08,.08,'#fff1d2');
  // Bảng giá nhỏ, vách ngăn và viền kệ tạo chiều sâu khi nhìn trên iPhone.
  for(let r=0;r<3;r++)this.addBox(x-1.10+r*.87,.76,z+.47,.31,.12,.022,'#f7efc8');this.addBox(x,.75,z+.40,2.22,.08,.08,'#fff1d2');
  if(cold){this.addBox(x-1.1,.55,z+.43,.05,.78,.03,'#e5fbff');this.addBox(x+1.1,.55,z+.43,.05,.78,.03,'#e5fbff');this.addBox(x,.55,z+.44,.035,.78,.03,'#e5fbff');}
  const palette=cat.id==='fruit'?['#ff6a68','#f8d75a','#80ca65','#f49e5b']:cat.id==='drink'?['#59bce9','#f0a64f','#e87169','#88c47f']:cat.id==='milk'?['#b6e8ff','#fbf4df','#7fbde4']:['#ffc658','#ef726f','#a8d36f','#9ec5ed'];
  const display=Math.min(qty,20);for(let i=0;i<display;i++){const row=Math.floor(i/10),col=i%10,c=palette[i%palette.length],px=x-1.0+col*.22,pz=z+.16+(row*.35);
   if(fruit)this.addSphere(px,.37+row*.36,pz,.115,.13,.12,c,4,7);
   else if(cat.id==='drink'){this.addCylinder(px,.35+row*.35,pz,.084,.29,c,6);this.addCylinder(px,.51+row*.35,pz,.06,.045,'#fff7e9',6);}
   else if(cat.id==='milk'){this.addBox(px,.36+row*.34,pz,.16,.29,.15,c);this.addBox(px,.52+row*.34,pz,.12,.05,.12,'#fdfdf6');}
   else this.addBox(px,.37+row*.33,pz,.16,.23,.18,c);
  }
  this.points.push({kind:'shelf',id:cat.id,...this.project(x,1.1,z)});
 }
 build(state,t){const s=state;this.pos=[];this.norm=[];this.cols=[];this.points=[];
  // neighborhood, asphalt and marked road
  this.addBox(0,-.48,0,25,.72,19,'#86bf7f');this.addBox(-8.9,-.29,-2,4,.25,19,colors.road);this.addBox(-8.85,-.14,0,3.5,.08,18,'#71818a');for(let i=-7;i<=7;i++)this.addBox(-8.8,-.09,i*1.18,.10,.012,.56,'#f6e4a2');
  this.addBox(-7.3,-.11,0,.85,.25,16,'#ddd7c5');this.addBox(0,-.15,0,14.6,.2,10.3,'#ebdbbb');this.addBox(0,-.02,0,14.2,.12,10.0,colors.tile);
  for(let i=-7;i<=7;i++)this.addBox(i,.042,0,.014,.009,10,'#ead8bd');for(let j=-5;j<=5;j++)this.addBox(0,.042,j,14.1,.009,.014,'#ead8bd');
  this.addBox(-7.0,1.48,0,.25,2.93,10.15,colors.wall);this.addBox(0,1.48,-5.02,14.2,2.93,.23,colors.wall);
  this.addBox(-7,2.99,0,.37,.14,10.25,'#f7a25f');
  // V32: rìa vỉa hè và đèn trần dạng low-poly, không phải texture tải ngoài.
  for(const x of [-4.7,-1.8,1.1,4.0]){
    this.addCylinder(x,2.90,-2.1,.04,.16,'#9c9f9b',6);
    this.addSphere(x,2.72,-2.1,.36,.11,.36,'#fff7c9',5,9);
  }this.addBox(0,2.99,-5,14.3,.14,.33,'#f7a25f');
  // billboard and murals
  this.addBox(-6.83,2.3,-2.1,.07,.80,1.62,'#5caceb');this.addBox(-6.78,2.32,-2.1,.06,.52,1.27,'#e5f7f4');
  this.addBox(2.3,2.0,-4.86,2.1,.86,.06,'#ff8a72');this.addBox(2.3,2.0,-4.80,1.75,.53,.05,'#ffdeb2');
  // air-conditioner, clock and counter
  this.addBox(-5.8,2.7,-4.63,1.35,.39,.36,'#d9e8ed');this.addBox(-5.8,2.58,-4.36,1.05,.09,.06,'#a9c2cc');
  this.addCylinder(4.55,2.1,-4.76,.29,.09,'#f8f1df',12);this.addCylinder(4.55,2.1,-4.68,.24,.08,'#d6e1eb',12);
  if(!this.addAuthoredModel('checkout',-4.55,2.4)){this.addBox(-4.55,.50,2.4,2.58,.93,1.42,'#80b1bd');this.addBox(-4.55,1.02,2.4,2.74,.12,1.52,'#fff9ea');this.addBox(-4.35,1.39,2.04,.71,.58,.40,'#445d82');this.addBox(-4.35,1.45,2.28,.55,.35,.12,'#b4e8d8');}
  // Tia sáng đầu đọc mã và máy POS phát sáng nhịp nhẹ tại quầy thu ngân.
  const scanGlow=(s.opened&&s.customers.some(c=>c.stage==='pay'||c.status==='queue'))?.08:0;
  this.addBox(-3.80,1.35,2.32,.25,.07,.28,scanGlow?'#a7ffb0':'#dbeae7');this.addCylinder(-3.75,1.16,2.67,.18,.23,'#8aa1b0');this.points.push({kind:'staff',...this.project(-4.55,1.5,2.4)});
  // customer gate glass doors
  this.addBox(-1.6,.83,5.00,2.7,1.66,.13,'#d6f1f1');this.addBox(-1.6,.89,5.09,.07,1.65,.09,'#6bb9c7');this.addBox(-2.92,.89,5.10,.08,1.65,.09,'#74afb6');this.addBox(-.28,.89,5.10,.08,1.65,.09,'#74afb6');this.addBox(-1.6,1.7,5.10,2.73,.13,.1,'#65afb7');
  // stock room and boxes
  this.addBox(4.55,.43,-3.70,3,.81,1.26,'#c49c75');this.addBox(5.15,1.35,-4.55,2.65,2.45,.38,'#d5a678');this.addBox(4.55,2.76,-4.68,3.5,.2,.32,'#78b5f0');
  for(let i=0;i<7;i++){this.addBox(3.7+(i%3)*.68,.98+Math.floor(i/3)*.52,-3.55,.55,.46,.54,'#cc9a6a');this.addBox(3.7+(i%3)*.68,1.23+Math.floor(i/3)*.52,-3.55,.4,.04,.57,'#efc793');}
  this.points.push({kind:'order',...this.project(4.6,1,-3.7)});
  for(const cat of E.activeCats(s))this.addShelf(cat,s,t);
  // clean area, lamps and landscape
  for(const p of [[-5.9,3.7],[-5.9,-2.9],[6,4.0]]){this.addCylinder(p[0],.40,p[1],.27,.5,'#d8ae73');this.addSphere(p[0],.95,p[1],.52,.65,.51,'#5dbd75');}
  // V28: mọi vật trang trí lấy vị trí đặt từ game state, không còn gắn cứng vào map.
  for(const id of s.decor){
    const item=E.DECOR_SLOTS?.[s.layout?.decor?.[id]];
    if(!item)continue;
    const [x,z]=this.mapPos(item.x,item.y);
    if(id==='plant'){this.addCylinder(x,.27,z,.30,.53,'#d58f62');this.addSphere(x,.80,z,.46,.56,.43,'#61b96f',6,10);}
    if(id==='flower'){this.addCylinder(x,.25,z,.26,.48,'#d68f85');for(let i=0;i<5;i++)this.addSphere(x+Math.sin(i*1.25)*.18,.60,z+Math.cos(i*1.25)*.18,.22,.24,.21,'#f091bf',5,8);}
    if(id==='mascot'){this.addSphere(x,.56,z,.38,.46,.34,'#f0bb77');this.addSphere(x-.24,.92,z,.14,.18,.14,'#e0a260');this.addSphere(x+.24,.92,z,.14,.18,.14,'#e0a260');}
    if(id==='lamp'){this.addCylinder(x,.95,z,.07,1.8,'#607789');this.addCone(x,1.84,z,.35,.50,'#fff2a1');}
    if(id==='poster'){this.addBox(x,.90,z,.80,1.40,.09,'#f4c45a');this.addBox(x,.92,z+.06,.63,1.10,.05,'#ed776f');}
  }
  if(s.equipment.includes('cold')){this.addBox(6.15,1,-1.8,1.15,2,1.2,'#b1e5f3');this.addBox(6.15,1.18,-1.17,.8,1.15,.05,'#8cbedc');}
  if(s.equipment.includes('storage'))this.addBox(5.6,1.5,-4.2,2.2,2.9,.82,'#7ca8b8');
  if(s.equipment.includes('cart')){this.addBox(2.4,.51,4.0,.74,.58,.49,'#62b9dc');for(const i of [-1,1])this.addCylinder(2.4+i*.24,.14,4.0,.12,.12,'#5d677d');}
  // street trees
  for(const [x,z,r] of [[-10,6,1],[-10,-5,.9],[8.1,-6,.9],[9.1,5,.8]])this.addTree(x,z,r);
  // chibi characters: smoothly animated between logical 1-sec update positions
  const ids=new Set();for(const person of [...s.staff,...s.customers].slice(0,s.settings.quality==='low'?9:this.slowFrames>=8?12:19)){ids.add(person.id);const target=this.mapPos(person.x,person.y);let old=this.visuals.get(person.id);if(!old){old={x:target[0],z:target[1],lastX:target[0],lastZ:target[1]};this.visuals.set(person.id,old);}
    old.x+=(target[0]-old.x)*.14;old.z+=(target[1]-old.z)*.14;person.motion=Math.hypot(target[0]-old.x,target[1]-old.z);this.addCharacter(old.x,old.z,person,t,!!person.role);
    if(person.role)this.points.push({kind:'staff',id:person.id,...this.project(old.x,1.4,old.z)});
  }
  for(const id of this.visuals.keys())if(!ids.has(id))this.visuals.delete(id);
 }
 render(s,t){if(!s)return;this.resizeIfNeeded();const gl=this.gl;this.m=cameraMatrix(this.yaw,this.zoom,this.canvas.width/this.canvas.height,this.pan);this.build(s,t);if(this.frame%2===0)this.drawLabels(s);
  // 9 interleaved floats / vertex: position, normal and color.
  const count=this.pos.length/3,packed=new Float32Array(count*9);for(let i=0;i<count;i++){for(let k=0;k<3;k++){packed[i*9+k]=this.pos[i*3+k];packed[i*9+3+k]=this.norm[i*3+k];packed[i*9+6+k]=this.cols[i*3+k];}}
  const hour=((s.minutes||480)/60)%24,daylight=clamp(Math.sin((hour-5)/15*Math.PI),.34,1);
  this.maxVertices=Math.max(this.maxVertices,count);gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.clearColor(.30+daylight*.33,.43+daylight*.41,.66+daylight*.28,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.useProgram(this.program);
  gl.uniform1f?.(this.loc.sun,daylight);gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,packed,gl.DYNAMIC_DRAW);
  for(const [loc,offset] of [[this.loc.position,0],[this.loc.normal,12],[this.loc.color,24]]){gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,3,gl.FLOAT,false,36,offset);}gl.uniformMatrix4fv(this.loc.matrix,false,new Float32Array(this.m));gl.drawArrays(gl.TRIANGLES,0,count);
 }
 drawLabels(s){if(!s.settings.showNames){this.labelLayer.replaceChildren();return;}const tags=[];for(const c of E.activeCats(s)){const [x,z]=this.mapPos(...E.categoryPos(s,c)),p=this.project(x,1.6,z);if(Math.abs(p.x)>1||Math.abs(p.y)>1)continue;tags.push(`<span class="world-label" style="left:${(p.x+1)*50}%;top:${(1-p.y)*50}%;border-color:${c.color}">${c.icon} ${c.name} <small>${s.stock[c.id]||0}</small></span>`);}
  for(const m of s.staff){const o=this.visuals.get(m.id);if(!o)continue;const p=this.project(o.x,2.2,o.z);if(Math.abs(p.x)>1||Math.abs(p.y)>1)continue;const words=(m.bubble||m.task||'').slice(0,32).replace(/[<>&"']/g,'');tags.push(`<span class="npc-bubble" style="left:${(p.x+1)*50}%;top:${(1-p.y)*50}%">${words}</span>`);}
  this.labelLayer.innerHTML=tags.join('');}
 resizeIfNeeded(force=false){const q=this.getState()?.settings?.quality,dpr=Math.min(devicePixelRatio||1,q==='low'?1:q==='high'?1.6:this.slowFrames>=8?.85:1.2);const w=Math.max(1,Math.round((this.canvas.clientWidth||800)*dpr)),h=Math.max(1,Math.round((this.canvas.clientHeight||400)*dpr));if(force||this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}}
 animate(time){if(!this.running)return;const quality=this.getState()?.settings?.quality;const gap=quality==='low'?54:this.slowFrames>=8?45:33;if(time-this.last>gap){try{const state=this.getState();this.render(state,state?.settings?.reducedMotion?0:time);if(this.last){const instantaneous=Math.min(60,1000/(time-this.last));this.fps=this.fps?Math.round(this.fps*.85+instantaneous*.15):Math.round(instantaneous);this.slowFrames=this.fps<20?Math.min(20,this.slowFrames+1):Math.max(0,this.slowFrames-1);}this.last=time;this.frame++;}catch(error){console.error('3D:',error);this.stop();root.dispatchEvent(new CustomEvent('store3dfailed'));return;}}this.raf=requestAnimationFrame(t=>this.animate(t));}
 stop(){this.running=false;cancelAnimationFrame(this.raf);window.removeEventListener('resize',this.resize);this.canvas.removeEventListener?.('pointerdown',this.down);this.canvas.removeEventListener?.('pointermove',this.move);this.canvas.removeEventListener?.('pointerup',this.up);this.canvas.removeEventListener?.('webglcontextlost',this.lost);this.labelLayer?.remove();}
}
root.StoreScene3D=Scene3D;
})(typeof window!=='undefined'?window:globalThis);
