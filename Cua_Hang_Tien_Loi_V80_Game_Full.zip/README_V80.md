# CỬA HÀNG TIỆN LỢI — V80 (Mobile Growth Edition)

## Giả định thiết kế
- Game mô phỏng quản lý **chơi đơn**, sử dụng **VNĐ ảo**, tiếp nối bản V75; không có giao dịch thật.
- Người chơi khởi đầu với 10.000.000đ, 4 khu bán hàng (Đồ uống, Bánh kẹo, Sữa, Trái cây), hai nhân viên An/Bình.
- Cửa hàng mở rộng 4 cấp; diện tích là chỉ số quản lý trong game, không đại diện tỷ lệ pixel thực tế của màn hình.
- Cửa hàng phải đóng cửa trong khi thi công. Có điều kiện cấp độ và tiền; thanh toán vốn nâng cấp không hoàn lại.
- Tồn kho tính **theo ngành**, chưa theo từng mã SKU của mỗi món mới. Hình minh họa SKU không làm phát sinh kho riêng.

## Bản đồ quy hoạch và giới hạn
| Cấp | Diện tích | Khu hàng | Nhân viên | Cấp quản lý tối thiểu | Chi phí nâng cấp |
|---|---:|---:|---:|---:|---:|
| 1 — Tiệm khởi nghiệp | 64 m² | 4 | 2 | 1 | 0đ |
| 2 — Gian hàng mở rộng | 96 m² | 6 | 4 | 2 | 2.600.000đ |
| 3 — Siêu thị mini | 144 m² | 8 | 6 | 4 | 4.800.000đ |
| 4 — Trung tâm tiện lợi | 192 m² | 10 | 8 | 6 | 8.200.000đ |

Giá tuyển nhân viên: 450.000đ cho vị trí thứ 3–4; 650.000đ vị trí thứ 5–6; 800.000đ vị trí thứ 7–8. Nhân sự và nâng cấp phải tuân thủ tiền mặt có sẵn.

## Ngành hàng mở khóa
- Cấp 1: Đồ uống, Bánh kẹo, Sữa, Trái cây.
- Cấp 2: Mì gói, Đông lạnh.
- Cấp 3: Chăm sóc cá nhân, Gia dụng.
- Cấp 4: Cà phê, Ăn nhanh.

Các hoạt động đặt hàng, giao hàng, trưng bày lên kệ và khách mua tiếp tục sử dụng động cơ V75.

## Hướng dẫn sử dụng
- Mở file `index.html` trong trình duyệt có hỗ trợ JavaScript, hoặc dùng bản độc lập `Cua_Hang_Tien_Loi_V80_Cho_Ngay.html` có chứa sẵn mã và sprite.
- Vào **Thêm → Mở rộng** hoặc thanh chức năng **Mở rộng** trong màn hình ngang.
- Đạt cấp quản lý quy định, đóng cửa rồi chọn **Xây dựng**, chờ game mở 2 khu mới.
- Vào **Nhân sự** hoặc màn hình Mở rộng để **Tuyển thêm** và **Phân công** người mới.
- Đặt hàng cho khu mới rồi chờ nhân viên nhận/bổ sung. Kệ chỉ hiện hàng khi có tồn.
- **Lưu dữ liệu:** Tự động lưu trên thiết bị nếu trình duyệt cho phép, tương thích định dạng V75. Sao lưu thủ công trước khi đổi trình duyệt.

## Cấu trúc dự án
- `src/engine.js`: tiền, kho, khách, NPC và kinh tế.
- `src/growth_v80.js`: quy hoạch 4 cấp, ngành hàng, nhân sự, điều kiện đầu tư, tương thích bản lưu.
- `src/growth_scene_v80.js`: phần sàn mới ở cả Canvas và WebGL.
- `src/app.js`: cửa sổ mở rộng, tuyển người và điều khiển cảm ứng.
- `assets/art/`, `assets/avatars/`, `assets/merch/`, `assets/growth/`: hình sản phẩm, nhân viên, bản đồ mở rộng; `assets/models/` chứa GLB nguồn.
- `tests/`: kiểm thử logic và hồi quy.

## Kiểm thử và giới hạn
- Tại bước đóng gói: 183/183 bài kiểm thử Node đạt; 3/3 kích thước điện thoại Chromium đạt luồng chạm mô phỏng.
- Ảnh chụp tier 4 trong bộ bàn giao dùng **dữ liệu kiểm thử giả lập cấp cao**, không phải vốn ban đầu người chơi.
- **Chưa kiểm chứng** Safari trên thiết bị iPhone vật lý, FPS GPU WebGL thực tế, hoặc nhân vật 3D rigged chất lượng thương mại.
- Không thực hiện hosting/truy cập trong giai đoạn này theo yêu cầu.
