# BỘ TÀI NGUYÊN MỸ THUẬT V75

Bộ tài nguyên mới tạo riêng cho dự án, theo phong cách minh họa chibi màu sáng.

- **18 hình sản phẩm** cho sáu ngành hàng (ba lựa chọn/nhóm), mỗi hình có nguồn SVG và bản PNG trong `assets/merch/`.
- **4 bảng sự kiện** (nắng nóng, mua sắm gia đình, mưa, ngày thường), dạng SVG/PNG.
- **Bản xem trước**: `V75_PRODUCT_ASSETS_PREVIEW.png`.
- Assets này đã nối trực tiếp trong bảng chọn mặt hàng; icon được hiển thị trên kệ 2.5D nếu hàng có tồn và mặt hàng đó được người chơi chọn.
- File PNG, SVG được cung cấp để dễ chỉnh sửa. Bộ này không bao gồm font chữ bản quyền hay sprite sheet lấy từ game khác.
- Tên sản phẩm là hư cấu/mô tả chung, không đại diện cho thương hiệu thật.

**Quan trọng:** Hình SKU chỉ đại diện mặt hàng trưng bày; engine hiện vận hành tồn kho ở cấp ngành, không giả định mỗi SKU có lượng nhập/xuất độc lập.
