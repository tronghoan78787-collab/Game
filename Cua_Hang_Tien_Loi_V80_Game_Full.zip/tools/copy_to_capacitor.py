from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1];target=root/'ios-shell/www'
target.mkdir(parents=True,exist_ok=True)
for f in ['index.html','sw.js','manifest.webmanifest','health.json']:
    shutil.copy2(root/f,target/f)
for d in ['src','assets']:
    if (target/d).exists():shutil.rmtree(target/d)
    shutil.copytree(root/d,target/d)
print('Prepared',target)
