from pathlib import Path
import re,json
R=Path(__file__).resolve().parents[1]
index=(R/'index.html').read_text()
index=index.replace('<title>Cửa Hàng Tiện Lợi — Chibi Tycoon V48 iOS Release Candidate</title>','<title>Cửa Hàng Tiện Lợi — Chibi Tycoon V54 iOS Operations</title>')
index=index.replace('<button data-panel="advisor" class="nav-item"><span>🧠</span><b>Trợ lý</b></button>','<button data-panel="advisor" class="nav-item"><span>🧠</span><b>Trợ lý</b></button>\n    <button data-panel="operations" class="nav-item"><span>📋</span><b>Vận hành</b></button>')
# Ops after director, so overrides complete wrapping chain.
index=index.replace('<script src="src/director.js"></script>','<script src="src/director.js"></script>\n<script>window.STORE_OPERATIONS_STAGE=54;</script>\n<script src="src/operations.js"></script>')
(R/'index.html').write_text(index)
appfile=R/'src/app.js';s=appfile.read_text()
s=s.replace("const releaseVersion='48.0.0-ios';","const releaseVersion='54.0.0-ios';")
s=s.replace("const names={advisor:'🧠 Trợ lý điều hành'","const names={operations:'📋 Trung tâm vận hành',finance:'💰 Sổ dòng tiền',advisor:'🧠 Trợ lý điều hành'")
s=s.replace("case 'advisor':return viewAdvisor();","case 'operations':return viewOperations();case 'finance':return viewFinance();case 'advisor':return viewAdvisor();")
s=s.replace('V48 iOS Release Candidate','V54 iOS Operations Beta')
s=s.replace("'cua-hang-tien-loi-ios-v48-backup.json'","'cua-hang-tien-loi-ios-v54-backup.json'")
s=s.replace('<button class="game-button" data-panel="staff">👥 Tuyển và phân ca</button>','<button class="game-button" data-panel="staff">👥 Tuyển và phân ca</button><button class="game-button green" data-panel="operations">📋 Trung tâm vận hành</button>')
s=s.replace('const pending=S.pending.length?', 'const pending=S.pending.length?')
s=s.replace('<div class="grid">${E.activeCats(S).map(c=>{\n    const q=UI.quantities[c.id]||24;', '<div class="chips"><button class="game-button gold" data-panel="operations">📊 Định mức và nhập hàng tự động</button><button class="game-button" data-panel="finance">💰 Xem sổ tiền</button></div><div class="grid">${E.activeCats(S).map(c=>{\n    const q=UI.quantities[c.id]||24;')
# Insert view functions before viewSettings as they are function declarations hoisted
marker='function viewSettings(){'
assert marker in s
newviews=r'''function viewOperations(){
  const rows=E.operationsForecast(S),staff=E.staffOperationsReport(S),integrity=E.operationsIntegrity(S);
  const service=S.operations.serviceStandard;
  return `<div class="info-strip"><span>📦 Kho còn ${E.availableRoom(S)} chỗ</span><span>💵 Tiền dự phòng ${E.money(S.operations.reserveCash)}</span><span>📈 ${S.stats.served} khách đã phục vụ</span></div>
    <div class="hint">Giả định V50: dự báo dựa trên hóa đơn gần đây và bán hàng theo ngành. Hàng tươi được giới hạn lô nhập để tránh quá hạn; không tự đặt khi dưới mức tiền dự phòng. Đơn hàng được trừ tiền ảo ngay khi đặt.</div>
    <div class="row between"><strong>Quỹ tiền không sử dụng để đặt hàng</strong><select class="input" style="width:auto" data-reserve="1">${[0,500000,1000000,1200000,1500000,2000000,3000000].map(n=>`<option value="${n}" ${n===S.operations.reserveCash?'selected':''}>${E.money(n)}</option>`).join('')}</select></div>
    <div class="grid">${rows.map(r=>`<div class="game-card"><span class="icon">${r.icon}</span><h3>${r.name}</h3>
      <p>Đang có: <b>${r.onHand}</b> · Đang giao: <b>${r.incoming}</b></p>
      <p>Đã bán gần đây: ${r.soldRecent} · Dự báo: ${r.dailyVelocity} SP/ngày</p>
      <div class="row between"><label>Ngưỡng đặt <select data-rule-min="${r.id}" class="input">${[0,6,10,12,18,24,36,48].map(n=>`<option value="${n}" ${r.minimum===n?'selected':''}>${n} SP</option>`).join('')}</select></label>
      <label>Mục tiêu <select data-rule-target="${r.id}" class="input">${[12,18,24,36,48,72,96].map(n=>`<option value="${n}" ${r.target===n?'selected':''}>${n} SP</option>`).join('')}</select></label></div>
      <p>${r.nearExpiry?'⚠️ Gần hạn: '+r.nearExpiry+' SP. ':''}${r.reason}</p>
      <button class="game-button green full" data-replenish="${r.id}" ${!r.canOrder?'disabled':''}>${r.pack?'Nhập đề xuất '+r.pack+' · '+E.money(r.orderCost):'Chưa cần nhập'}</button></div>`).join('')}</div>
    <button class="game-button green full" data-action="replenishAll">📦 ĐẶT HÀNG CẦN THIẾT THEO ĐỊNH MỨC</button>
    <div class="section-heading">👩🏻‍💼 Quy trình phục vụ</div>
    <div class="chips">${[['customer','🤝 Khách hàng trước'],['balanced','⚖️ Cân bằng'],['shelf','🛒 Ưu tiên kệ']].map(([id,name])=>`<button class="chip ${service===id?'active':''}" data-service-standard="${id}">${name}</button>`).join('')}</div>
    <div class="hint">Quy trình hướng dẫn AI ưu tiên các loại công việc. NPC vẫn xử lý các tình huống khẩn cấp dựa trên thang điểm của mô hình hành vi.</div>
    <div class="section-heading">📊 Hoạt động nhân viên (ước tính từ mô phỏng)</div>
    <div class="grid two">${staff.map(m=>`<div class="game-card"><strong>${safe(m.name)} · ${m.role==='cashier'?'Thu ngân':m.role==='operator'?'Vận hành':'Nghỉ'}</strong>
      <p>${safe(m.focus)}</p><p>🧾 Thanh toán ${m.checkouts} · 📦 Xếp kệ ${m.restocked} · 🧹 Vệ sinh ${m.cleaned}</p><p>❤️ Tâm trạng ${m.mood}% · ⚡ Thể lực ${m.energy}%</p></div>`).join('')}</div>
    <div class="section-heading">🔒 Kiểm tra dữ liệu</div><div class="game-card"><strong>${integrity.valid?'✅ Dữ liệu hợp lệ':'⚠️ Cần kiểm tra bản lưu'}</strong>
    <p>${integrity.errors.length?integrity.errors.map(safe).join(' · '):'Không phát hiện lỗi nghiêm trọng trong tồn kho và sổ tiền.'}</p>
    <p>${integrity.warnings.length?integrity.warnings.map(safe).join(' · '):'Không có cảnh báo bổ sung.'}</p></div>
    <div class="chips"><button class="game-button" data-panel="finance">💰 Xem sổ dòng tiền</button><button class="game-button" data-panel="report">📈 Báo cáo chung</button></div>`;
}
function viewFinance(){
  const audit=E.financeAudit(S),rows=E.operationsForecast(S),inventory=E.inventoryAudit(S);
  const valuation=inventory.reduce((n,r)=>n+r.stockValue,0);
  return `<div class="hint">Giả định V49: sổ dòng tiền mới ghi các nghiệp vụ kể từ lúc nâng cấp V49, không tạo giao dịch lịch sử giả. Giá trị tồn kho = số hàng đang có × giá nhập; không bao gồm hàng đang giao. Đây là báo cáo game, không phải chứng từ kế toán thực.</div>
  <div class="grid two"><div class="report-stat"><small>💰 Tiền mặt hiện tại</small><b>${E.money(S.cash)}</b></div>
    <div class="report-stat"><small>📦 Giá trị hàng tồn</small><b>${E.money(valuation)}</b></div>
    <div class="report-stat"><small>📈 Lãi gộp tích lũy</small><b>${E.money(S.stats.revenue-S.stats.cogs)}</b></div>
    <div class="report-stat"><small>🏪 Doanh thu hôm nay</small><b>${E.money(S.today.revenue)}</b></div></div>
  <div class="info-strip"><span>Đã ghi ${audit.recorded} dòng tiền</span><span>${audit.valid?'✅ Khớp số dư':'⚠️ Chênh lệch '+E.money(Math.abs(audit.difference))}</span><span>Ghi từ ngày ${audit.firstDay}</span></div>
  <div class="section-heading">Sổ giao dịch gần nhất</div>
  ${audit.entries.length?audit.entries.slice(0,75).map(e=>`<div class="receipt-card"><div class="row between"><b>Ngày ${e.day} · ${safe(e.type)}</b><b style="color:${e.delta>0?'#287c4f':'#a34b33'}">${e.delta>0?'+':''}${E.money(e.delta)}</b></div><small>${safe(e.detail||'Giao dịch cửa hàng')} · #${e.seq}</small></div>`).join(''):'<div class="game-card">Chưa có giao dịch nào từ khi nâng cấp hệ thống sổ tiền.</div>'}
  <div class="section-heading">Tỷ trọng hàng hóa</div><div class="grid">${rows.map(r=>`<div class="game-card"><b>${r.icon} ${r.name}</b><p>Tồn ${r.onHand} SP · Dự kiến ${r.dailyVelocity}/ngày</p></div>`).join('')}</div>`;
}
'''
s=s.replace(marker,newviews+marker)
s=s.replace("  if(btn.dataset.priority){act({type:'PRIORITY',id:btn.dataset.priority});return;}","  if(btn.dataset.priority){act({type:'PRIORITY',id:btn.dataset.priority});return;}\n  if(btn.dataset.replenish){act({type:'REPLENISH',id:btn.dataset.replenish});return;}\n  if(btn.dataset.serviceStandard){act({type:'SET_SERVICE_STANDARD',standard:btn.dataset.serviceStandard});return;}")
s=s.replace("    case 'autoOrder':act({type:'AUTO_ORDER'});break;","    case 'autoOrder':act({type:'AUTO_ORDER'});break;\n    case 'replenishAll':act({type:'REPLENISH'});break;")
s=s.replace("  if(e.target.matches('[data-shift-staff]'))act({type:'SET_SHIFT',staffId:e.target.dataset.shiftStaff,shift:e.target.value});", "  if(e.target.matches('[data-reserve]'))act({type:'SET_CASH_RESERVE',amount:Number(e.target.value)});\n  if(e.target.matches('[data-rule-min],[data-rule-target]')){const id=e.target.dataset.ruleMin||e.target.dataset.ruleTarget;const card=e.target.closest('.game-card');const minimum=Number(card.querySelector('[data-rule-min]').value),target=Number(card.querySelector('[data-rule-target]').value);act({type:'SET_REORDER_RULE',id,minimum,target});}\n  if(e.target.matches('[data-shift-staff]'))act({type:'SET_SHIFT',staffId:e.target.dataset.shiftStaff,shift:e.target.value});")
appfile.write_text(s)
# add css for operations and additional nav button fits in landscape
css=R/'src/style.css'
css.write_text(css.read_text()+'''\n/* V49–V54: bảng vận hành tích hợp trong HUD, kéo cuộn ngang nhẹ trên điện thoại nhỏ. */\n.bottom-nav{overflow-x:auto;scrollbar-width:none;justify-content:flex-start}\n.bottom-nav::-webkit-scrollbar{display:none}\n.bottom-nav .nav-item{flex:1 0 8%;min-width:45px}\n.modal-body .game-card select.input{max-width:110px;min-height:37px;padding:3px;border-radius:7px;background:#fff}\n@media (max-width:760px) and (orientation:landscape){.bottom-nav .nav-item{min-width:40px}.bottom-nav .nav-item b{font-size:7px}.bottom-nav{padding-left:3px;padding-right:3px}}\n@media(orientation:portrait){.modal-body .game-card select.input{max-width:95px}}\n''')
# Build script needs include ops module.
b=R/'tools/build_standalone.py';t=b.read_text().replace("'director.js','app.js'","'director.js','operations.js','app.js'")
t=t.replace("out=ROOT.parent/'cua_hang_tien_loi_ios_V48_choi_ngay.html'","out=ROOT.parent/'cua_hang_tien_loi_ios_V54_choi_ngay.html'")
b.write_text(t)
# offline update
sw=R/'sw.js';txt=sw.read_text().replace('ios-v48.0','ios-v54.0').replace("'./src/director.js'","'./src/director.js','./src/operations.js'")
sw.write_text(txt)
# versions and health
pkg=R/'package.json';j=json.loads(pkg.read_text());j['version']='54.0.0';j['description']='iOS-first convenience store simulator with inventory replenishment, cash ledger and NPC operations';pkg.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
for f in ['health.json','manifest.webmanifest','netlify.toml','_headers']:
 p=R/f
 if p.exists(): p.write_text(p.read_text().replace('48.0.0','54.0.0').replace('v48','v54'))
print('upgraded',len(s))
