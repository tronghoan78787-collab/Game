"""Build a playable single HTML bundle for constrained mobile HTML previews.
This is NOT a hosted iOS Safari acceptance test. Static website remains canonical.
"""
from pathlib import Path
import re,json,base64
R=Path(__file__).resolve().parents[1]
html=(R/'index.html').read_text(encoding='utf-8')
css=(R/'src/style.css').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="src/style.css">','<style>\n'+css+'\n</style>')
svg_files=(R/'assets/avatars').glob('*.svg')
avatars={p.stem:'data:image/svg+xml;base64,'+base64.b64encode(p.read_bytes()).decode() for p in svg_files}
# Only PNG needed in standalone: 69 sprites, ca. 2MB. Embedded as UTF-8 JS variable.
art_files=(R/'assets/art').glob('*.png')
art={p.stem:'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode() for p in art_files}
initial='<script src="src/ios.js"></script>'
html=html.replace(initial,'<script>window.EMBEDDED_AVATARS='+json.dumps(avatars)+';window.EMBEDDED_SPRITES='+json.dumps(art)+';</script>\n'+initial)
for name in ['ios.js','vault.js','engine.js','motion.js','scene.js','model_assets.js','scene3d.js','expansion.js','audio.js','director.js','operations.js','app.js']:
  code=(R/'src'/name).read_text(encoding='utf-8').replace('</script','<\\/script')
  target='<script src="src/'+name+'"></script>'
  assert target in html,name
  html=html.replace(target,'<script>\n'+code+'\n</script>')
icon='data:image/png;base64,'+base64.b64encode((R/'assets/icon-192.png').read_bytes()).decode()
html=html.replace('href="assets/icon-192.png"','href="'+icon+'"')
html=re.sub(r'\s*<link rel="manifest" href="manifest.webmanifest">','',html)
out=R.parent/'cua_hang_tien_loi_V65_CHOI_NGAY.html'
out.write_text(html,encoding='utf-8')
print(str(out),out.stat().st_size,'bytes,',len(art),'art images')
assert 'src="src/' not in html
