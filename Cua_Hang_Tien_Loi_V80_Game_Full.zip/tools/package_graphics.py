from pathlib import Path
import shutil,zipfile,json,re
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent
STAGES={56:'Tài nguyên chibi và kệ động',57:'Cửa hàng isometric và tương tác NPC',58:'HUD thiết kế số 2',59:'Cấu hình đồ họa và offline iOS',60:'Bản tích hợp và kiểm thử cảm ứng'}
original=OUT/'cua_hang_tien_loi_mobile_V55'
for stage,title in STAGES.items():
    target=OUT/f'cua_hang_tien_loi_graphics_stage_V{stage}'
    if target.exists():shutil.rmtree(target)
    target.mkdir(parents=True)
    for fname in ['index.html','manifest.webmanifest','sw.js','health.json','404.html','_headers','_redirects','robots.txt']:
        f=ROOT/fname
        if f.exists():shutil.copy2(f,target/fname)
    # Runtime only (website is self-contained after deploying on static HTTPS hosting)
    shutil.copytree(ROOT/'src',target/'src')
    shutil.copytree(ROOT/'assets',target/'assets',ignore=shutil.ignore_patterns('*.svg') if stage<60 else None)
    # SVG avatars are runtime assets; always copy them.
    (target/'assets/avatars').mkdir(exist_ok=True)
    for avatar in (ROOT/'assets/avatars').glob('*.svg'):shutil.copy2(avatar,target/'assets/avatars'/avatar.name)
    # Revisions are cumulative: early stages retain old HUD and cache rules.
    if stage<58:shutil.copy2(original/'src/style.css',target/'src/style.css')
    if stage==56:
        f=target/'src/scene.js';code=f.read_text().replace('    this.drawRetailEffects(s,time);','');f.write_text(code)
    if stage<59:
        shutil.copy2(original/'sw.js',target/'sw.js')
        # Changing the SW cache name ensures isolated upgrade path.
        f=target/'sw.js';s=f.read_text().replace('cua-hang-tien-loi-mobile-v55.0',f'cua-hang-tien-loi-art-v{stage}');f.write_text(s)
    f=target/'index.html';s=f.read_text().replace('V60 Chibi Art',f'V{stage} Chibi Art');f.write_text(s)
    f=target/'src/app.js';s=f.read_text().replace('60.0.0-chibi-art',f'{stage}.0.0-chibi-art');f.write_text(s)
    if stage==60:
        for d in ['tests','tools']:
            shutil.copytree(ROOT/d,target/d,ignore=shutil.ignore_patterns('qa_*','V60_*','touch_v60.py') if d=='tools' else None)
        for file in ['README_V60.md','MILESTONES_V56_V60.md','ART_DIRECTION_V60.md','QA_GRAPHICS_V60.md']:
            shutil.copy2(ROOT/file,target/file)
    (target/'MILESTONE.md').write_text(f'''# V{stage} — {title}\n\n**Giả định:** Ưu tiên iPhone; tất cả nút là phần tử tương tác. Dữ liệu save và game economy vẫn tương thích V55.\n\nMốc {stage}: {title.lower()}.\n\n**Cách chạy:** đưa cả thư mục lên HTTPS; mở index.html bằng Safari. File HTML nội bộ trong ứng dụng Tệp có thể không thực thi JavaScript.\n\n**Giới hạn:** Không kiểm thử trên Safari iPhone vật lý, không có IPA đã ký, WebGL thực nghiệm.\n''',encoding='utf-8')
    archive=OUT/f'cua_hang_tien_loi_V{stage}_Graphics.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in sorted(target.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(target))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None,stage
        assert 'index.html' in z.namelist()
        assert 'assets/art/an_idle_happy.png' in z.namelist()
    print(stage,archive.stat().st_size,'bytes')
# Source full: website + source + ios project + QA screenshots/docs, excludes duplicate generated SVG art in release zip?
full=OUT/'cua_hang_tien_loi_V56_V60_FULL_SOURCE.zip'
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if str(rel).startswith(('qa_','V60_GAMEPLAY_','V60_ORDER_','V60_STAFF_','V60_SETTINGS_','V60_iphone','V60_small')):continue
        if 'node_modules' in p.parts or '__pycache__' in p.parts:continue
        z.write(p,'project/'+str(rel))
    for p in sorted(OUT.glob('cua_hang_tien_loi_V[5-6][0-9]_Graphics.zip')):
        z.write(p,'milestones/'+p.name)
with zipfile.ZipFile(full) as z:assert z.testzip() is None
print('FULL',full.stat().st_size)
# Compact mobile package single HTML + README instructions
mobile=OUT/'cua_hang_tien_loi_V60_MOBILE_CHOI_NGAY.zip'
with zipfile.ZipFile(mobile,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    z.write(OUT/'cua_hang_tien_loi_V60_CHOI_NGAY.html','index.html')
    z.writestr('HUONG_DAN.txt','Cửa Hàng Tiện Lợi V60: Mở index.html bằng trình duyệt có hỗ trợ chạy JavaScript. Trên iPhone nên sử dụng bản Website đưa lên HTTPS, không mở bằng xem trước trong Tệp.\n')
with zipfile.ZipFile(mobile) as z:assert z.testzip() is None
print('MOBILE',mobile.stat().st_size)
# side by side comparison screenshots from actual Chromium runs; do not alter game screens.
a=Image.open(original/'V55_iphone_plus_landscape.png').convert('RGB')
b=Image.open(ROOT/'V60_iphone_plus_landscape.png').convert('RGB')
width=850;height=396
a=a.resize((width,height),Image.Resampling.LANCZOS)
b=b.resize((width,height),Image.Resampling.LANCZOS)
img=Image.new('RGB',(width*2,440),'#fff')
img.paste(a,(0,44));img.paste(b,(width,44))
d=ImageDraw.Draw(img);d.rectangle([0,0,width*2,44],fill='#234c80')
d.text((15,11),'V55 - đồ họa thủ tục',fill='white')
d.text((width+15,11),'V60 - nhân vật/kệ sprite và HUD',fill='white')
img.save(ROOT/'COMPARE_V55_V60.png',optimize=True)
print('COMPARE',img.size)
