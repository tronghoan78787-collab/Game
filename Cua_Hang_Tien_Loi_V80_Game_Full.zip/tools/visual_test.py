from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
h=(R.parent/'cua_hang_tien_loi_V60_CHOI_NGAY.html').read_text(encoding='utf8')
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  for w,hgt,label in [(844,390,'landscape'),(390,844,'portrait'),(667,375,'small')]:
    page=browser.new_page(viewport={'width':w,'height':hgt},device_scale_factor=1,is_mobile=True,has_touch=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(h,wait_until='domcontentloaded')
    page.wait_for_timeout(1600)
    data=page.evaluate('''() => ({ready:!!window.ConvenienceGame, mode:document.body.className, money:document.querySelector('#money')?.textContent, canvas:[document.querySelector('#scene').width,document.querySelector('#scene').height],sprites:Object.keys(window.EMBEDDED_SPRITES||{}).length})''')
    print(label,data,'errors',errors[:5])
    page.screenshot(path=str(R/f'qa_{label}.png'))
    page.close()
  browser.close()
