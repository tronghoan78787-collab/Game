from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
h=(R.parent/'cua_hang_tien_loi_V60_CHOI_NGAY.html').read_text(encoding='utf8').replace('<head>','<head><script>window.__CHIBI_QA__=true;</script>',1)
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  for w,he,name in [(844,390,'stocked_landscape'),(390,844,'stocked_portrait')]:
    page=browser.new_page(viewport={'width':w,'height':he},device_scale_factor=1,is_mobile=True,has_touch=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(h);page.wait_for_timeout(500)
    output=page.evaluate('''() => {
      const game=window.ConvenienceGame; const ids=['drink','snack','milk','fruit'];
      for(const id of ids) game.dispatch({type:'ORDER',id,qty:24});
      game.advanceForTest(30);
      const s=game.getState();return {stock:s.stock,warehouse:s.warehouse,pending:s.pending.length,renderer:game.renderer()};
    }''')
    print(name,output,errors)
    page.locator('.coach-close').click(force=True) if page.locator('.coach-close').is_visible() else None
    page.wait_for_timeout(650)
    page.screenshot(path=str(R/f'qa_{name}.png'))
    page.close()
  browser.close()
