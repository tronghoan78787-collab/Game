#!/usr/bin/env python3
"""V56-V60: deterministic original vector art authored for Cửa Hàng Tiện Lợi.
Creates offline SVG sprites and 2x PNG previews. No external image downloads.
"""
from pathlib import Path
import math, random
import cairosvg
ROOT=Path(__file__).resolve().parents[1]
DIR=ROOT/'assets'/'art';DIR.mkdir(parents=True,exist_ok=True)

HEADER='''<svg xmlns="http://www.w3.org/2000/svg" width="220" height="205" viewBox="0 0 220 205"><defs>
 <linearGradient id="side" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#d3a87f"/><stop offset="1" stop-color="#84614d"/></linearGradient>
 <linearGradient id="metal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#f5fbff"/><stop offset=".48" stop-color="#c2e6f0"/><stop offset="1" stop-color="#7eb6d2"/></linearGradient>
 <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#c7f9ff" stop-opacity=".5"/><stop offset=".47" stop-color="#82d6f4" stop-opacity=".08"/><stop offset="1" stop-color="#2d7cad" stop-opacity=".35"/></linearGradient>
 <linearGradient id="shine" x1="0" y1="0" x2=".5" y2="1"><stop stop-color="#fff" stop-opacity=".8"/><stop offset="1" stop-color="#fff" stop-opacity=".0"/></linearGradient>
 <linearGradient id="cap" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff9e8"/><stop offset="1" stop-color="#ffe5bc"/></linearGradient>
 <filter id="shade" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6"/></filter>
 <filter id="shadow" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="1" dy="4" stdDeviation="3" flood-color="#3f4a53" flood-opacity=".3"/></filter>
 </defs>
'''

def R(x,y,w,h,fill,r=2,stroke='none',sw=1):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def P(points,fill,stroke='none',sw=1):return f'<polygon points="{points}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"/>'
def T(x,y,t,sz=12,color='#fff',weight=900,anchor='middle'):return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial, Helvetica, sans-serif" font-size="{sz}" font-weight="{weight}" paint-order="stroke" stroke="#284965" stroke-opacity=".28" stroke-width="1.6" fill="{color}">{t}</text>'

def bottle(x,y,col,size=1):
 return f'<g transform="translate({x} {y}) scale({size})">'+R(-6,-20,12,22,col,3,'#f7ffff',.65)+R(-4,-25,8,6,'#e9f4f5',1)+R(-6,-10,12,9,'#ffffff',2)+R(-3,-8,6,2,'#e7c57c',1)+R(-2,-17,4,3,'#ffffff',1)+'</g>'
def boxproduct(x,y,color,sz=1,kind='snack'):
 body=R(-7,-19,14,21,color,2,'#fff4cb',.8)+P('-7,-19 -2,-24 12,-22 7,-19','#fff0bd')+R(-5,-12,10,6,'#fff7d5',2)
 if kind=='snack':body+='<circle cx="0" cy="-9" r="2.4" fill="#eaa35c"/>'
 else:body+=R(-4,-11,8,3,'#70bfd1')
 return f'<g transform="translate({x} {y}) scale({sz})">{body}</g>'
def fruit(x,y,color,sz=1):
 return f'<g transform="translate({x} {y}) scale({sz})"><ellipse cy="-3" rx="8" ry="7" fill="{color}" stroke="#8f744d" stroke-width=".7"/><path d="M0 -8 Q2 -15 9 -12 Q7 -6 1 -8" fill="#77b965"/><path d="M-3 -6 Q-5 -1 -3 0" stroke="#fff" stroke-width="1.5" opacity=".4"/></g>'

def shelf(cat,level):
 # level: empty, low, full. shelves remain visibly empty if no stock.
 colors={'drink':('#27a7ef','#1857a5','ĐỒ UỐNG'), 'snack':('#fa913e','#b95821','BÁNH KẸO'), 'milk':('#4bc7ee','#4172cf','SỮA TƯƠI'), 'fruit':('#74ba52','#3f8f41','TRÁI CÂY'), 'noodle':('#ef8165','#b74b52','MÌ GÓI'), 'frozen':('#7fc3fa','#3c71c2','ĐÔNG LẠNH')}
 primary,dark,title=colors[cat]
 out=HEADER
 out+=f'<ellipse cx="115" cy="186" rx="91" ry="12" fill="#33454b" opacity=".22" filter="url(#shade)"/>'
 if cat in ['drink','milk','frozen']:
  # premium glass-door refrigerated case - 3D cabinet
  out+=P('21,45 42,31 200,41 180,55','#ffffff','#6f95aa',2)
  out+=P('180,55 200,41 200,171 180,187','url(#metal)','#6898af',2)
  out+=R(21,50,160,135,'url(#metal)',8,'#5d96b4',3)
  out+=R(30,59,143,116,'#284e76',5,'#e4ffff',3)
  for row in range(3):
   out+=R(34,92+row*33,134,4,'#daeaf2',1)
  if level!='empty':
   count=7 if level=='low' else 21
   palette=['#ff7478','#5da7ef','#ffe18c','#8ed5b4','#f5f6e5','#e9a2c9','#ffb45b'] if cat=='drink' else ['#ffffff','#86ccef','#f5e7a9','#a1e3da','#b5c9ff']
   for i in range(count):
    r,c=divmod(i,7)
    x=45+c*18.4;y=88+r*33
    if cat=='drink':out+=bottle(x,y,palette[i%len(palette)],1)
    elif cat=='milk':out+=boxproduct(x,y,palette[i%len(palette)],.92,'milk')
    else:out+=boxproduct(x,y,palette[i%len(palette)],.92,'frozen')
  out+=R(31,59,142,115,'url(#glass)',4)
  out+=P('34,62 60,62 42,170 31,170','#ffffff',sw=0).replace('fill="#ffffff"','fill="#ffffff" opacity=".21"')
  out+=R(95,60,3,115,'#eafaff',1)
  out+=R(100,100,4,31,'#d6f3fa',2)
  out+=R(21,181,160,7,'#6f99ad',3)
  out+=R(15,25,169,28,primary,7,'#e9ffff',3)
  out+=P('184,25 201,35 200,56 184,53',dark,'#d7f9ff',2)
  out+=R(30,30,145,6,'#ffffff',3).replace('fill="#ffffff"','fill="#ffffff" opacity=".36"')
 else:
  # double-sided snack racks + wooden fruit bins
  out+=P('23,55 48,38 198,50 173,66','#f6ecd7','#b78c62',3)
  out+=P('173,66 198,50 198,167 173,188','url(#side)','#996e4d',3)
  out+=R(22,57,153,129,'#e9caa1',5,'#9a7659',3)
  for r in range(3):
   yy=83+r*34
   out+=R(30,yy,135,28,'#fff2df',2,'#aa815d',2)
   if cat=='fruit':
    out+=P(f'29,{yy+23} 163,{yy+23} 169,{yy+34} 35,{yy+34}','#a97848','#8d6343',1)
    out+=P(f'29,{yy+23} 163,{yy+23} 165,{yy+29} 31,{yy+29}','#f5d9a1')
   else:
    out+=R(31,yy+23,134,5,'#ce9560',1)
  if level!='empty':
   count=7 if level=='low' else 21
   cols=['#fa784d','#ffbe53','#7dc784','#ed7076','#9bccee','#f5d65e','#b5a6d8']
   for i in range(count):
    r,c=divmod(i,7);x=42+c*18.5;y=104+r*34
    if cat=='fruit':out+=fruit(x,y,cols[i%7],1.04)
    else:out+=boxproduct(x,y,cols[i%7],1,'snack')
  out+=R(18,31,164,31,primary,7,'#fff5d8',3)
  out+=P('182,31 201,43 201,59 182,62',dark,'#f5d9ac',2)
  out+=R(25,35,149,7,'#fff1dd',3).replace('fill="#fff1dd"','fill="#fff1dd" opacity=".35"')
  out+=R(24,184,150,7,'#ad7a53',3)
 out+=f'<g filter="url(#shadow)">{R(51,29,118,28,primary,7,"#fff0d5",2)}</g>'
 out+=T(110,48,title,15)
 if level=='empty':
  out+=R(65,114,94,25,'#fff5e4',8,'#efc9a6',2)+T(112,132,'CHƯA CÓ HÀNG',11,'#cc8f71')
 out+='</svg>'
 return out

# professional chibi characters in red staff uniform, slight variants with waving/restocking
AVATAR_HEAD='''<svg xmlns="http://www.w3.org/2000/svg" width="140" height="188" viewBox="0 0 140 188"><defs>
 <linearGradient id="skin" x1="0" x2=".9" y1="0" y2="1"><stop stop-color="#fff6d9"/><stop offset=".55" stop-color="#ffe0c5"/><stop offset="1" stop-color="#f5ae9e"/></linearGradient>
 <linearGradient id="hair" x1="0" x2=".8" y1="0" y2="1"><stop stop-color="{highlight}"/><stop offset="1" stop-color="{hair}"/></linearGradient>
 <linearGradient id="suit" x1="0" x2="1" y1="0" y2="1"><stop stop-color="{light}"/><stop offset="1" stop-color="{shirt}"/></linearGradient>
 <linearGradient id="shine" x1="0" x2=".6" y1="0" y2="1"><stop stop-color="#ffffff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
 <filter id="shadow" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="3" stdDeviation="2" flood-color="#3a5267" flood-opacity=".20"/></filter></defs>
'''
def actor(name,kind='staff',mood='happy',action='idle'):
 configs={'an':('#563b39','#b78963','#f2505a','#ff8c77','long'), 'binh':('#343848','#7d8497','#f25651','#ff9080','short'), 'linh':('#6a3b39','#b77b62','#f16e61','#ff9d85','ponytail'), 'minh':('#292f3c','#6e7c92','#e9505a','#ff8d7b','short'), 'customer_a':('#4a3540','#8e6778','#78bc91','#ade4b3','long'), 'customer_b':('#503931','#99775c','#65aadb','#9bd4e5','short'), 'customer_c':('#5c4350','#aa7e8e','#ecae63','#ffd794','ponytail')}
 hair,highlight,shirt,light,hairtype=configs.get(name,configs['an']);isstaff=kind=='staff'
 out=AVATAR_HEAD.format(hair=hair,highlight=highlight,shirt=shirt,light=light)
 # cast shadow legs
 out+='<ellipse cx="70" cy="177" rx="29" ry="7" fill="#405066" opacity=".19"/>'
 out+=R(53,137,14,31,'#344867',6,'#263954',3)+R(75,137,14,31,'#344867',6,'#263954',3)
 out+=R(46,163,24,12,'#f9ffff',5,'#516779',2)+R(73,163,23,12,'#f9ffff',5,'#516779',2)
 # body
 out+='<path d="M46 114 Q45 99 58 94 L81 94 Q97 97 98 114 L95 146 Q70 151 44 146Z" fill="url(#suit)" stroke="#8e555c" stroke-width="3"/>'
 out+='<path d="M63 95 L71 109 L79 95" fill="#fff7ec" stroke="#e1e4df" stroke-width="2"/>'
 if isstaff:
  out+=R(60,113,21,25,'#fff6ea',3,'#fff',1)+R(65,116,10,5,'#e8b75c',2)
  out+=R(85,114,10,12,'#fff8eb',2,'#d6e1e5',1)+T(90,123,'24',6,'#e44c54')
 else:out+=R(61,115,21,6,'#fcf5e4',2)
 # arms and gestures
 if action in ('carry','work'):
  out+='<path d="M45 112 Q24 112 28 130 L45 145" fill="none" stroke="#fad4b8" stroke-width="13" stroke-linecap="round"/>'
  out+='<path d="M95 111 Q115 119 110 136 L92 145" fill="none" stroke="#fad4b8" stroke-width="13" stroke-linecap="round"/>'
  out+=R(40,132,59,29,'#e5b477',4,'#9f754a',2)+P('41,133 70,121 99,133 69,145','#f7d29d','#a4794b',1)+R(64,135,11,17,'#f7edcb',1)
 elif action=='wave':
  out+='<path d="M46 113 Q37 130 35 141" fill="none" stroke="#fad4b8" stroke-width="13" stroke-linecap="round"/>'
  out+='<path d="M94 110 Q112 94 119 73" fill="none" stroke="#fad4b8" stroke-width="13" stroke-linecap="round"/>'
  out+='<ellipse cx="120" cy="69" rx="10" ry="12" fill="url(#skin)" stroke="#eda994" stroke-width="2"/>'
 elif action=='scan':
  out+='<path d="M46 114 Q35 128 43 143" fill="none" stroke="#fad4b8" stroke-width="12" stroke-linecap="round"/>'
  out+='<path d="M94 112 Q104 131 92 139" fill="none" stroke="#fad4b8" stroke-width="12" stroke-linecap="round"/>'
  out+=R(90,132,25,12,'#285e80',3,'#c6eafa',2)+R(91,129,15,5,'#eafafa',2)
 else:
  out+='<path d="M46 113 Q39 129 44 143" fill="none" stroke="#fad4b8" stroke-width="12" stroke-linecap="round"/>'
  out+='<path d="M95 113 Q104 129 96 143" fill="none" stroke="#fad4b8" stroke-width="12" stroke-linecap="round"/>'
 # hair / head silhouette larger than body
 out+='<ellipse cx="70" cy="66" rx="45" ry="48" fill="url(#hair)" stroke="#634c51" stroke-width="2"/>'
 if hairtype in ('long','ponytail'):
  out+='<path d="M31 64 Q23 93 32 117 Q36 122 43 116 L49 94Z" fill="url(#hair)"/>'
  out+='<path d="M107 65 Q119 95 108 115 Q101 122 94 115 L91 92Z" fill="url(#hair)"/>'
 if hairtype=='ponytail':
  out+='<path d="M101 44 Q127 41 126 77 Q130 96 118 99 Q105 83 111 68" fill="url(#hair)" stroke="#634c51" stroke-width="2"/>'
 # face cheeks, ears
 out+='<ellipse cx="70" cy="72" rx="37" ry="37" fill="url(#skin)" stroke="#ebb39c" stroke-width="1.5"/>'
 out+='<ellipse cx="34" cy="75" rx="6" ry="9" fill="url(#skin)"/><ellipse cx="106" cy="75" rx="6" ry="9" fill="url(#skin)"/>'
 out+='<ellipse cx="48" cy="89" rx="10" ry="6" fill="#ff9baf" opacity=".43"/><ellipse cx="92" cy="89" rx="10" ry="6" fill="#ff9baf" opacity=".43"/>'
 # front fringe highlights
 out+='<path d="M33 56 Q33 18 75 22 Q102 19 108 52 Q89 46 75 40 Q55 62 33 56" fill="url(#hair)"/>'
 out+='<path d="M44 43 Q65 28 89 33" fill="none" stroke="#f5d7b3" stroke-width="4" stroke-linecap="round" opacity=".28"/>'
 out+='<path d="M68 31 Q72 45 61 54" fill="none" stroke="'+hair+'" stroke-width="10" stroke-linecap="round"/>'
 # eyes big and polished
 eye_h=10 if mood=='sleepy' else 12
 for x in (55,85):
  if mood=='sleepy':out+=f'<path d="M{x-8} 76 Q{x} 70 {x+7} 76" fill="none" stroke="#443849" stroke-width="3" stroke-linecap="round"/>'
  else:
   out+=f'<ellipse cx="{x}" cy="74" rx="7.5" ry="{eye_h}" fill="#fffefa" stroke="#875969" stroke-width="1.2"/>'
   out+=f'<ellipse cx="{x+1}" cy="76" rx="5.4" ry="{eye_h-2}" fill="#3e3447"/>'
   out+=f'<ellipse cx="{x-1.3}" cy="71" rx="2.7" ry="3.9" fill="white"/><circle cx="{x+3}" cy="80" r="1.15" fill="white"/>'
 out+='<path d="M47 58 Q55 55 62 58 M78 58 Q85 55 92 58" fill="none" stroke="#573d45" stroke-width="2" stroke-linecap="round"/>'
 if mood=='sad':out+='<path d="M65 99 Q70 93 75 99" fill="none" stroke="#af5a6a" stroke-width="2.4" stroke-linecap="round"/>'
 else:out+='<path d="M63 95 Q70 106 77 95" fill="'+('#cd5867' if mood=='happy' else 'none')+'" stroke="#a75c68" stroke-width="2.2" stroke-linecap="round"/>'
 if isstaff:
  # branded red cap, like original reference
  out+='<path d="M31 39 Q28 16 69 12 Q105 15 111 39 Q71 28 31 39" fill="#e94d56" stroke="#fff4eb" stroke-width="3"/>'
  out+='<path d="M65 30 Q87 26 115 35 Q106 43 90 43 Q81 39 65 39" fill="#c23545" stroke="#fff4eb" stroke-width="2"/>'
  out+='<rect x="63" y="18" width="14" height="11" rx="2" fill="#fff8e6"/>'
  out+='<text x="70" y="26" font-family="Arial" font-size="7" font-weight="900" fill="#e44251" text-anchor="middle">24</text>'
 out+='</svg>'
 return out

def cashcounter():
 out=HEADER
 out+='<ellipse cx="112" cy="183" rx="95" ry="15" fill="#324d5c" opacity=".19" filter="url(#shade)"/>'
 out+=P('20,105 97,68 207,105 130,145','#f8f5e6','#7896a1',3)
 out+=P('20,105 130,145 130,192 20,149','#52a9b7','#386a8d',3)
 out+=P('130,145 207,105 207,150 130,192','#87cfd5','#3d8ba2',3)
 out+=P('20,105 97,68 207,105 130,145','#f5f5ef','#a5bfca',2)
 out+=R(99,62,65,39,'#355b87',6,'#e5f7ff',3)+R(105,67,53,28,'#80d6eb',3)
 out+=T(132,88,'₫',20,'#ffffff')
 out+=P('79,113 101,104 128,116 108,127','#354e64','#b4c7cf',2)
 out+=R(78,92,26,26,'#3c597d',3,'#a9d6df',2)+R(84,95,15,9,'#c4eefa',1)
 out+=R(54,105,25,10,'#f9ce68',4)+R(25,96,18,16,'#f8a681',4)
 out+=T(94,174,'THU NGÂN',15,'#ffffff')
 out+='</svg>'
 return out

for cat in ('drink','snack','milk','fruit','noodle','frozen'):
 for level in ('empty','low','full'):
  p=DIR/f'{cat}_{level}.svg';p.write_text(shelf(cat,level),encoding='utf-8')
  cairosvg.svg2png(bytestring=p.read_bytes(),write_to=str(p.with_suffix('.png')),output_width=330,output_height=308)

for name in ('an','binh','linh','minh','customer_a','customer_b','customer_c'):
 kind='customer' if name.startswith('customer') else 'staff'
 for action in ('idle','wave','work','scan'):
  for mood in ('happy','sad'):
   if action=='scan' and kind=='customer':continue
   p=DIR/f'{name}_{action}_{mood}.svg';p.write_text(actor(name,kind,mood,action),encoding='utf-8')
   cairosvg.svg2png(bytestring=p.read_bytes(),write_to=str(p.with_suffix('.png')),output_width=210,output_height=282)

p=DIR/'checkout.svg';p.write_text(cashcounter(),encoding='utf-8');cairosvg.svg2png(bytestring=p.read_bytes(),write_to=str(p.with_suffix('.png')),output_width=330,output_height=308)
print('Created',len(list(DIR.glob('*.png'))),'PNG sprites; total KB',round(sum(p.stat().st_size for p in DIR.glob('*.png'))/1024))
