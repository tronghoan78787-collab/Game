"""Capture real Chromium frames after dispatching gameplay actions (no generated mock gameplay)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
R=Path(__file__).resolve().parents[1]
h=(R.parent/'cua_hang_tien_loi_V60_CHOI_NGAY.html').read_text(encoding='utf8').replace('<head>','<head><script>window.__CHIBI_QA__=true;</script>',1)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for w,ht,label in [(932,430,'LANDSCAPE'),(390,844,'PORTRAIT')]:
  c=b.new_context(viewport={'width':w,'height':ht},device_scale_factor=2,is_mobile=True,has_touch=True)
  page=c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(h);page.evaluate('window.ConvenienceGame.ready')
  page.evaluate('''() => {for(let id of ['drink','snack','milk','fruit'])window.ConvenienceGame.dispatch({type:'ORDER',id,qty:24});window.ConvenienceGame.advanceForTest(130);}''')
  page.evaluate('''() => {let g=window.ConvenienceGame;g.dispatch({type:'OPEN'});g.advanceForTest(24);}''')
  page.wait_for_timeout(900)
  page.locator('.coach-close').click(force=True) if page.locator('.coach-close').is_visible() else None
  page.evaluate('''() => {let f=document.getElementById('floatText');f.hidden=true;let tip=document.getElementById('tips');tip.hidden=true;}''')
  page.wait_for_timeout(300)
  page.screenshot(path=str(R/f'V60_GAMEPLAY_{label}.png'))
  if label=='LANDSCAPE':
   page.locator('.mobile-nav-button[data-panel="order"]').tap();page.screenshot(path=str(R/'V60_ORDER_LANDSCAPE.png'));page.locator('.modal-heading .close').tap()
   page.locator('.mobile-nav-button[data-panel="staff"]').tap();page.screenshot(path=str(R/'V60_STAFF_LANDSCAPE.png'));page.locator('.modal-heading .close').tap()
   page.locator('.mobile-nav-button[data-panel="more"]').tap();page.locator('.mobile-more-tile[data-panel="settings"]').tap();page.screenshot(path=str(R/'V60_SETTINGS_LANDSCAPE.png'))
  print(label,'state',page.evaluate('''() => {let s=window.ConvenienceGame.getState();return {stock:s.stock,customers:s.customers.length,cash:s.cash,mode:window.ConvenienceGame.renderer()}}'''),'errors',errors)
  c.close()
 b.close()
# Manifest product screenshot is a real game screenshot, resized to the required metadata resolution.
im=Image.open(R/'V60_GAMEPLAY_LANDSCAPE.png').convert('RGB');im.resize((844,390),Image.Resampling.LANCZOS).save(R/'assets/preview.jpg',quality=88,optimize=True)
print('Updated assets/preview.jpg')
