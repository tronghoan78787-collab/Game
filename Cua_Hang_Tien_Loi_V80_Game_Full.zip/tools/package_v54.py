"""Reproducible V49–V54 ZIP builder with offline site and full source distributions."""
from pathlib import Path
import shutil,zipfile,json,re,subprocess,hashlib
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT.parent
MILESTONES={
  49:('Sổ tiền và đối soát','Sổ dòng tiền từ thời điểm nâng cấp, kiểm soát chênh lệch tiền.'),
  50:('Định mức nhập hàng','Quỹ dự phòng và đặt hàng theo forecast có xác nhận.'),
  51:('Quy trình NPC','Ưu tiên phục vụ khách/hàng hóa và thống kê nhân viên.'),
  52:('Bảng vận hành và dữ liệu','UI vận hành, kiểm tra kho, cảnh báo dữ liệu.'),
  53:('Tương thích và iOS','Giữ save V48, IndexedDB, cache ngoại tuyến và nguồn Capacitor.'),
  54:('Tích hợp QA','Bản game tích hợp iOS-first, tài liệu, kiểm thử toàn hệ thống.')
}
WEB_ITEMS=['index.html','404.html','manifest.webmanifest','sw.js','health.json','_headers','_redirects','.nojekyll','netlify.toml','robots.txt','src','assets']
RELEASE_ITEMS=WEB_ITEMS+['server.js','package.json','README.md','README_V54.md','DEPLOY_V54.md','GAME_SYSTEMS.md','QA_REPORT_V54.md','RELEASE_NOTES_V54.md','STAGES_V49_V54.md','tests','tools','ios-shell','.github']

def copy_items(to,names):
    to.mkdir(parents=True,exist_ok=True)
    for name in names:
        src=ROOT/name
        if not src.exists():continue
        out=to/name
        if src.is_dir(): shutil.copytree(src,out,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
        else:
            out.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,out)

def zip_tree(folder,target):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file() and not p.name.startswith('.__'):
                z.write(p,p.relative_to(folder).as_posix())
    with zipfile.ZipFile(target) as z:
        bad=z.testzip()
        if bad:raise RuntimeError(f'CRC invalid {target}: {bad}')
        names=z.namelist()
        for required in ['index.html','src/engine.js','src/operations.js','src/app.js']:
            if required not in names: raise RuntimeError(f'Missing {required}: {target}')
    print(target.name, target.stat().st_size)

build=DEST/'_build_v54_packages'
if build.exists():shutil.rmtree(build)
build.mkdir()

# Isolated sequential milestones. Old HTML/CSS UI is present as an early preview;
# operations behind feature flags reject use until the appropriate release stage.
for stage,(title,description) in MILESTONES.items():
    folder=build/f'V{stage}'
    copy_items(folder,WEB_ITEMS+['server.js','package.json','README_V54.md','GAME_SYSTEMS.md','STAGES_V49_V54.md','DEPLOY_V54.md'])
    index=folder/'index.html'
    data=index.read_text(encoding='utf-8').replace('STORE_OPERATIONS_STAGE=54;',f'STORE_OPERATIONS_STAGE={stage};')
    data=data.replace('Chibi Tycoon V54 iOS Operations',f'Chibi Tycoon V{stage} iOS Operations')
    index.write_text(data,encoding='utf-8')
    app=folder/'src/app.js'
    txt=app.read_text(encoding='utf-8').replace("const releaseVersion='54.0.0-ios';",f"const releaseVersion='{stage}.0.0-ios';")
    app.write_text(txt,encoding='utf-8')
    sw=folder/'sw.js'
    sw.write_text(sw.read_text().replace('ios-v54.0',f'ios-v{stage}.0'))
    health=folder/'health.json'
    j=json.loads(health.read_text());j['release']=f'{stage}.0.0-ios-rc';health.write_text(json.dumps(j,ensure_ascii=False,indent=2))
    pkg=folder/'package.json'
    j=json.loads(pkg.read_text());j['version']=f'{stage}.0.0';pkg.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
    (folder/'README_STAGE.md').write_text(f'''# Cửa Hàng Tiện Lợi — V{stage}\n\n**Giai đoạn:** {title}\n\n{description}\n\n**Giả định:** dùng chung engine V48, save `version:12`, có sẵn bộ giao diện vận hành nhưng tính năng ở stage sau chưa mở. Đây là snapshot để kiểm tra tiến độ phát triển, không phải bản App Store hoặc trang HTTPS đã được xuất bản.\n\n**Cách chạy:** mở `index.html` trong trình duyệt cho phép file hoặc chạy `npm start` với Node.js >=18. Bản V54 là bản tích hợp cuối có đầy đủ chức năng.\n\n**Cơ chế mở khóa tính năng:** `window.STORE_OPERATIONS_STAGE={stage}` trong HTML, kiểm tra bằng `src/operations.js`. Giai đoạn V49 chỉ mở sổ tiền; V50 thêm đặt hàng thông minh; V51 thêm quy trình phục vụ; V52 thêm phân tích dữ liệu; V53 và V54 là mốc iOS và tích hợp.\n''',encoding='utf-8')
    zip_tree(folder,DEST/f'cua_hang_tien_loi_iOS_V{stage}.zip')

web=build/'website';copy_items(web,WEB_ITEMS+['DEPLOY_V54.md','README_V54.md','GAME_SYSTEMS.md'])
zip_tree(web,DEST/'cua_hang_tien_loi_iOS_V54_website.zip')
source=build/'full_source';copy_items(source,RELEASE_ITEMS+['QA_V54_BROWSER.json','GAMEPLAY_V54.png','QA_V54_iphone_landscape.png','QA_V54_iphone_portrait.png','QA_V54_desktop.png'])
zip_tree(source,DEST/'cua_hang_tien_loi_iOS_V49_V54_full_source.zip')
# Stage evidence hash manifest for user verification.
packages=sorted([*DEST.glob('cua_hang_tien_loi_iOS_V5[0-4].zip'), DEST/'cua_hang_tien_loi_iOS_V49.zip',DEST/'cua_hang_tien_loi_iOS_V54_website.zip',DEST/'cua_hang_tien_loi_iOS_V49_V54_full_source.zip'])
manifest={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in packages}
(ROOT/'RELEASE_PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
shutil.rmtree(build)
print('All archives passed ZIP CRC + required-path checks')
