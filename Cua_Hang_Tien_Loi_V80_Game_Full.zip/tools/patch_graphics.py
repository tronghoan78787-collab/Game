from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'src'/'scene.js'
s=p.read_text()
s=s.replace("this.drag=null;this.touches=new Map();this.pinch=null;this.visuals=new Map();this.running=true;this.lastFrame=0;", "this.drag=null;this.touches=new Map();this.pinch=null;this.visuals=new Map();this.running=true;this.lastFrame=0;\n    this.sprites=Object.create(null);this.loadedSprites=0;this.loadIllustrations();")
start=s.index('  resize(){')
s=s[:start]+'''  // V56: offline sprite atlas. Real PNG graphics, no network calls or external CDN.
  loadIllustrations(){
    const cats=['drink','snack','milk','fruit','noodle','frozen'];
    const avatarNames=['an','binh','linh','minh','customer_a','customer_b','customer_c'];
    const keys=['checkout'];
    for(const cat of cats)for(const fill of ['empty','low','full'])keys.push(cat+'_'+fill);
    for(const name of avatarNames){
      const actions=name.startsWith('customer')?['idle','wave','work']:['idle','wave','work','scan'];
      for(const action of actions)for(const mood of ['happy','sad'])keys.push(name+'_'+action+'_'+mood);
    }
    for(const key of keys){
      const image=new Image();image.onload=()=>{this.loadedSprites++};
      image.onerror=()=>{image.failed=true};
      image.src='assets/art/'+key+'.png';this.sprites[key]=image;
    }
  }
  sprite(key,x,y,width,height){
    const img=this.sprites[key];if(!img||!img.complete||img.failed||!img.naturalWidth)return false;
    this.ctx.drawImage(img,x,y,width,height);return true;
  }
''' + s[start:]
start=s.index('  rack(x,y,cat,qty,max,now){')
s=s[:start]+'''  premiumRack(x,y,cat,qty,max,time){
    if(!this.sprites||this.getState()?.settings?.quality==='low')return false;
    const fullness=qty<=0?'empty':qty<max*.37?'low':'full';
    if(!this.sprite(cat.id+'_'+fullness,x-84,y-96,170,160))return false;
    const c=this.ctx;
    this.rounded(x-48,y+58,96,21,10,'#fffaf0','#d7d4a7',2);
    this.text(qty+' / '+max+' SP',x,y+68,12,qty<=0?'#cf7656':'#328e78',null);
    if(qty<=4){
      this.rounded(x+55,y-87,27,26,12,'#f77971','#ffffff',2);
      this.text('!',x+68,y-74,18,'#fff','#ad414b');
    }else if(qty>max*.6){
      this.ellipse(x+71,y-57,13,13,'#6dd496');this.text('✓',x+71,y-57,16,'#fff','#2f9a66');
    }
    return true;
  }
''' + s[start:]
s=s.replace('  rack(x,y,cat,qty,max,now){\n    const c=this.ctx,w=112,h=84;', '  rack(x,y,cat,qty,max,now){\n    if(this.premiumRack(x,y,cat,qty,max,now))return;\n    const c=this.ctx,w=112,h=84;')
s=s.replace('  checkout(s,time){\n    const x=302,y=383;', "  checkout(s,time){\n    const x=302,y=383;\n    if(s.settings?.quality!=='low'&&this.sprite('checkout',x-108,y-121,212,183))return;")
needle='  character(x,y,skin,shirt,hair,name,t,bubble,mood,role){\n'
s=s.replace(needle,'''  premiumCharacter(x,y,skin,shirt,hair,name,t,bubble,mood,role){
    if(!this.sprites||this.getState()?.settings?.quality==='low')return false;
    const isStaff=role!=='customer';
    const n=isStaff?(name==='An'?'an':name==='Bình'?'binh':name==='Linh'?'linh':name==='Minh'?'minh':'binh'):
      (['customer_a','customer_b','customer_c'][Math.abs(Math.floor(x*13+y*7))%3]);
    const action=isStaff?(role==='rest'?'idle':role==='cashier'?(Math.floor(t/850)%4===0?'wave':'scan'):(Math.floor(t/800)%3===0?'idle':'work')):
      (Math.floor(t/1100)%5===0?'wave':'idle');
    const expression=Number(mood||65)<38?'sad':'happy';
    const bob=(this.getState()?.settings?.reducedMotion?0:(role==='rest'?0:Math.sin(t*.009+x*.15)*1.3));
    const w=isStaff?67:58,h=isStaff?91:82;
    if(!this.sprite(n+'_'+action+'_'+expression,x-w/2,y-h+10+bob,w,h))return false;
    if(isStaff&&this.getState()?.settings?.showNames)this.text(name,x,y+17,11,'#ffffff','#38779d');
    if(bubble){
      let text=String(bubble);if(text.length>26)text=text.slice(0,23)+'…';
      const width=Math.min(155,Math.max(58,text.length*6.4+20));const by=y-h-21+bob;
      this.rounded(x-width/2,by,width,27,12,'#fffdf1','#86b5c9',2);
      this.poly([[x-5,by+24],[x+4,by+24],[x-2,by+31]],'#fffdf1');
      this.text(text,x,by+13,10,'#48728d',null);
    }
    return true;
  }
  character(x,y,skin,shirt,hair,name,t,bubble,mood,role){
    if(this.premiumCharacter(x,y,skin,shirt,hair,name,t,bubble,mood,role))return;
''')
# extra wall decorative fixtures
s=s.replace('    // shelf-like back wall cabinets\n', '''    // V57 illustrated lighting and retail posters, independent of stock state.
    this.rounded(215,238,77,50,5,'#fce8a8','#d9a369',3);
    this.emoji('☕',253,260,26);this.text('GIẢM GIÁ',253,279,10,'#d65d52','#fff8d3');
    this.rounded(902,233,41,36,5,'#ecf4ee','#82a49b',2);
    this.emoji('🌿',922,247,19);
    this.rounded(440,61,76,8,4,'#efdfbd','#b9aa8b',2);
    for(const lx of [452,474,496]){
      this.ellipse(lx,79,14,5,'#fffbd2a6');this.trace([[lx,68],[lx,75]],'#af9480',2);
    }
    // shelf-like back wall cabinets
''')
s=s.replace("this.drawAtmosphere(s,time);", "this.drawAtmosphere(s,time);\n    this.drawRetailEffects(s,time);")
anchor=s.index('  drawSigns(s,time){')
s=s[:anchor]+'''  drawRetailEffects(s,time){
    // Small sparkling promotions and store signs without obstructing touch targets.
    if(this.getState()?.settings?.reducedMotion)return;
    const c=this.ctx;c.save();
    const spots=[[372,193],[624,188],[764,283],[904,321]];
    for(let i=0;i<spots.length;i++){
      const [x,y]=spots[i];const a=.35+.25*Math.sin(time/630+i*2.6);
      c.globalAlpha=a;c.strokeStyle='#fff3c8';c.lineWidth=1.8;
      c.beginPath();c.moveTo(x-5,y);c.lineTo(x+5,y);c.moveTo(x,y-5);c.lineTo(x,y+5);c.stroke();
    }
    c.restore();
  }
''' + s[anchor:]
p.write_text(s)
# Engine: default premium art mode, optional original WebGL view in graphics settings
p=root/'src'/'engine.js';s=p.read_text()
s=s.replace("settings:{sound:false,quality:'auto',showNames:true,largeText:false,reducedMotion:false}","settings:{sound:false,quality:'auto',renderMode:'illustrated',showNames:true,largeText:false,reducedMotion:false}")
s=s.replace("['sound','showNames','quality','largeText','reducedMotion'].includes(action.key)","['sound','showNames','quality','renderMode','largeText','reducedMotion'].includes(action.key)")
s=s.replace("if(action.key==='quality'&&!['auto','high','low'].includes(action.value))return result(false,'Chất lượng không hợp lệ.');", "if(action.key==='quality'&&!['auto','high','low'].includes(action.value))return result(false,'Chất lượng không hợp lệ.');\n        if(action.key==='renderMode'&&!['illustrated','3d'].includes(action.value))return result(false,'Chế độ vẽ không hợp lệ.');")
s=s.replace("if(action.key!=='quality'&&typeof action.value!=='boolean')", "if(!['quality','renderMode'].includes(action.key)&&typeof action.value!=='boolean')")
p.write_text(s)
# App: default hand-illustrated rather than primitive WebGL; 3D as optional renderer.
p=root/'src'/'app.js';s=p.read_text()
s=s.replace("const releaseVersion='55.0.0-mobile-touch';", "const releaseVersion='60.0.0-chibi-art';")
s=s.replace("try{scene=new window.StoreScene3D($('scene'),state,onSceneHit);document.body.classList.add('render-3d');}\ncatch(err){console.warn('WebGL fallback to Canvas 2D:',err);scene=new window.StoreScene($('scene'),state,onSceneHit);document.body.classList.add('render-2d');}", "try{if(S.settings.renderMode==='3d'){scene=new window.StoreScene3D($('scene'),state,onSceneHit);document.body.classList.add('render-3d');}else{scene=new window.StoreScene($('scene'),state,onSceneHit);document.body.classList.add('render-2d','render-premium');}}\ncatch(err){console.warn('WebGL fallback to Canvas 2D:',err);scene=new window.StoreScene($('scene'),state,onSceneHit);document.body.classList.add('render-2d','render-premium');}")
s=s.replace('    <div class="row between"><strong>🎨 Chất lượng đồ họa</strong><select', '''    <div class="row between"><strong>🖼️ Phong cách hình ảnh</strong><select id="renderMode" class="input" style="width:auto"><option value="illustrated" ${S.settings.renderMode!=='3d'?'selected':''}>Chibi minh họa HD</option><option value="3d" ${S.settings.renderMode==='3d'?'selected':''}>3D thử nghiệm</option></select></div><div class="line"></div>
    <div class="row between"><strong>🎨 Chất lượng đồ họa</strong><select''')
s=s.replace("  if(e.target.id==='quality'){const out=act({type:'SETTING',key:'quality',value:e.target.value});if(out.ok)scene.resize();}", "  if(e.target.id==='quality'){const out=act({type:'SETTING',key:'quality',value:e.target.value});if(out.ok)scene.resize();}\n  if(e.target.id==='renderMode'){const out=act({type:'SETTING',key:'renderMode',value:e.target.value});if(out.ok){save();window.location.reload();}}")
s=s.replace('V55 Mobile Touch Beta','V60 Chibi Art Mobile')
s=s.replace('cua-hang-tien-loi-mobile-v55-backup.json','cua-hang-tien-loi-v60-backup.json')
p.write_text(s)
# Branding title and visual changes
p=root/'index.html';s=p.read_text().replace('V55 Mobile Touch','V60 Chibi Art');s=s.replace('meta name="theme-color" content="#437ed8"','meta name="theme-color" content="#267fd2"');p.write_text(s)
p=root/'package.json';s=p.read_text().replace('"version": "55.0.0"','"version": "60.0.0"').replace('Phone-first touch UI convenience store game','Chibi art HD offline-first mobile convenience store game');p.write_text(s)
print('Patched scene and app, sprite count',len(list((root/'assets'/'art').glob('*.png'))))
