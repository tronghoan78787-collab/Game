# QA V75 — KẾT QUẢ ĐÃ QUAN SÁT

**Môi trường:** Node.js 22, Chromium headless mở tệp HTML một trang bằng `page.set_content` và giả lập touch. Không có Safari iOS vật lý trong môi trường kiểm thử.

- **159/159 bài kiểm thử tự động JavaScript đạt**, 143 bài kế thừa từ V70 cộng 16 bài mới.
- **4/4 cấu hình màn hình touch emulation đạt**: 844×390, 390×844, 667×375, 375×667.
- Các thao tác chạm đã kiểm tra: **Thêm → Danh mục & giá → thay giá 14.000→14.500đ → chọn nước suối → xem Nhu cầu → xem Phát triển → đóng menu**. Không ghi nhận pageerror trong bốn lượt.
- Kiểm thử hóa đơn thực tế: ở dữ liệu cố định, 31 đơn đồ uống thu **434.000đ** tại giá 14.000đ và **496.000đ** tại giá 16.000đ; chi phí giá vốn không đổi.
- Kiểm thử gameplay cùng dự án: đặt **48 SP** cho bốn ngành, lên kệ, khai trương, chọn mặt hàng, chạy mô phỏng: **16 khách phục vụ, doanh thu ảo 272.000đ**, không ghi nhận lỗi JavaScript trong lượt kiểm thử.
- Kiểm tra dữ liệu: bản lưu V70 khôi phục sang V75, giá không hợp lệ bị khôi phục, nhiệm vụ không thể nhận lại lần thứ hai, không tạo tồn kho SKU ảo.

## Chưa được kiểm chứng

- Safari trên iPhone vật lý, WebGL 3D GPU, FPS ổn định, thử nghiệm sau 60 phút, chế độ offline trên HTTPS ngoài môi trường container.
- Chất lượng hoạt ảnh 3D rigged và mức độ chi tiết tương đương toàn bộ mẫu 2.

**Đánh giá:** V75 đủ điều kiện bàn giao **beta nguồn/HTML**, chưa phải sản phẩm iOS thương mại đã nghiệm thu.
