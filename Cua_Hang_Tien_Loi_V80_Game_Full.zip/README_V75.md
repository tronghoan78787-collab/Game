# CỬA HÀNG TIỆN LỢI — CHIBI TYCOON MOBILE V75

## Phạm vi

Đây là bản beta có thể chơi, nâng cấp từ mã nguồn V70. Chơi đơn, tiền hoàn toàn là tiền ảo. Ưu tiên màn hình điện thoại và cảm ứng; không phát triển công cụ truy cập hay hosting mới trong lượt V71–V75.

## Giả định kỹ thuật

- Người chơi bắt đầu với 10.000.000đ, kệ **Đồ uống, Bánh kẹo, Sữa, Trái cây** và hai nhân viên **An (Thu ngân)**, **Bình (Vận hành)**.
- Dữ liệu tồn kho theo **ngành hàng** giống V70. Chọn mặt hàng chủ lực từ 18 hình minh họa chỉ quyết định trưng bày, hỗ trợ mô phỏng nhu cầu, **không có tồn kho SKU độc lập**.
- Người chơi tùy chỉnh giá bán theo từng ngành trong khoảng **80–130%** giá cơ bản, theo bước **500đ**. Giá nhập không đổi. Giá mới thực sự được áp dụng vào hóa đơn NPC.
- Nhu cầu mô phỏng theo chu kỳ **4 ngày**, kết hợp điều chỉnh giá và mặt hàng nổi bật; không lấy dữ liệu thời tiết hay giá thị trường ngoài đời.
- Thử thách tăng trưởng thưởng tiền ảo và XP một lần; dữ liệu lưu cũ (V70/V12) tự bổ sung trường mới bằng `normalizeSave`.
- Đồ họa mặc định là **chibi isometric 2.5D Canvas**. WebGL 3D vẫn là phần thử nghiệm và chưa được nghiệm thu trên iPhone thực.

## Chơi và điều khiển

- Khi khởi đầu, chạm **Cửa hàng → Nhập gói 4 kệ** để đặt 48 sản phẩm; Bình tự nhận và lên kệ. Khi các kệ có hàng, chạm **Khai trương**.
- Vào **Thêm → Danh mục & giá** để tăng/giảm giá bán 500đ mỗi lần và chọn một trong ba mặt hàng nổi bật của từng ngành.
- Vào **Thêm → Nhu cầu khách** để xem chu kỳ ngày, mức ưa thích, hàng thiếu dự kiến và số sản phẩm đã bán theo ngành.
- Vào **Thêm → Phát triển** để nhận thưởng thử thách một lần khi đạt yêu cầu.
- Vào **Nhân viên** để phân chức vụ. An tự thanh toán và tư vấn khuyến mãi; Bình tự nhận hàng, xếp kệ, vệ sinh và giúp khách.
- Chạm lên kệ để xem tồn kho; vuốt trong menu để cuộn, kéo nền cửa hàng để di chuyển, chụm hai ngón để phóng to/thu nhỏ (trình duyệt hỗ trợ).
- Bản lưu vẫn dùng khóa V12 để tương thích. Chức năng xuất/nhập bản lưu JSON vẫn được giữ từ V70.

## Cấu trúc mã nguồn

- `src/engine.js`: kinh tế nền tảng, giao hàng, kho, nhân viên, khách hàng, hóa đơn.
- `src/expansion.js`, `director.js`, `operations.js`: mở rộng, trợ lý vận hành và tài chính.
- `src/commerce.js`: **V71–V75**, giá bán, SKU trưng bày, sức mua, thử thách và thu thập thống kê.
- `src/app.js`, `style.css`: giao diện cảm ứng, menu thương mại, HUD, báo cáo.
- `src/scene.js`: Canvas isometric và biểu tượng mặt hàng chủ lực trực tiếp trên kệ khi có hàng.
- `assets/merch`: **18 cặp SVG + PNG** sản phẩm và **4 bảng sự kiện SVG + PNG**.
- `tests/commerce_v75.test.js`: các bài kiểm thử mới; những bài kiểm thử cũ được giữ nguyên.
- `lite.html`: bản HTML một tệp tự chứa mã game, ảnh cơ bản và ảnh sản phẩm.

## Kiểm thử và giới hạn

Chạy `node --test tests/*.test.js`. Bản này đã đạt 159/159 bài kiểm thử JavaScript. Kiểm thử UI bằng Chromium touch emulation tại 844×390, 390×844, 667×375 và 375×667; thử thay giá, chọn mặt hàng, xem dự báo, nhiệm vụ. Đã chạy luồng chơi thực tế với 16 khách thanh toán và doanh thu ảo 272.000đ.

**Không** coi kết quả Chromium là nghiệm thu Safari iPhone. Chưa có tài nguyên nhân vật 3D rigged chất lượng thương mại; chưa có IPA/TestFlight/App Store. Không thiết kế đường dẫn hay đăng nhập hosting trong lộ trình này theo yêu cầu.
