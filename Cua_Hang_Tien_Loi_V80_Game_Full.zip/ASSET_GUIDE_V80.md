# Bộ tài nguyên V80

- `assets/art/{personal,home,coffee,ready}_{empty,low,full}.png`: mỗi khu 3 trạng thái tồn kho.
- `assets/art/{thao,phuc,ha,tu}_{idle,wave,work,scan}_{happy,sad}.png`: 32 biến thể tư thế/cảm xúc NPC.
- `assets/avatars/{thao,phuc,ha,tu}.svg`: bốn ảnh đại diện nhân viên mới.
- `assets/merch/{shampoo,soap,toothpaste,tissue,detergent,cleaner,latte,blackcoffee,cappuccino,sandwich,riceball,salad}.{svg,png}`: 12 SKU đồ họa mới.
- `assets/art/product_{personal,home,coffee,ready}.png`: hình biểu tượng ngành.
- `assets/growth/tier{1..4}.{svg,png}`: bốn bản đồ thẻ quy hoạch.

Chế độ Canvas tải sprite theo nhu cầu để tránh chiếm bộ nhớ ảnh không cần thiết. Các file ảnh có thể thay mà không thay ID ngành trong engine.
