# Đặc tả cân bằng tăng trưởng V76–V80

## Giả định
Phát triển game chơi đơn offline, không có doanh thu hoặc tuyển dụng bằng tiền thật. Người chơi mở diện tích theo **khoảng cách tăng trưởng kinh tế** thay vì chạm để mở miễn phí.

## Gameplay loop
1. Kinh doanh tại 4 khu, tích lũy vốn và kinh nghiệm.
2. Đạt cấp độ và phí xây dựng; đóng cửa khi nâng cấp.
3. Mỗi cấp mới mở thêm 2 khu. Nhà cung cấp giao hàng, nhân viên nhận hàng, lên kệ.
4. Tuyển thêm 2 nhân sự sau từng bước nâng cấp; phân vai theo nhu cầu khách.
5. Tối ưu doanh thu, tồn kho, nhân sự và khoản vốn đầu tư trong chu kỳ kinh doanh tiếp theo.

## AI NPC và chi phí
- Nhân viên mới chỉ thực hiện vai trò đã giao; vẫn chịu ảnh hưởng thể lực, kỹ năng và lịch ca.
- Không tự sinh thêm người miễn phí khi tải bản lưu.
- Thẻ tiền mặt trừ đúng **một lần** trên giao dịch xây/tuyển; mở rộng ghi sổ tiền nếu bản lưu có sổ.
- Chặn trùng lặp nâng cấp/tuyển khi không đủ tiền, thiếu cấp hoặc đã đạt trần.
- Kệ và các ngành bị khóa không cho nhận đơn trước cấp mở khóa.

## Dữ liệu bền vững
- `storeLevel`, `staff`, `stock`, `warehouse`, `layout.shelves`, `growth.records` có quy tắc chuẩn hóa.
- Bản lưu 2/4 nhân viên cũ vẫn được mở; bản 8 nhân viên giữ nguyên khi khôi phục.
- Tiến trình cấp cửa hàng không giảm khi mở bản game tương thích.
- Danh mục đồ họa có nguồn SVG và PNG để thay bộ chibi mà không đổi logic.
