# Báo cáo kiểm thử — Cửa Hàng Tiện Lợi Mobile V80

## Phạm vi
- Lõi kinh tế, tuyển dụng, điều kiện mở rộng và lưu dữ liệu V75 → V80.
- Canvas isometric hiển thị cánh sàn 144/192 m² và kệ mới khi được mở khóa.
- Vốn khởi đầu 10.000.000đ, 2 nhân viên, 4 ngành; mở rộng tối đa 10 ngành và 8 nhân viên.
- Giao diện cảm ứng thực hiện `.tap()` trong Playwright Chromium ở 844×390, 390×844, 667×375.

## Kết quả
- **183/183** bài kiểm thử Node JavaScript **đạt**.
- **3/3** luồng thao tác cảm ứng Chromium **đạt**: mở màn Mở rộng, xây ba lần, tuyển sáu người, mở Nhập hàng; không ghi nhận lỗi JavaScript.
- **Tương thích dữ liệu lưu:** kiểm thử khởi tạo và đọc lại roster 8 người, giữ các khu đã mở.
- **Tài nguyên:** 12 sprite trạng thái kệ mới, 32 sprite nhân viên, 4 chân dung, 12 sản phẩm và 4 thẻ khu vực có SVG/PNG.
- **Bản đồ:** chụp ảnh cả tier 1 và tier 4 từ Chromium.

## Giới hạn và chưa nghiệm thu
- Chưa kiểm thử trên **Safari của iPhone vật lý**, chưa đo FPS/GPU thật.
- Chưa có hoạt ảnh xương 3D chuyên nghiệp; WebGL là mô hình low-poly/thủ tục.
- Các bức ảnh mở rộng cấp cao là **kịch bản QA với vốn/cấp thử nghiệm**, không đại diện trạng thái khởi đầu.
- Chưa làm triển khai website hoặc thay đổi phương thức truy cập theo yêu cầu người dùng.
