# CỬA HÀNG TIỆN LỢI — V70 MOBILE RELEASE CANDIDATE

## Giả định và mục tiêu
- Chơi đơn, kinh tế tiền ảo, khởi đầu 10.000.000đ, 4 ngành hàng, 2 nhân viên An và Bình.
- Ưu tiên chạy trên iPhone bằng Safari HTTPS, hỗ trợ dọc/ngang. Không giả định có máy Mac hay tài khoản nhà phát triển Apple.
- Bản mặc định **Lite** dùng Canvas chibi 2.5D, không nạp 1,5 MB dữ liệu mô hình WebGL; website có `advanced.html` để trải nghiệm bộ dựng khác.
- Tiến độ được giữ theo khóa lưu V12; IndexedDB chỉ là dự phòng cùng nguồn gốc (origin). Chuyển miền cần nhập bản sao lưu JSON.

## Mốc V66–V70
V66: Gói nhập ban đầu 4 kệ 1 chạm, tăng kích thước nút, tối ưu bảng cảm ứng.
V67: Tạo Lite HTML tự chứa (mã và 80 sprite WebP thu gọn), không cần tải asset từ internet.
V68: Ghi rõ cảnh báo mở tệp cục bộ, giữ sao lưu localStorage / IndexedDB và hướng dẫn chuyển miền bằng JSON.
V69: Website với `index.html` Lite, `advanced.html` đầy đủ, cache PWA theo phiên bản.
V70: Kiểm thử logic, giả lập cảm ứng và kiểm tra file ZIP. Mốc phát hành *candidate*, không phải đã được Apple hay Safari vật lý chứng nhận.

## Cách chơi
1. Mở đường dẫn HTTPS tới `index.html`.
2. Chạm **Cửa hàng → NHẬP GÓI 4 KỆ** để đặt 48 sản phẩm với giá 516.000đ; hoặc nhập từng ngành.
3. Đợi Bình nhận và bổ sung kệ (khoảng 9 giây game); chạm **Khai trương**.
4. An tự tính tiền, khách tự tìm hàng. Dùng **Nhân viên / Nhiệm vụ / Thêm** để quản lý.
5. Dữ liệu lưu cục bộ trên cùng website; xuất sao lưu JSON trong Cài đặt để chuyển miền hoặc thiết bị.

## Phát hành
- Cách thử nhanh trên hosting hỗ trợ ZIP: tải `Cua_Hang_Tien_Loi_V70_Lite_1File.zip` (chỉ index.html).
- Trên Netlify Drop nên **giải nén** `Cua_Hang_Tien_Loi_V70_Website.zip` rồi tải **thư mục** lên từ máy hỗ trợ chọn thư mục.
- Vercel hoặc hosting khác: tải thư mục `Cua_Hang_Tien_Loi_V70_Deploy_Web/` làm static site với index.html.
- Không tải HTML trong ChatGPT/Files lên rồi kỳ vọng Safari chạy JS; đó có thể chỉ là trình xem trước.

## Kiểm thử & giới hạn
- Node tests: `node --test tests/*.test.js` trong thư mục source.
- Playwright: dùng cấu hình điện thoại và thao tác touch, không thay cho Safari iPhone thật.
- Không có tên miền HTTPS công khai, chứng thực App Store/IPA, hoặc kiểm thử 60 phút trên phần cứng iOS thật.
- 3D WebGL low-poly vẫn là nhánh thử nghiệm, không phải bộ rigged/animation chuyên nghiệp từ ảnh mẫu số 2.
