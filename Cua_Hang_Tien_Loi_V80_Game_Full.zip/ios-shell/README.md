# iOS Capacitor shell — source scaffold

**Giả định:** Web/PWA là nền sản phẩm đã được kiểm thử. Native shell là tùy chọn phân phối qua App Store, *chưa được biên dịch hoặc ký số*.

1. Trên **máy Mac có Xcode**, cài Node.js, CocoaPods và đăng nhập Apple Developer (để ký/phát hành).
2. Trong thư mục game chính, chạy `python3 tools/copy_to_capacitor.py` để cập nhật `ios-shell/www` từ bản web.
3. Chuyển tới `ios-shell`, chạy `npm install`, `npx cap add ios`, `npx cap sync ios`, `npx cap open ios`.
4. Trong Xcode, cấu hình Bundle Identifier, Team, Signing, iOS minimum deployment version, orientation landscape. Kiểm thử trên iPhone thật, sau đó tạo archive để gửi TestFlight.

App chạy bằng WKWebView, sử dụng chính mã nguồn của game. Phụ thuộc npm chưa được tải trong gói này; thư mục dự án Xcode (`ios/`) chỉ được tạo sau lệnh `cap add ios` trên máy Mac. Không có IPA đã ký hoặc ứng dụng đã duyệt trên App Store.

## V54
Chạy `python3 tools/copy_to_capacitor.py` tại thư mục dự án trước khi `npm install && npm run ios:add && npm run ios:sync`. Khung Capacitor không chứa IPA đã ký; yêu cầu macOS/Xcode và tài khoản phát triển phù hợp để triển khai trên iPhone thật.
