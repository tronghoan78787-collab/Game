/*
 * CHIBI TYCOON V38–V42 — Director AI & management systems.
 * Giả định: AI hành vi giải thích được, chạy hoàn toàn offline, không LLM/API.
 * Tất cả tiền đều là tiền ảo. Giữ khóa lưu cũ và E.VERSION=12 để tương thích.
 */
(function(root,factory){
  const E=root.StoreEngine||(typeof module!=='undefined'?require('./engine.js'):null);
  if(!E)throw Error('StoreEngine must load before director.js');
  const api=factory(E,root);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(E,root){
  'use strict';
  const STAGE=Math.max(38,Math.min(42,Number(root.STORE_RELEASE_STAGE)||42));
  const CONTRACTS=[
    {id:'smiles',icon:'😊',title:'Nụ cười khách hàng',desc:'Phục vụ 4 khách và giữ độ sạch từ 65%',reward:90000,xp:20,
      ready:s=>s.today.served>=4&&s.cleanliness>=65,score:s=>Math.min(1,s.today.served/4)},
    {id:'shelves',icon:'📦',title:'Kệ hàng luôn đầy',desc:'Tồn kệ tổng cộng ít nhất 32 sản phẩm',reward:80000,xp:18,
      ready:s=>E.stockTotal(s,'stock')>=32,score:s=>Math.min(1,E.stockTotal(s,'stock')/32)},
    {id:'turnover',icon:'💰',title:'Kinh doanh khởi sắc',desc:'Doanh thu ngày đạt 140.000đ',reward:110000,xp:22,
      ready:s=>s.today.revenue>=140000,score:s=>Math.min(1,s.today.revenue/140000)},
    {id:'service',icon:'🤝',title:'Dịch vụ tận tâm',desc:'Phục vụ 5 khách và uy tín từ 76%',reward:105000,xp:22,
      ready:s=>s.today.served>=5&&s.reputation>=76,score:s=>Math.min(1,s.today.served/5)},
    {id:'profit',icon:'📈',title:'Lãi gộp vững vàng',desc:'Lãi gộp ngày đạt 55.000đ',reward:95000,xp:21,
      ready:s=>s.today.revenue-s.today.cogs>=55000,score:s=>Math.min(1,(s.today.revenue-s.today.cogs)/55000)}
  ];
  const safeInt=(n,max=99999999)=>Math.max(0,Math.min(max,Math.floor(Number(n)||0)));
  function hydrate(s){
    if(!s||typeof s!=='object')return s;
    const d=s.director&&typeof s.director==='object'?s.director:{};
    d.salesByCat=d.salesByCat&&typeof d.salesByCat==='object'?d.salesByCat:{};
    for(const c of E.CATEGORIES)d.salesByCat[c.id]=safeInt(d.salesByCat[c.id]);
    d.seenServed=safeInt(d.seenServed??s.stats.served);
    d.dialogue=Array.isArray(d.dialogue)?d.dialogue.slice(0,16).filter(x=>x&&typeof x.text==='string'):[];
    d.claimed=Array.isArray(d.claimed)?d.claimed.slice(-120).filter(x=>typeof x==='string'):[];
    d.lastHuddleDay=safeInt(d.lastHuddleDay,100000);
    d.lastCareDay=safeInt(d.lastCareDay,100000);
    d.satisfied=safeInt(d.satisfied);
    d.unhappy=safeInt(d.unhappy);
    d.lastMessageTick=safeInt(d.lastMessageTick,999999999);
    s.director=d;return s;
  }
  function note(s,speaker,text,tone='info'){
    const d=hydrate(s).director;
    d.dialogue.unshift({speaker:String(speaker).slice(0,28),text:String(text).slice(0,180),tone,day:s.day,minute:s.minutes});
    if(d.dialogue.length>16)d.dialogue.length=16;
  }
  function contractList(s){return CONTRACTS.filter((_,i)=>((i+s.day)%5)!==4).slice(0,3).map(c=>({
    ...c,claimed:hydrate(s).director.claimed.includes(s.day+':'+c.id),progress:c.score(s)
  }));}
  function salesForecast(s){
    hydrate(s);
    const days=Math.max(1,Math.min(7,s.day));
    return E.activeCats(s).map(cat=>{
      const sales=s.director.salesByCat[cat.id]||0;
      const velocity=Math.max(3,Math.ceil(sales/days));
      // Hàng tươi giới hạn mục tiêu vì tồn kho có hạn sử dụng.
      const target=['fruit','milk'].includes(cat.id)?Math.min(24,Math.max(12,velocity*2)):Math.min(52,Math.max(16,velocity*3));
      const pending=s.pending.reduce((a,p)=>a+(p.cat===cat.id?Math.max(0,p.qty-p.received):0),0);
      const available=(s.stock[cat.id]||0)+(s.warehouse[cat.id]||0)+pending;
      const missing=Math.max(0,target-available);
      let pack=missing>=45?48:missing>=22?24:missing>=9?12:0;
      if(['fruit','milk'].includes(cat.id))pack=Math.min(pack,24);
      const fill=E.availableRoom(s),minReserve=Math.min(2000000,Math.max(500000,Math.round(s.cash*.15)));
      if(pack>fill||s.cash-cat.cost*pack<minReserve)pack=0;
      return {id:cat.id,name:cat.name,icon:cat.icon,velocity,target,available,missing,pack,cost:pack*cat.cost,
        reason:missing>0?'Dự báo thiếu hàng':'Đủ hàng dự kiến'};
    });
  }
  function forecastMessage(s){
    const suggestion=salesForecast(s).filter(r=>r.missing>0).sort((a,b)=>b.missing-a.missing);
    if(!suggestion.length)return '✅ Tồn kho đáp ứng nhu cầu ngắn hạn.';
    const top=suggestion[0];return `📦 ${top.name}: còn ${top.available}, mục tiêu ${top.target}. ${top.pack?'Nên đặt '+top.pack+' sản phẩm.':'Kiểm tra vốn và sức chứa kho.'}`;
  }
  function healthScore(s){
    const queue=s.customers.filter(c=>c.stage==='queue').length;
    const stock=E.activeCats(s).reduce((a,c)=>a+Math.min(1,(s.stock[c.id]||0)/12),0)/E.activeCats(s).length;
    const staff=s.staff.filter(m=>m.role!=='rest').reduce((a,m)=>a+m.mood/100,0)/Math.max(1,s.staff.filter(m=>m.role!=='rest').length);
    return Math.round(E.clamp(s.cleanliness*.25+s.reputation*.29+stock*24+staff*22-queue*3,0,100));
  }
  function recommendations(s){
    const queue=s.customers.filter(c=>c.stage==='queue').length;
    const needs=s.customers.filter(c=>c.stage==='needHelp').length;
    const problems=[];
    if(needs)problems.push({priority:100,icon:'🙋',text:needs+' khách đang cần hỗ trợ — ưu tiên nhân viên vận hành.'});
    if(queue>=3)problems.push({priority:95,icon:'🧾',text:queue+' khách đang xếp hàng — cần đủ thu ngân.'});
    if(s.cleanliness<70)problems.push({priority:85,icon:'🧹',text:'Độ sạch xuống '+Math.round(s.cleanliness)+'% — ưu tiên vệ sinh.'});
    for(const r of salesForecast(s))if(r.missing>=10)problems.push({priority:60+r.missing/10,icon:r.icon,text:r.name+' cần nhập hàng: còn '+r.available+' / mục tiêu '+r.target+'.'});
    if(s.staff.some(m=>m.energy<20))problems.push({priority:75,icon:'☕',text:'Nhân viên thiếu thể lực — hãy sắp xếp nghỉ giải lao.'});
    if(s.customerCare.complaints>0)problems.push({priority:50,icon:'💬',text:s.customerCare.complaints+' phản ánh cần được chăm sóc.'});
    if(problems.length===0)problems.push({priority:10,icon:'🌟',text:'Cửa hàng ổn định. Tiếp tục theo dõi khách và hàng hóa.'});
    return problems.sort((a,b)=>b.priority-a.priority).slice(0,6);
  }
  const originalCreate=E.createGame, originalNormalize=E.normalizeSave, originalDispatch=E.dispatch, originalAdvance=E.advance;
  E.createGame=function(){return hydrate(originalCreate());};
  E.normalizeSave=function(raw){return hydrate(originalNormalize(raw));};
  E.dispatch=function(s,a){
    hydrate(s);
    if(a?.type==='AUTO_ORDER'){
      if(STAGE<39)return {ok:false,message:'Chưa mở quản lý nhập hàng thông minh.'};
      const options=salesForecast(s).filter(x=>x.pack>0).sort((a,b)=>b.missing-a.missing);
      if(!options.length)return {ok:false,message:'Không có đơn cần đặt hoặc cần giữ quỹ dự phòng.'};
      let count=0,cost=0;
      for(const p of options){
        const r=originalDispatch(s,{type:'ORDER',id:p.id,qty:p.pack});
        if(r.ok){count++;cost+=p.cost;}
      }
      return count?{ok:true,message:`Đã đặt ${count} ngành hàng, hết ${E.money(cost)}. Duy trì quỹ dự phòng.`}:
        {ok:false,message:'Không thể đặt thêm với vốn và sức chứa hiện tại.'};
    }
    if(a?.type==='TEAM_HUDDLE'){
      if(STAGE<38)return {ok:false,message:'Tính năng chưa mở.'};
      if(s.director.lastHuddleDay===s.day)return {ok:false,message:'Đã họp đầu ca hôm nay.'};
      s.director.lastHuddleDay=s.day;
      for(const m of s.staff){m.mood=E.clamp(m.mood+6,0,100);m.energy=E.clamp(m.energy-2,0,100);m.bubble='💪 Cố gắng nhé!';}
      note(s,'Cửa hàng trưởng','Cảm ơn cả đội! Ưu tiên khách hàng, luôn giữ kệ gọn và sạch.','success');
      return {ok:true,message:'Đã họp đầu ca: tâm trạng nhân viên +6.'};
    }
    if(a?.type==='CUSTOMER_CARE'){
      if(STAGE<38)return {ok:false,message:'Tính năng chưa mở.'};
      if(s.director.lastCareDay===s.day)return {ok:false,message:'Hôm nay đã xử lý phản ánh.'};
      if(s.customerCare.complaints<1)return {ok:false,message:'Chưa có phản ánh cần giải quyết.'};
      if(s.cash<30000)return {ok:false,message:'Cần 30.000đ để hỗ trợ khách.'};
      s.cash-=30000;s.stats.operatingCosts+=30000;s.customerCare.complaints--;
      s.reputation=E.clamp(s.reputation+1.3,0,100);s.director.lastCareDay=s.day;
      note(s,'Chăm sóc khách','Đã xin lỗi và hỗ trợ một khách, dịch vụ được cải thiện.','success');
      return {ok:true,message:'Đã hỗ trợ khách 30.000đ, uy tín +1,3%.'};
    }
    if(a?.type==='CLAIM_CONTRACT'){
      if(STAGE<41)return {ok:false,message:'Hợp đồng sẽ mở ở V41.'};
      const c=contractList(s).find(c=>c.id===a.id);
      if(!c)return {ok:false,message:'Nhiệm vụ không còn trong ngày.'};
      if(c.claimed)return {ok:false,message:'Đã nhận thưởng nhiệm vụ này hôm nay.'};
      if(!c.ready(s))return {ok:false,message:'Chưa hoàn thành yêu cầu.'};
      s.director.claimed.push(s.day+':'+c.id);s.director.claimed=s.director.claimed.slice(-120);
      s.cash+=c.reward;s.xp+=c.xp;
      // Đồng bộ quy tắc lên cấp với game chính.
      while(s.xp>=s.level*140){s.xp-=s.level*140;s.level++;s.reputation=E.clamp(s.reputation+2,0,100);}
      note(s,'Hợp đồng khu phố','Hoàn thành '+c.title+', nhận '+E.money(c.reward),'success');
      return {ok:true,message:'Hợp đồng hoàn thành! +'+E.money(c.reward)+' và '+c.xp+' XP.'};
    }
    return originalDispatch(s,a);
  };
  E.advance=function(s,rng=Math.random){
    hydrate(s);
    const previous=s.stats.served;
    originalAdvance(s,rng);
    if(STAGE>=38){
      const sold=Math.max(0,s.stats.served-previous);
      if(sold){
        const receipts=s.receipts.slice(0,sold);
        for(const r of receipts)for(const id of r.items||[])if(s.director.salesByCat[id]!==undefined)s.director.salesByCat[id]++;
        s.director.satisfied+=receipts.filter(r=>r.stars>=4).length;
        note(s,'An • Thu ngân',s.promo.cat?'Dạ chương trình giảm '+s.promo.rate+'% đang áp dụng cho '+(E.CATEGORIES.find(c=>c.id===s.promo.cat)?.name||'sản phẩm')+' ạ!':'Cảm ơn quý khách, hẹn gặp lại ạ!','success');
      }
      if(s.elapsed-s.director.lastMessageTick>=13 && s.opened){
        const waiting=s.customers.filter(x=>x.stage==='queue').length;
        const need=s.customers.find(x=>x.stage==='needHelp');
        if(need){note(s,'Khách hàng',`Mình đang tìm ${E.CATEGORIES.find(c=>c.id===need.cat)?.name||'món hàng'}, nhờ giúp!`,'warn');}
        else if(waiting>=3){note(s,'An • Thu ngân','Đang có '+waiting+' khách chờ, em ưu tiên tính tiền trước.','warn');}
        else if(s.cleanliness<65){note(s,'Bình • Vận hành','Em sẽ ưu tiên dọn vệ sinh sau khi hỗ trợ khách.','info');}
        if(need||waiting>=3||s.cleanliness<65)s.director.lastMessageTick=s.elapsed;
      }
      // Diễn đạt nhu cầu của khách trên bản đồ, không cho NPC phát ngôn trái trạng thái.
      for(const c of s.customers){
        if(c.stage==='browse'&&c.mood>75&&s.elapsed%17===0)c.thought='🛍️ Tìm '+(E.CATEGORIES.find(x=>x.id===c.cat)?.name||'sản phẩm');
      }
    }
    return s;
  };
  E.STORE_DIRECTOR_VERSION=STAGE;
  E.CONTRACTS=CONTRACTS;
  E.contractList=contractList;
  E.salesForecast=salesForecast;
  E.forecastMessage=forecastMessage;
  E.recommendations=recommendations;
  E.healthScore=healthScore;
  E.directorNote=note;
  return {STAGE,CONTRACTS,hydrate,contractList,salesForecast,recommendations,healthScore};
});
