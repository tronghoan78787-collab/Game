/* V44 - redundant IndexedDB save copies for iOS web/PWA; old localStorage key remains unchanged. */
(function(root,factory){
  const vault=factory(root);root.StoreVault=vault;
  if(typeof module==='object'&&module.exports)module.exports=vault;
})(typeof window==='object'?window:globalThis,function(root){
 'use strict';
 const DB_NAME='chibi-store-ios-v44',DB_VER=1,STORE='snapshots',MAX_BYTES=2000000;
 let dbPromise,queued='',timer=null,lastStatus='pending';
 function checksum(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(16).padStart(8,'0');}
 function validJSON(text,hash){if(typeof text!=='string'||text.length>MAX_BYTES)return null;
  if(hash&&checksum(text)!==hash)return null;
  try{const s=JSON.parse(text);return s&&s.version===12&&Array.isArray(s.staff)&&s.stock&&s.warehouse&&s.stats?s:null;}catch(e){return null;}}
 function open(){if(dbPromise)return dbPromise;
  dbPromise=new Promise((resolve,reject)=>{
   if(!root.indexedDB){reject(new Error('IndexedDB not supported'));return;}
   let request;
   try{request=root.indexedDB.open(DB_NAME,DB_VER);}catch(e){reject(e);return;}
   request.onupgradeneeded=()=>{const db=request.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'id'});};
   request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>{db.close();dbPromise=null;};lastStatus='ready';resolve(db);};
   request.onerror=()=>{lastStatus='unavailable';reject(request.error||Error('Cannot open game database'));};
   request.onblocked=()=>{lastStatus='unavailable';reject(Error('Database upgrade blocked'));};
  });return dbPromise;
 }
 function records(){return open().then(db=>new Promise((resolve,reject)=>{
   const req=db.transaction(STORE,'readonly').objectStore(STORE).getAll();
   req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);
 }));}
 async function latest(){try{const found=await records();found.sort((a,b)=>(b.savedAt||0)-(a.savedAt||0));
  for(const r of found){const s=validJSON(r.json,r.checksum);if(s)return s;}
  return null;
 }catch(e){lastStatus='unavailable';return null;}}
 async function write(text){const s=validJSON(text);if(!s)return false;
  try{
   const db=await open();const old=await records();const id=String(Date.now())+'-'+String(Math.floor(Math.random()*1e6));
   const entry={id,savedAt:Date.now(),json:text,checksum:checksum(text)};
   await new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE,'readwrite'),obj=tx.objectStore(STORE);
    obj.put(entry);
    const sorted=old.sort((a,b)=>(b.savedAt||0)-(a.savedAt||0));
    for(const item of sorted.slice(3))obj.delete(item.id);
    tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
    tx.onabort=()=>reject(tx.error||new Error('Transaction aborted'));
   });lastStatus='ready';return true;
  }catch(e){lastStatus='unavailable';return false;}
 }
 function schedule(game){try{const text=JSON.stringify(game);if(text.length>MAX_BYTES){lastStatus='too_large';return false;}
  queued=text;if(timer)clearTimeout(timer);timer=setTimeout(flush,700);return true;
 }catch(e){lastStatus='unavailable';return false;}}
 function flush(){if(timer)clearTimeout(timer);timer=null;if(!queued)return Promise.resolve(false);
   const snapshot=queued;queued='';return write(snapshot);
 }
 async function purge(){try{const db=await open();await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});return true;}catch(e){return false;}}
 return {checksum,validJSON,latest,schedule,flush,purge,write,open,status:()=>lastStatus,MAX_BYTES};
});
