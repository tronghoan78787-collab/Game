/* V43: iPhone viewport/orientation support without blocking the game. */
(function(root){
  'use strict';
  const ios=/(iPhone|iPad|iPod)/.test(navigator.userAgent)||(/Macintosh/.test(navigator.userAgent)&&navigator.maxTouchPoints>1);
  const standalone=()=>!!(navigator.standalone||matchMedia('(display-mode: standalone)').matches);
  function sync(){
    const vv=root.visualViewport;
    const width=Math.round(vv?.width||root.innerWidth||document.documentElement.clientWidth);
    const height=Math.round(vv?.height||root.innerHeight||document.documentElement.clientHeight);
    if(width<=0||height<=0)return;
    const style=document.documentElement.style;
    style.setProperty('--ios-view-width',width+'px');
    style.setProperty('--ios-view-height',height+'px');
    document.documentElement.classList.toggle('is-standalone',standalone());
    document.documentElement.classList.toggle('is-ios',ios);
  }
  let scheduled=false;
  function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;sync();});}
  root.addEventListener('resize',schedule,{passive:true});
  root.addEventListener('orientationchange',()=>{schedule();setTimeout(sync,180);setTimeout(sync,450);},{passive:true});
  root.visualViewport?.addEventListener('resize',schedule,{passive:true});
  root.visualViewport?.addEventListener('scroll',schedule,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestAnimationFrame(sync);});
  document.addEventListener('DOMContentLoaded',sync);
  sync();root.IOSGameViewport={sync,ios,standalone};
})(window);
