/*
 * CỬA HÀNG TIỆN LỢI — FRONTEND CONTROLLER
 * GIẢ ĐỊNH (giai đoạn 2-4): website offline-first, người chơi dùng cảm ứng iPhone ngang;
 * bản lưu localStorage trên máy, có nút xuất/nhập JSON để chuyển thiết bị.
 */
(function(){
'use strict';
const E=window.StoreEngine;
const STORE_KEY='cua_hang_tien_loi_chibi_v12'; // Compatible V12 saves
const $=id=>document.getElementById(id);
const avatarURL=id=>(window.EMBEDDED_AVATARS&&window.EMBEDDED_AVATARS[id])||'assets/avatars/'+encodeURIComponent(String(id))+'.svg';
const safe=x=>String(x??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const timeStr=min=>`${String(Math.floor(min/60)).padStart(2,'0')}:${String(min%60).padStart(2,'0')}`;
const roleEmoji=role=>role==='cashier'?'💳':role==='operator'?'📦':'☕';
const progress=(v,goal)=>Math.max(0,Math.min(100,Math.round(v/Math.max(1,goal)*100)));
const bar=(v,max,warning=false)=>`<div class="meter${warning?' warn':''}"><i style="width:${progress(v,max)}%"></i></div>`;
const tab=(id,label,selected)=>`<button class="chip${selected===id?' active':''}" data-tab="${id}">${label}</button>`;
let S;
let foundUsableLocalSave=false, bootReady=false;
// V42: nếu bản lưu chính lỗi, thử bản dự phòng cùng origin; không ghi đè bản cũ khi đọc thất bại.
try{
  const primary=localStorage.getItem(STORE_KEY);
  try{
    const parsed=primary?JSON.parse(primary):null;
    if(parsed&&parsed.version===E.VERSION){S=E.normalizeSave(parsed);foundUsableLocalSave=true;}
    else S=E.createGame();
  }catch(err){
    const backup=localStorage.getItem(STORE_KEY+'.backup');
    try{const parsed=backup?JSON.parse(backup):null;if(parsed&&parsed.version===E.VERSION){S=E.normalizeSave(parsed);foundUsableLocalSave=true;}else S=E.createGame();}
    catch(e){S=E.createGame();}
  }
}catch(err){S=E.createGame();}

const UI={panel:null,tab:'equipment',quantities:{},saveTick:0,toastTimer:null,lastPanelRefresh:0,storageGood:true,layoutPick:null,siteInstallPrompt:null,swWaiting:null,swUpdateRequested:false};
const releaseVersion='60.0.0-chibi-art';
let volatileAmbient=false;
function ambientWanted(){try{return localStorage.getItem('chibi_ambient')==='on';}catch(e){return volatileAmbient;}}
function saveAmbient(v){volatileAmbient=!!v;try{localStorage.setItem('chibi_ambient',v?'on':'off');}catch(e){}}
function updateConnection(){const note=$('connectionNote');if(!note)return;note.hidden=navigator.onLine!==false;}
window.addEventListener('offline',updateConnection);window.addEventListener('online',updateConnection);
const state=()=>S;
const onSceneHit=(hit,id)=>{
  if(hit==='shelf'){UI.tab=id;openPanel('shelf');}
  else openPanel(hit==='staff'?'staff':hit==='order'?'order':'store');
};
let scene;
try{if(S.settings.renderMode==='3d'){scene=new window.StoreScene3D($('scene'),state,onSceneHit);document.body.classList.add('render-3d');}else{scene=new window.StoreScene($('scene'),state,onSceneHit);document.body.classList.add('render-2d','render-premium');}}
catch(err){console.warn('WebGL fallback to Canvas 2D:',err);scene=new window.StoreScene($('scene'),state,onSceneHit);document.body.classList.add('render-2d','render-premium');}
window.addEventListener('store3dfailed',()=>{if(scene instanceof window.StoreScene3D){scene=new window.StoreScene($('scene'),state,onSceneHit);document.body.classList.add('render-2d');say('Thiết bị chuyển sang đồ họa tiết kiệm.');}});
function save(){
  if(!bootReady)return;
  // Đồng bộ localStorage để pagehide không phụ thuộc tác vụ bất đồng bộ; IndexedDB giữ bản dự phòng.
  let localSaved=false;
  try{
    const encoded=JSON.stringify(S);
    if(UI.saveTick%24===0){const previous=localStorage.getItem(STORE_KEY);if(previous&&previous!==encoded){
      try{if(JSON.parse(previous)?.version===E.VERSION)localStorage.setItem(STORE_KEY+'.backup',previous);}catch(_){}
    }}
    localStorage.setItem(STORE_KEY,encoded);localSaved=true;
  }catch(e){localSaved=false;}
  const idbQueued=window.StoreVault?.schedule(S)||false;
  UI.storageGood=localSaved||(idbQueued&&window.StoreVault?.status?.()==='ready');
}
function say(message,bad=false){
  const el=$('floatText');el.textContent=message;el.hidden=false;el.classList.toggle('error',bad);
  clearTimeout(UI.toastTimer);UI.toastTimer=setTimeout(()=>el.hidden=true,2800);
  if(S.settings.sound)window.StoreAudio?.play(bad?'error':'tap');
}
let ac;
function chime(){try{ac??=new(window.AudioContext||window.webkitAudioContext)();
  const osc=ac.createOscillator(),vol=ac.createGain();osc.connect(vol);vol.connect(ac.destination);
  osc.type='sine';osc.frequency.setValueAtTime(650,ac.currentTime);osc.frequency.exponentialRampToValueAtTime(840,ac.currentTime+.09);
  vol.gain.setValueAtTime(.045,ac.currentTime);vol.gain.exponentialRampToValueAtTime(.001,ac.currentTime+.18);
  osc.start();osc.stop(ac.currentTime+.18);
}catch(e){}}
function act(action){if(!bootReady){say('Đang khôi phục tiến độ, vui lòng thử lại sau giây lát.');return {ok:false,message:'Đang tải tiến độ.'};}
 const beforeDay=S.day;
 const out=E.dispatch(S,action);if(out.message)say(out.message,!out.ok);
 if(out.ok){
  const sound={ORDER:'order',OPEN:'open',CLAIM_MISSION:'achievement',CLAIM_DAILY:'achievement',CLAIM_STORY:'achievement',CLAIM_ACHIEVEMENT:'achievement',BUY_EQUIPMENT:'stock',BUY_DECOR:'stock',STAFF_BONUS:'achievement',PLACE_DECOR:'stock',HIRE:'customer'}[action.type];
  if(sound)window.StoreAudio?.play(sound);
  save();render();if(UI.panel)renderPanel();
 }return out;}

function render(){
  document.documentElement.classList.toggle('large-text',!!S.settings.largeText);
  document.documentElement.classList.toggle('reduced-motion',!!S.settings.reducedMotion);
  $('brandName').textContent=S.name.toUpperCase();$('money').textContent=E.money(S.cash);
  $('level').textContent=S.level;$('rep').textContent=Math.round(S.reputation)+'%';
  $('day').textContent='Ngày '+S.day;$('time').textContent=timeStr(S.minutes);
  $('speed').textContent='×'+S.speed;$('pause').textContent=S.paused?'▶️':'⏸️';
  const staffHTML=S.staff.map(m=>`<div class="staff-mini" data-panel="staff" title="Xem công việc của ${safe(m.name)}">
    <span class="staff-face"><img src="${avatarURL(m.id)}" alt="" loading="lazy"></span>
    <div style="min-width:0;flex:1"><strong class="staff-name">${safe(m.name)} ${m.mood<35?'😟':m.mood>75?'😊':'😐'}</strong>
    <span class="staff-job">${safe(m.task)}</span>${bar(m.energy,100,m.energy<30)}</div>
  </div>`).join('');
  $('staffPreview').innerHTML=staffHTML;
  $('cleanPreview').textContent='🧹 '+Math.round(S.cleanliness)+'%  ·  📦 '+E.stockTotal(S,'warehouse')+'/'+E.warehouseCapacity(S)+' · 💝 '+(S.service?.repeatVisits||0);
  if($('specialEvent'))$('specialEvent').textContent=S.activeEvent?.name?'🎉 '+S.activeEvent.name:'🌟 Tiệm Chibi';
  if($('adviceQuick'))$('adviceQuick').textContent='🧠 Sức khỏe tiệm '+E.healthScore(S)+'/100';
  const fpsBadge=$('fpsBadge');
  if(fpsBadge){const rate=scene?.fps||0;fpsBadge.textContent=(rate?rate+' FPS':'— FPS')+' · '+(document.body.classList.contains('render-3d')?'3D':'2.5D');}
  const tip=E.nextTip(S);
  $('tips').hidden=!!S.tutorial.hidden;
  $('tipTitle').textContent=tip.title;$('tipDescription').textContent=tip.text;$('tipGo').dataset.panel=tip.panel;
  const btn=$('openButton');btn.hidden=S.opened;
  if(!S.opened){
    const isReady=E.stockTotal(S,'stock')>0;
    btn.textContent=isReady?'🎉 KHAI TRƯƠNG':'📦 ĐẶT HÀNG ĐỂ KHAI TRƯƠNG';
    btn.dataset.action=isReady?'open':'firstOrder';
  }
  const readyContracts=E.contractList(S).filter(c=>!c.claimed&&c.ready(S)).length;
  const available=E.MISSIONS.filter(m=>!S.questsClaimed.includes(m.id)&&E.currentMetric(S,m.metric)>=m.goal).length+readyContracts;
  $('missionCount').textContent=available;$('missionCount').hidden=!available;
}
function openPanel(panel){
  const names={more:'☰ Toàn bộ chức năng',operations:'📋 Trung tâm vận hành',finance:'💰 Sổ dòng tiền',advisor:'🧠 Trợ lý điều hành',contracts:'🎟️ Hợp đồng khu phố',help:'❓ Hướng dẫn chơi và phím tắt',layout:'🧩 Thiết kế và bố trí',story:'📖 Hành trình cửa hàng',store:'🏪 Quản lý cửa hàng',order:'📦 Đặt hàng & kho',shelf:'🛒 Quản lý kệ hàng',staff:'👥 Phân công nhân sự',promo:'🏷️ Chương trình khuyến mãi',
    shop:'🛍️ Cửa hàng nâng cấp',missions:'🎯 Nhiệm vụ cửa hàng',achievements:'🏆 Thành tựu',report:'📈 Báo cáo kinh doanh',settings:'⚙️ Cài đặt',events:'📣 Nhật ký NPC',daily:'🌞 Nhiệm vụ hằng ngày',reviews:'💬 Đánh giá khách hàng',receipts:'🧾 Hóa đơn đã bán'};
  if(!names[panel])return;UI.panel=panel;renderPanel();
  $('modalRoot').hidden=false;
  const mobileBrand=document.querySelector('.mobile-nav-button[data-panel="'+panel+'"]');
  document.querySelectorAll('.mobile-nav-button').forEach(x=>x.classList.toggle('selected',x===mobileBrand));
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('selected',x.dataset.panel===panel));
}
function closePanel(){UI.panel=null;$('modalRoot').hidden=true;$('modalRoot').innerHTML='';
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('selected',x.dataset.panel==='store'));
  document.querySelectorAll('.mobile-nav-button').forEach(x=>x.classList.toggle('selected',x.dataset.panel==='store'));
}
function panelBody(){switch(UI.panel){
  case 'more':return viewMobileMore();
  case 'operations':return viewOperations();case 'finance':return viewFinance();case 'advisor':return viewAdvisor();case 'contracts':return viewContracts();case 'help':return viewHelp();case 'layout':return viewLayout();case 'story':return viewStory();case 'store':return viewStore();case 'order':return viewOrder();case 'shelf':return viewShelves();
  case 'staff':return viewStaff();case 'promo':return viewPromo();case 'shop':return viewShop();
  case 'missions':return viewMissions();case 'achievements':return viewAchievements();case 'report':return viewReport();
  case 'settings':return viewSettings();case 'events':return viewEvents();case 'daily':return viewDaily();case 'reviews':return viewReviews();case 'receipts':return viewReceipts();default:return'';
}}
function renderPanel(){
  if(!UI.panel)return;
  const root=$('modalRoot');const body=root.querySelector('.modal-body');const oldScroll=body?.scrollTop||0;
  const names={more:'☰ Toàn bộ chức năng',operations:'📋 Trung tâm vận hành',finance:'💰 Sổ dòng tiền',advisor:'🧠 Trợ lý điều hành',contracts:'🎟️ Hợp đồng khu phố',help:'❓ Hướng dẫn chơi và phím tắt',layout:'🧩 Thiết kế và bố trí',story:'📖 Hành trình cửa hàng',store:'🏪 Quản lý cửa hàng',order:'📦 Đặt hàng & kho',shelf:'🛒 Quản lý kệ hàng',staff:'👥 Phân công nhân sự',promo:'🏷️ Chương trình khuyến mãi',shop:'🛍️ Cửa hàng nâng cấp',missions:'🎯 Nhiệm vụ cửa hàng',achievements:'🏆 Thành tựu',report:'📈 Báo cáo kinh doanh',settings:'⚙️ Cài đặt',events:'📣 Nhật ký NPC',daily:'🌞 Nhiệm vụ hằng ngày',reviews:'💬 Đánh giá khách hàng',receipts:'🧾 Hóa đơn đã bán'};
  root.innerHTML=`<section class="game-modal" role="dialog" aria-modal="true" aria-label="${names[UI.panel]}">
    <div class="modal-heading"><h2>${names[UI.panel]}</h2><button class="close" data-action="close" aria-label="Đóng">×</button></div>
    <div class="modal-body">${panelBody()}</div></section>`;
  root.querySelector('.modal-body').scrollTop=oldScroll;
}
function viewMobileMore(){
  const actions=[
   ['🛒','Kệ hàng','shelf'],['🏷️','Khuyến mãi','promo'],['🧠','Trợ lý','advisor'],
   ['📋','Vận hành','operations'],['🛍️','Nâng cấp','shop'],['🧩','Bố trí','layout'],
   ['📈','Báo cáo','report'],['💰','Dòng tiền','finance'],['🌞','Nhiệm vụ ngày','daily'],
   ['🎟️','Hợp đồng','contracts'],['🏆','Thành tựu','achievements'],['📖','Cốt truyện','story'],
   ['💬','Đánh giá khách','reviews'],['📣','Nhật ký','events'],['⚙️','Cài đặt','settings'],['❓','Hướng dẫn','help']
  ];
  return `<p class="modal-subtitle">Chạm một chức năng để mở. Không cần kéo menu nhỏ hoặc xoay điện thoại.</p>
    <button class="game-button green full" data-action="testTouch">👆 KIỂM TRA CẢM ỨNG — CHẠM VÀO ĐÂY</button>
  <div class="mobile-more-grid">${actions.map(([icon,label,panel])=>`<button class="mobile-more-tile" data-panel="${panel}"><span>${icon}</span><b>${label}</b></button>`).join('')}</div>`;
}
function viewStore(){
  const buyRate=E.stockTotal(S,'stock')+E.stockTotal(S,'warehouse');
  return `<div class="info-strip"><span>🏷️ ${safe(S.name)}</span><span>🏆 Cấp ${S.level}</span><span>⭐ Uy tín ${Math.round(S.reputation)}%</span><span>📦 Hàng sẵn có ${buyRate}</span></div>
    <div class="grid two">
      <div class="game-card"><span class="icon">🏪</span><h3>Cửa hàng của bạn</h3><p>${S.opened?'🟢 Đang đón khách':'🟠 Chưa mở cửa'} · Ngày ${S.day}, ${timeStr(S.minutes)}</p>
        <p>Cửa hàng có ${E.activeCats(S).length} khu vực hàng hóa và ${S.staff.length} nhân viên. Chạm vào kệ ngoài bản đồ để mở đúng ngành hàng.</p>
        <button class="game-button ${S.opened?'red':'green'} full" data-action="${S.opened?'closeShop':'open'}">${S.opened?'🔒 Tạm đóng cửa':'🎉 Khai trương'}</button></div>
      <div class="game-card"><span class="icon">🌟</span><h3>Nâng cấp không gian</h3>
        <p>Cấp mở rộng: ${S.storeLevel}/2. Cấp cửa hàng trưởng: ${S.level}. ${S.storeLevel<2?'Mở khóa Mì gói và Đông lạnh khi đạt cấp 2.':'Đã mở thêm hai ngành hàng!'}</p>
        <p class="price">Chi phí mở rộng: ${E.money(2600000)}</p>
        <button class="game-button full" data-action="expand" ${S.storeLevel>=2||S.level<2||S.cash<2600000?'disabled':''}>${S.storeLevel>=2?'✅ Đã mở rộng':S.level<2?'🔒 Cần cấp 2':'🏗️ Mở rộng cửa hàng'}</button></div>
    </div>
    <div class="section-heading">Chỉ đạo nhanh</div><div class="chips"><button class="game-button green" data-panel="advisor">🧠 Gợi ý vận hành</button><button class="game-button gold" data-panel="contracts">🎟️ Hợp đồng ngày</button></div>
    <div class="section-heading">Tình hình hiện tại</div>
    <div class="grid"><div class="report-stat"><small>Doanh thu hôm nay</small><b>${E.money(S.today.revenue)}</b></div>
      <div class="report-stat"><small>Khách đã phục vụ</small><b>${S.today.served}</b></div>
      <div class="report-stat"><small>Vệ sinh</small><b>${Math.round(S.cleanliness)}%</b></div></div>
    <div class="section-heading">Bộ công cụ cửa hàng trưởng</div><div class="chips"><button class="game-button green" data-panel="layout">🧩 Sắp xếp nội thất</button><button class="game-button gold" data-panel="story">📖 Hành trình kinh doanh</button><button class="game-button" data-panel="staff">👥 Tuyển và phân ca</button><button class="game-button green" data-panel="operations">📋 Trung tâm vận hành</button></div>`;
}
function viewOrder(){
  const room=E.availableRoom(S);
  const pending=S.pending.length?`<div class="hint">🚚 ${S.pending.map(p=>`${safe(E.CATEGORIES.find(c=>c.id===p.cat)?.name)}: ${p.arrived?'đã đến, chờ nhận':Math.max(0,p.arrivesAt-S.elapsed)+' giây'} (${p.received}/${p.qty})`).join(' · ')}</div>`:'';
  return `<div class="info-strip"><span>💰 Vốn ${E.money(S.cash)}</span><span>📦 Kho ${E.stockTotal(S,'warehouse')}/${E.warehouseCapacity(S)}</span><span>📥 Còn chỗ ${room}</span><span>📊 Giá trị tồn: ${E.money(E.inventoryAudit(S).reduce((a,c)=>a+c.stockValue,0))}</span></div>
  ${pending}<div class="smart-order-callout"><div><strong>🧠 Gợi ý nhập hàng</strong><p>${safe(E.forecastMessage(S))}</p></div><button class="game-button green" data-action="autoOrder">ĐẶT THEO DỰ BÁO</button></div><div class="hint">Nhà cung cấp giao hàng sau ${S.equipment.includes('express')?5:9} giây thực. Bình (nhân viên vận hành) sẽ tự nhận hàng rồi bổ sung lên kệ. Hàng nhập trừ tiền ngay khi đặt.</div>
  <div class="chips"><button class="game-button gold" data-panel="operations">📊 Định mức và nhập hàng tự động</button><button class="game-button" data-panel="finance">💰 Xem sổ tiền</button></div><div class="grid">${E.activeCats(S).map(c=>{
    const q=UI.quantities[c.id]||24;
    return `<div class="game-card"><span class="icon">${c.icon}</span><h3>${c.name}</h3>
      <div class="meta"><span>Giá nhập / SP</span><b>${E.money(c.cost)}</b></div>
      <div class="meta"><span>Giá bán / SP</span><b>${E.money(c.price)}</b></div>
      <div class="meta"><span>Kệ: ${S.stock[c.id]}</span><span>Kho: ${S.warehouse[c.id]}</span></div>
      <div class="qty-row">${[12,24,48,96].map(n=>`<button data-qty="${n}" data-cat="${c.id}" class="${q===n?'on':''}">${n}</button>`).join('')}</div>
      <button class="game-button green full" data-buy-order="${c.id}" ${S.cash<c.cost*q||room<q?'disabled':''}>ĐẶT ${q} · ${E.money(q*c.cost)}</button></div>`;
  }).join('')}</div>`;
}
function viewShelves(){
  const selected=E.activeCats(S).find(c=>c.id===UI.tab);
  const ordered=E.activeCats(S).slice().sort((a,b)=>Number(b.id===UI.tab)-Number(a.id===UI.tab));
  return `<div class="hint">${selected?'🎯 Kệ đã chọn: <b>'+safe(selected.name)+'</b>. ':''}Nhân viên vận hành tự lấy hàng theo nguyên tắc FIFO (lô nhập trước ưu tiên bán trước). Trái cây hạn 3 ngày, sữa hạn 5 ngày. Có thể xem thời điểm nhập và số lượng từng lô ngay trong kệ.</div><button class="game-button green" data-action="audit">📋 Kiểm kê hôm nay</button>
  <div class="grid">${ordered.map(c=>{
    const cap=E.shelfCapacity(S,c.id);
    return `<div class="game-card"><span class="icon">${c.icon}</span><h3>${c.name}</h3>
    <div class="meta"><span>Kệ ${S.stock[c.id]}/${cap}</span><span>Kho ${S.warehouse[c.id]}</span></div>${bar(S.stock[c.id],cap,S.stock[c.id]<6)}
    <p>Giá bán: ${E.money(c.price)} · ${E.activeDiscount(S,c.id)>0?'🏷️ Giảm '+E.activeDiscount(S,c.id)+'%':'Giá niêm yết'}</p>
    ${['fruit','milk'].includes(c.id)?`<div class="batch-lines">${E.inventoryAudit(S).find(x=>x.id===c.id).batches.map(l=>`<span class="${S.day-l.day>=(['fruit'].includes(c.id)?2:4)?'expiring':''}">📅 ${l.area}: ${l.qty} SP · Nhận ngày ${l.day}</span>`).join('')||'Chưa có lô hàng'}</div>`:''}
    <button class="game-button full" data-panel="order">📦 Đặt thêm hàng</button></div>`;
  }).join('')}</div>`;
}
function viewStaff(){
  return `<div class="hint">Khởi đầu với An và Bình. Lên cấp 2 có thể tuyển thêm Linh và Minh (tối đa 4 nhân viên). Mỗi người được phân công chức vụ, ca làm việc và kỹ năng trọng tâm. Khách cần giúp đỡ vẫn là ưu tiên cao.</div>
  <div class="role-line">${S.staff.map(m=>`<div class="role-box"><span class="avatar"><img src="${avatarURL(m.id)}" alt="" loading="lazy"></span><div style="min-width:0;flex:1">
    <strong>${m.name} ${m.mood>=70?'😊':m.mood<35?'😟':'😐'}</strong>
    <p>🎓 Kỹ năng ${m.skill}/5 · 💖 Tâm trạng ${Math.round(m.mood)}%</p>${bar(m.energy,100,m.energy<30)}
    <p>⚡ Thể lực ${Math.round(m.energy)}% · ${safe(m.task)}</p>
    <label class="muted" for="role-${m.id}">Phân công:</label>
    <select id="role-${m.id}" data-role-staff="${m.id}">${E.ROLES.map(r=>`<option value="${r}" ${m.role===r?'selected':''}>${E.ROLE_NAMES[r]}</option>`).join('')}</select>
    <div class="row staff-options"><label class="muted">Ca làm <select data-shift-staff="${m.id}"><option value="full" ${m.shift==='full'||!m.shift?'selected':''}>Cả ngày</option><option value="morning" ${m.shift==='morning'?'selected':''}>08–15h</option><option value="evening" ${m.shift==='evening'?'selected':''}>15–22h</option></select></label><label class="muted">Thế mạnh<select data-trait-staff="${m.id}"><option value="friendly" ${m.trait==='friendly'||!m.trait?'selected':''}>Thân thiện</option><option value="efficient" ${m.trait==='efficient'?'selected':''}>Nhanh nhẹn</option><option value="patient" ${m.trait==='patient'?'selected':''}>Kiên nhẫn</option></select></label></div>
    <button class="game-button small full" data-train="${m.id}" ${m.skill>=5||S.cash<240000?'disabled':''}>🎓 Đào tạo · 240.000đ</button>
    </div></div>`).join('')}</div>
  <div class="game-card" style="margin-top:8px"><div class="row between"><div><strong>👥 Tuyển nhân viên</strong><p>Đội ngũ ${S.staff.length}/4 · Phí tuyển 450.000đ/người · Lương 95.000đ/ngày/người</p></div><button class="game-button green" data-action="hire" ${S.level<2||S.staff.length>=4||S.cash<450000?'disabled':''}>${S.level<2?'Cần cấp 2':S.staff.length>=4?'Đủ nhân sự':'Tuyển thêm'}</button></div></div>
  <div class="section-heading">📋 Ưu tiên công việc của nhân viên vận hành</div>
  <div class="hint">NPC vẫn ưu tiên trường hợp khẩn cấp. Khi không có khách cần hỗ trợ, bạn có thể thay đổi thứ tự xử lý các việc khác.</div>
  <div class="chips">${[['customer','🤝 Hỗ trợ khách'],['delivery','🚚 Nhận hàng'],['shelf','🛒 Lên kệ'],['clean','🧹 Vệ sinh']].map(([id,label])=>`<button class="chip ${((S.priority||'customer')===id)?'active':''}" data-priority="${id}">${label}</button>`).join('')}</div>
  <div class="section-heading">Cơ chế tự lựa chọn công việc</div>
  <div class="section-heading">🎁 Khen thưởng nhân viên</div><div class="chips">${S.staff.map(m=>`<button class="game-button small gold" data-bonus="${m.id}" ${S.cash<50000||m.mood>=98?'disabled':''}>🎁 Thưởng ${m.name} · 50.000đ</button>`).join('')}</div>
  <div class="grid two"><div class="game-card"><h3>👩🏻‍💼 Thu ngân</h3><p>1. Ưu tiên khách xếp hàng. 2. Thanh toán và tự tư vấn khuyến mãi. 3. Chào hỏi và hướng dẫn khách khi rảnh.</p></div>
  <div class="game-card"><h3>👨🏻‍🔧 Vận hành</h3><p>1. Ưu tiên hỗ trợ khách đang tìm hàng. 2. Nhận hàng. 3. Bổ sung kệ sắp hết. 4. Vệ sinh khi độ sạch giảm.</p></div></div>`;
}
function viewPromo(){
  const cat=E.activeCats(S);const selected=cat.find(c=>c.id===UI.tab)||cat[0];const rate=UI.quantities.promoRate??10;
  const active=S.promo.cat?E.CATEGORIES.find(c=>c.id===S.promo.cat):null;
  return `<div class="hint">Thu ngân sẽ tự giới thiệu sản phẩm có chương trình giảm giá. Giảm giá có thể làm tăng lượt khách và tỷ lệ mua thêm, nhưng giảm lợi nhuận mỗi sản phẩm.</div>
  <div class="info-strip"><span>🏷️ Đang chạy: ${active?active.name+' -'+S.promo.rate+'%':'Không có'}</span><span>Hiệu lực: ${active?'đến hết ngày '+S.promo.untilDay:'—'}</span></div>
  <div class="section-heading">Chọn ngành hàng</div><div class="chips">${cat.map(c=>tab(c.id,c.icon+' '+c.name,selected.id)).join('')}</div>
  <div class="section-heading">Chọn mức giảm giá</div>
  <div class="chips">${[5,10,15].map(n=>`<button class="chip ${rate===n?'active':''}" data-promo-rate="${n}">${n}%</button>`).join('')}</div>
  <div class="info-strip" style="margin-top:12px">Giá gốc: ${E.money(selected.price)} → Giá sau giảm: <strong>${E.money(selected.price*(1-rate/100))}</strong> · Lãi gộp/SP: <strong>${E.money(selected.price*(1-rate/100)-selected.cost)}</strong></div>
  <button class="game-button green" data-set-promo="${selected.id}">📣 Chạy ưu đãi ${selected.name} -${rate}%</button>
  <button class="game-button gray" data-action="stopPromo">Tắt khuyến mãi</button>`;
}
function viewShop(){
  const equip=UI.tab!=='decor';const items=equip?E.EQUIPMENT:E.DECOR;
  return `<div class="chips" style="margin-bottom:9px">${tab('equipment','🛠️ Trang thiết bị',equip?'equipment':'decor')}${tab('decor','🎀 Vật phẩm trang trí',!equip?'decor':'equipment')}</div>
  <div class="info-strip">💰 Ngân sách: <strong>${E.money(S.cash)}</strong> · ${equip?'Mua 1 lần, hiệu ứng hoạt động vĩnh viễn':'Trang trí tăng sức hút và uy tín cửa hàng'}</div>
  <div class="grid">${items.map(item=>{
    const owned=(equip?S.equipment:S.decor).includes(item.id);
    return `<div class="game-card"><span class="icon">${item.icon}</span><h3>${item.name}</h3><p>${item.desc}</p>
      <div class="price">${E.money(item.price)}</div>
      <button class="game-button green full" ${owned||S.cash<item.price?'disabled':''} data-purchase="${item.id}" data-kind="${equip?'equipment':'decor'}">${owned?'✅ Đã sở hữu':S.cash<item.price?'🔒 Thiếu tiền':'🛍️ Mua ngay'}</button></div>`;
  }).join('')}</div>`;
}
function viewDaily(){
  return `<div class="info-strip"><span>🌤️ Ngày ${S.day}</span><span>⭐ Uy tín ${Math.round(S.reputation)}%</span><span>🧹 Độ sạch ${Math.round(S.cleanliness)}%</span></div>
    <div class="hint">Nhiệm vụ sẽ thay đổi theo ngày. Mỗi phần thưởng chỉ nhận một lần. Hãy phục vụ tốt và giữ cửa hàng sạch sẽ!</div>
    ${E.activeDailyTasks(S).map(t=>{
      const value=E.dailyValue(S,t),done=S.dailyClaimed.includes(S.day+':'+t.id);
      return `<div class="mission"><span class="mission-icon">🌞</span><div class="mission-info"><strong>${t.name}</strong><small>${t.desc}</small>${bar(Math.min(value,t.goal),t.goal)}<small>${Math.min(t.goal,Math.floor(value)).toLocaleString('vi-VN')}/${t.goal.toLocaleString('vi-VN')} · ${E.money(t.reward)} + ${t.xp} XP</small></div><button class="game-button small ${value>=t.goal&&!done?'green':'gray'}" data-claim-daily="${t.id}" ${done||value<t.goal?'disabled':''}>${done?'Đã nhận':'Nhận'}</button></div>`;
    }).join('')}
    <button class="game-button full" data-panel="missions">🎯 Xem nhiệm vụ dài hạn</button>`;
}
function viewReviews(){
  const n=S.reviews.length;const score=n?(S.reviews.reduce((a,r)=>a+r.stars,0)/n).toFixed(1):'—';
  return `<div class="info-strip"><span>💬 Đánh giá gần nhất: ${n}</span><span>⭐ Trung bình ${score}/5</span></div>
    <div class="hint">Khách sẽ để lại nhận xét sau khi thanh toán hoặc bỏ về. Đánh giá giúp bạn nhận biết vấn đề trong cửa hàng.</div>
    ${n?S.reviews.map(r=>`<div class="review-card"><div class="row between"><strong>${'⭐'.repeat(Math.min(5,Math.max(1,r.stars)))}</strong><small>Ngày ${r.day}</small></div><p>${safe(r.text)}</p></div>`).join(''):'<div class="game-card">Chưa có đánh giá. Hãy khai trương và phục vụ những vị khách đầu tiên.</div>'}
    <button class="game-button full" data-panel="report">📊 Về báo cáo kinh doanh</button>`;
}
function viewMissions(){
  return `<div class="chips" style="margin-bottom:9px"><button class="game-button gold" data-panel="contracts">🎟️ Hợp đồng khu phố · ${E.contractList(S).filter(c=>!c.claimed&&c.ready(S)).length} có thể nhận</button><button class="game-button" data-panel="daily">🌞 Nhiệm vụ ngày</button></div><button class="game-button gold" data-panel="daily">🌞 Nhiệm vụ hôm nay</button><div class="hint" style="margin-top:7px">Hoàn thành mục tiêu để nhận thêm tiền ảo và XP, tăng cấp quản lý để mở rộng cửa hàng.</div>
  ${E.MISSIONS.map(m=>{
    const v=E.currentMetric(S,m.metric),done=S.questsClaimed.includes(m.id);
    return `<div class="mission"><span class="mission-icon">${done?'✅':v>=m.goal?'🎁':'🎯'}</span>
      <div class="mission-info"><strong>${m.title}</strong><small>${m.desc}</small>${bar(Math.min(v,m.goal),m.goal)}
        <small>${Math.min(Math.floor(v),m.goal).toLocaleString('vi-VN')}/${m.goal.toLocaleString('vi-VN')} · <span class="mission-reward">${E.money(m.reward)} + ${m.xp} XP</span></small></div>
      <button class="game-button small ${v>=m.goal&&!done?'green':'gray'}" data-claim="${m.id}" ${done||v<m.goal?'disabled':''}>${done?'Đã nhận':'Nhận'}</button></div>`;
  }).join('')}`;
}
function viewAchievements(){
  return `<div class="hint">Thành tựu vĩnh viễn được ghi nhận từ các lượt kinh doanh của bạn.</div>
  ${E.ACHIEVEMENTS.map(a=>{const v=E.currentMetric(S,a.metric),done=S.achievementsClaimed.includes(a.id);
    return `<div class="mission"><span class="mission-icon">🏆</span><div class="mission-info"><strong>${a.title}</strong><small>${a.desc}</small>${bar(Math.min(v,a.goal),a.goal)}<small>${Math.min(Math.floor(v),a.goal)}/${a.goal} · Thưởng ${E.money(a.reward)}</small></div>
      <button class="game-button small ${v>=a.goal&&!done?'green':'gray'}" data-achieve="${a.id}" ${done||v<a.goal?'disabled':''}>${done?'Đã nhận':'Nhận'}</button></div>`;
  }).join('')}`;
}
function viewReceipts(){
  return `<div class="info-strip"><span>🧾 ${S.receipts?.length||0} hóa đơn gần nhất</span><span>🤝 Khách quay lại: ${S.customerCare?.loyalty||0}</span></div>
  <div class="hint">Tất cả giao dịch dùng tiền ảo. Giá vốn và doanh thu được ghi nhận khi nhân viên thu ngân hoàn tất thanh toán.</div>
  ${(S.receipts||[]).length?S.receipts.map((r,i)=>`<div class="receipt-card"><div class="row between"><b>🧾 #${S.stats.served-i} · Ngày ${r.day}</b><b class="price">${E.money(r.bill)}</b></div><small>${timeStr(r.time)} · ${r.qty} sản phẩm · Khách ${safe(r.customer)} · Giá vốn ${E.money(r.cogs)} · Lãi gộp ${E.money(r.bill-r.cogs)}</small></div>`).join(''):'<div class="game-card">Chưa có hóa đơn. Khai trương để phục vụ khách đầu tiên.</div>'}
  <button class="game-button full" data-panel="report">📈 Xem báo cáo</button>`;
}
function viewReport(){
  const net=E.dailyNet(S);const totals=S.stats;
  const rows=S.history.slice(0,6);
  const max=Math.max(1,...rows.map(r=>r.revenue),S.today.revenue);
  return `<div class="chips"><button class="game-button" data-panel="advisor">🧠 Trợ lý điều hành</button><button class="game-button gold" data-panel="reviews">💬 Đánh giá khách</button><button class="game-button green" data-panel="receipts">🧾 Xem hóa đơn</button></div><div class="grid" style="margin-top:8px"><div class="report-stat"><small>Doanh thu hôm nay</small><b>${E.money(S.today.revenue)}</b></div>
      <div class="report-stat"><small>Lãi gộp hôm nay</small><b>${E.money(S.today.revenue-S.today.cogs)}</b></div>
      <div class="report-stat"><small>Lãi ròng tạm tính*</small><b>${E.money(net)}</b></div></div>
      <p class="muted">*Lãi ròng tạm tính = doanh thu − giá vốn hàng đã bán − lương − điện nước đã ghi nhận. Tiền mua trang trí, thiết bị và mở rộng được tính riêng vào chi đầu tư.</p>
      <div class="grid"><div class="report-stat"><small>Tổng doanh thu</small><b>${E.money(totals.revenue)}</b></div>
      <div class="report-stat"><small>Khách phục vụ</small><b>${totals.served}</b></div>
      <div class="report-stat"><small>Khách bỏ về</small><b>${totals.missed}</b></div></div>
      <div class="section-heading">Lịch sử kinh doanh</div>
      ${[{day:S.day,revenue:S.today.revenue,net,served:S.today.served},...rows].map(r=>`<div class="game-card" style="margin-bottom:6px;padding:6px 10px"><div class="row between"><strong style="font-size:12px;color:#4277a1">Ngày ${r.day}</strong><small>DT ${E.money(r.revenue)} · Lãi ${E.money(r.net)} · ${r.served} khách</small></div>${bar(r.revenue,max)}</div>`).join('')}
      <div class="section-heading">Chi phí tích lũy</div><div class="info-strip"><span>Giá vốn: ${E.money(totals.cogs)}</span><span>Lương: ${E.money(totals.wages)}</span><span>Điện nước: ${E.money(totals.utilities)}</span><span>Đầu tư: ${E.money(totals.operatingCosts)}</span><span>Hỏng hủy: ${E.money(totals.wasteCost||0)}</span></div>`;
}
function viewAdvisor(){
  const health=E.healthScore(S),report=E.recommendations(S),forecast=E.salesForecast(S),d=S.director;
  return `<div class="advisor-hero"><div class="advisor-score"><strong>${health}</strong><small>/100</small></div><div><h3>🧠 Trợ lý cửa hàng trưởng</h3><p>Đánh giá từ độ sạch, uy tín, mức đầy kệ và tâm trạng nhân viên. AI hành vi chạy hoàn toàn trên máy, không gửi thông tin ra ngoài.</p></div></div>
    <div class="section-heading">Ưu tiên đề xuất</div>
    ${report.map((x,i)=>`<div class="advice-card"><span>${x.icon}</span><div><strong>${i===0?'Ưu tiên cao nhất':'Gợi ý '+(i+1)}</strong><p>${safe(x.text)}</p></div></div>`).join('')}
    <div class="chips" style="margin-top:10px"><button class="game-button green" data-action="autoOrder">📦 Đặt hàng theo dự báo</button><button class="game-button" data-action="huddle">💪 Họp đầu ca</button><button class="game-button" data-action="care">💬 Chăm sóc phản ánh</button><button class="game-button gold" data-panel="contracts">🎟️ Hợp đồng khu phố</button></div>
    <div class="section-heading">Dự báo bổ sung sản phẩm</div><div class="forecast-grid">${forecast.map(r=>`<div class="forecast-line"><b>${r.icon} ${safe(r.name)}</b><span>${r.available}/${r.target} SP</span><span class="${r.pack?'need-order':''}">${r.pack?'Đặt gợi ý '+r.pack+' SP':'Đủ hoặc cần giữ vốn'}</span></div>`).join('')}</div>
    <div class="section-heading">🗣️ Hội thoại NPC gần đây</div>
    ${d.dialogue.length?d.dialogue.slice(0,10).map(x=>`<div class="npc-dialogue"><b>${safe(x.speaker)}</b><span>${safe(x.text)}</span></div>`).join(''):'<p class="muted">Khi cửa hàng hoạt động, khách hàng và nhân viên sẽ phản hồi theo tình huống thực tế.</p>'}
    <div class="hint">Đây là mô phỏng AI có quy tắc; không phải chatbot có nhận thức hay mô hình ngôn ngữ trực tuyến.</div>`;
}
function viewContracts(){
 const list=E.contractList(S);
 return `<div class="hint">🎟️ Hợp đồng khu phố đổi theo ngày game. Mỗi hợp đồng chỉ lĩnh thưởng một lần trong ngày; phần thưởng và XP dùng tiền ảo.</div>
 ${list.map(c=>`<div class="mission"><span class="mission-icon">${c.icon}</span><div class="mission-info"><strong>${safe(c.title)}</strong><small>${safe(c.desc)}</small>${bar(c.progress,1)}<small>${c.claimed?'✅ Đã nhận':Math.round(c.progress*100)+'% tiến độ'} · ${E.money(c.reward)} + ${c.xp} XP</small></div><button class="game-button small ${c.ready(S)&&!c.claimed?'green':'gray'}" data-contract="${c.id}" ${c.claimed||!c.ready(S)?'disabled':''}>${c.claimed?'Đã nhận':'Nhận'}</button></div>`).join('')}
 <div class="chips"><button class="game-button" data-panel="missions">🎯 Nhiệm vụ chính</button><button class="game-button" data-panel="daily">🌞 Nhiệm vụ ngày</button><button class="game-button" data-panel="story">📖 Cốt truyện</button></div>`;
}
function viewEvents(){
  return `<div class="hint">Hệ thống AI hành vi cập nhật hành động của nhân viên và khách hàng theo thời gian. Nhật ký lưu ${S.log.length} sự kiện gần nhất.</div>
    ${S.log.map(a=>`<div class="event ${a.type}">Ngày ${a.at===0?1:S.day} · ${safe(a.text)}</div>`).join('')}`;
}
function viewLayout(){
  const cats=E.activeCats(S),owned=S.decor;
  const pick=UI.layoutPick;
  const shelfSelected=pick?.type==='shelf'?pick.id:null;
  const decorSelected=pick?.type==='decor'?pick.id:null;
  const slots=E.SHELF_SLOTS;
  const symbols=['🚪','🧊','🌷','🌳','🛒','💡'];
  return `<div class="hint">🧩 Tạm đóng cửa để đổi vị trí kệ. Chạm chọn một kệ ở dưới, sau đó chạm ô muốn chuyển tới. Nếu ô đã có kệ, hai kệ sẽ đổi chỗ. Bạn cũng có thể kéo thả trên trình duyệt hỗ trợ. Vật phẩm trang trí chỉ đặt ở 8 điểm an toàn, không chắn đường khách.</div>
  <div class="info-strip"><span>${S.opened?'🔴 Đang mở — cần đóng cửa để bố trí kệ':'🟢 Được phép sắp xếp kệ'}</span><span>🏪 ${cats.length} khu hàng</span><span>🎀 ${owned.length} món trang trí</span></div>
  <div class="section-heading">Chọn kệ để bố trí</div><div class="chips">${cats.map(c=>`<button draggable="true" data-drag-kind="shelf" data-drag-id="${c.id}" class="chip ${shelfSelected===c.id?'active':''}" data-layout-shelf="${c.id}">${c.icon} ${c.name} · ô ${(S.layout.shelves[c.id]??0)+1}</button>`).join('')}</div>
  <div class="layout-grid">${slots.map((v,i)=>{const occupant=cats.find(c=>S.layout.shelves[c.id]===i);return `<button data-layout-slot="${i}" data-drop-slot="${i}" class="layout-tile ${occupant?'busy':''}" ${S.opened?'disabled':''}><b>Ô ${i+1}</b><span>${occupant?.icon||'➕'}</span><small>${occupant?.name||'Trống'}</small></button>`;}).join('')}</div>
  <div class="section-heading">Vật phẩm trang trí</div><div class="chips">${owned.length?owned.map(id=>{const d=E.DECOR.find(x=>x.id===id);return `<button draggable="true" data-drag-kind="decor" data-drag-id="${id}" class="chip ${decorSelected===id?'active':''}" data-layout-decor="${id}">${d?.icon||'🎀'} ${d?.name||id}</button>`;}).join(''):'Chưa mua vật phẩm. Mở Siêu thị → Trang trí để mua.'}</div>
  <div class="layout-grid">${E.DECOR_SLOTS.map((pos,i)=>{const id=Object.keys(S.layout.decor).find(k=>S.layout.decor[k]===i);const d=E.DECOR.find(x=>x.id===id);return `<button data-decor-slot="${i}" data-drop-slot="d${i}" class="layout-tile ${id?'busy':''}"><b>${pos.label}</b><span>${d?.icon||'✨'}</span><small>${d?.name||'Chọn đồ để đặt'}</small></button>`;}).join('')}</div>
  <div class="chips" style="margin-top:8px"><button class="game-button green" data-panel="shop">🛍️ Mua vật phẩm</button><button class="game-button" data-panel="store">🏪 Về cửa hàng</button></div>`;
}
function viewStory(){
  return `${S.storyClaimed.length===E.STORY.length?'<div class="ending-banner"><strong>🏆 CHÚC MỪNG CỬA HÀNG TRƯỞNG!</strong><p>Bạn đã đưa cửa hàng trở thành tiệm kiểu mẫu. Câu chuyện đã hoàn thành, nhưng bạn có thể tiếp tục kinh doanh, trang trí và phá kỷ lục doanh thu.</p></div>':''}<div class="info-strip"><span>📖 Hành trình ${S.storyClaimed.length}/${E.STORY.length} chương</span><span>🔥 Chuỗi ngày kinh doanh hiệu quả: ${S.dailyStreak||0}</span><span>🌟 Khách VIP: ${S.service?.vipServed||0}</span></div>
    ${S.activeEvent?`<div class="hint">${S.activeEvent.icon} ${safe(S.activeEvent.name)} — ${safe(S.activeEvent.desc)}</div>`:''}
    ${E.STORY.map((m,i)=>{const done=S.storyClaimed.includes(m.id),locked=i>0&&!S.storyClaimed.includes(E.STORY[i-1].id),ready=m.ready(S);return `<div class="mission"><span class="mission-icon">${done?'🏅':locked?'🔒':'📖'}</span><div class="mission-info"><strong>${m.title}</strong><small>${m.desc}</small><small>🎁 ${E.money(m.reward)} + ${m.xp} XP</small></div><button class="game-button ${ready&&!locked&&!done?'green':'gray'} small" data-claim-story="${m.id}" ${done||locked||!ready?'disabled':''}>${done?'Đã nhận':locked?'Khóa':ready?'Nhận thưởng':'Chưa đạt'}</button></div>`;}).join('')}
  <div class="section-heading">Sự kiện luân phiên</div>${E.EVENTS.map(e=>`<div class="game-card" style="margin:5px 0"><b>${e.icon} ${e.name}</b><p>${e.desc} · chu kỳ ${e.every} ngày game</p></div>`).join('')}`;
}
function viewHelp(){
  const steps=[
   ['📦 Bước 1 — Đặt hàng','Vào Đặt hàng, chọn ngành hàng và mua số lượng vừa phải. Khởi đầu 10.000.000đ là vốn tiền ảo.','order'],
   ['🧑‍🔧 Bước 2 — Nhận và lên kệ','Bình (vận hành) tự nhận hàng từ nhà cung cấp, sau đó sắp lên kệ. Bạn có thể đổi ưu tiên công việc trong Nhân sự.','staff'],
   ['🎉 Bước 3 — Khai trương','Khi có hàng trên kệ, nhấn Khai trương. Khách tự tìm hàng rồi đến quầy.','store'],
   ['💳 Bước 4 — Thu ngân','An tự tính tiền và tư vấn khuyến mãi nếu bạn thiết lập ưu đãi. Đừng để hàng trên kệ hết.','promo'],
   ['🎯 Bước 5 — Phát triển','Nhận thưởng nhiệm vụ, mua thiết bị, tuyển người khi đủ cấp và hoàn thành bốn chương cốt truyện.','story'],
   ['💾 Lưu game','Game tự lưu trên trình duyệt hiện tại. Muốn chuyển máy hoặc đổi tên miền: Cài đặt → Xuất bản lưu JSON, sau đó Nhập ở máy mới.','settings']
  ];
  return `<div class="hint">🏪 <b>CỬA HÀNG TIỆN LỢI</b> • V60 Chibi Art Mobile. Đây là game tiền ảo chơi đơn. Chạm thanh chức năng lớn phía dưới để thao tác ở cả màn dọc lẫn ngang.</div>
    ${steps.map((row,i)=>`<div class="game-card" style="margin:6px 0"><div class="row between"><div><h3>${row[0]}</h3><p>${row[1]}</p></div><button class="game-button small" data-panel="${row[2]}">Mở</button></div></div>`).join('')}
    <div class="hint">📱 iPhone: Mở game trong Safari qua HTTPS và thêm vào Màn hình chính để ẩn thanh địa chỉ. Game hiển thị theo hướng bạn đang cầm; không tự xoay giao diện bằng CSS. Đóng Safari không làm tiến độ tiếp tục chạy ngầm. ⌨️ Phím tắt máy tính: <b>Space</b> tạm dừng, <b>Esc</b> đóng cửa sổ. Trên điện thoại: kéo một ngón để dịch camera, chụm hai ngón để phóng to/thu nhỏ ở cảnh 3D.</div>`;
}
function viewOperations(){
  const rows=E.operationsForecast(S),staff=E.staffOperationsReport(S),integrity=E.operationsIntegrity(S);
  const service=S.operations.serviceStandard;
  return `<div class="info-strip"><span>📦 Kho còn ${E.availableRoom(S)} chỗ</span><span>💵 Tiền dự phòng ${E.money(S.operations.reserveCash)}</span><span>📈 ${S.stats.served} khách đã phục vụ</span></div>
    <div class="hint">Giả định V50: dự báo dựa trên hóa đơn gần đây và bán hàng theo ngành. Hàng tươi được giới hạn lô nhập để tránh quá hạn; không tự đặt khi dưới mức tiền dự phòng. Đơn hàng được trừ tiền ảo ngay khi đặt.</div>
    <div class="row between"><strong>Quỹ tiền không sử dụng để đặt hàng</strong><select class="input" style="width:auto" data-reserve="1">${[0,500000,1000000,1200000,1500000,2000000,3000000].map(n=>`<option value="${n}" ${n===S.operations.reserveCash?'selected':''}>${E.money(n)}</option>`).join('')}</select></div>
    <div class="grid">${rows.map(r=>`<div class="game-card"><span class="icon">${r.icon}</span><h3>${r.name}</h3>
      <p>Đang có: <b>${r.onHand}</b> · Đang giao: <b>${r.incoming}</b></p>
      <p>Đã bán gần đây: ${r.soldRecent} · Dự báo: ${r.dailyVelocity} SP/ngày</p>
      <div class="row between"><label>Ngưỡng đặt <select data-rule-min="${r.id}" class="input">${[0,6,10,12,18,24,36,48].map(n=>`<option value="${n}" ${r.minimum===n?'selected':''}>${n} SP</option>`).join('')}</select></label>
      <label>Mục tiêu <select data-rule-target="${r.id}" class="input">${[12,18,24,36,48,72,96].map(n=>`<option value="${n}" ${r.target===n?'selected':''}>${n} SP</option>`).join('')}</select></label></div>
      <p>${r.nearExpiry?'⚠️ Gần hạn: '+r.nearExpiry+' SP. ':''}${r.reason}</p>
      <button class="game-button green full" data-replenish="${r.id}" ${!r.canOrder?'disabled':''}>${r.pack?'Nhập đề xuất '+r.pack+' · '+E.money(r.orderCost):'Chưa cần nhập'}</button></div>`).join('')}</div>
    <button class="game-button green full" data-action="replenishAll">📦 ĐẶT HÀNG CẦN THIẾT THEO ĐỊNH MỨC</button>
    <div class="section-heading">👩🏻‍💼 Quy trình phục vụ</div>
    <div class="chips">${[['customer','🤝 Khách hàng trước'],['balanced','⚖️ Cân bằng'],['shelf','🛒 Ưu tiên kệ']].map(([id,name])=>`<button class="chip ${service===id?'active':''}" data-service-standard="${id}">${name}</button>`).join('')}</div>
    <div class="hint">Quy trình hướng dẫn AI ưu tiên các loại công việc. NPC vẫn xử lý các tình huống khẩn cấp dựa trên thang điểm của mô hình hành vi.</div>
    <div class="section-heading">📊 Hoạt động nhân viên (ước tính từ mô phỏng)</div>
    <div class="grid two">${staff.map(m=>`<div class="game-card"><strong>${safe(m.name)} · ${m.role==='cashier'?'Thu ngân':m.role==='operator'?'Vận hành':'Nghỉ'}</strong>
      <p>${safe(m.focus)}</p><p>🧾 Thanh toán ${m.checkouts} · 📦 Xếp kệ ${m.restocked} · 🧹 Vệ sinh ${m.cleaned}</p><p>❤️ Tâm trạng ${m.mood}% · ⚡ Thể lực ${m.energy}%</p></div>`).join('')}</div>
    <div class="section-heading">🔒 Kiểm tra dữ liệu</div><div class="game-card"><strong>${integrity.valid?'✅ Dữ liệu hợp lệ':'⚠️ Cần kiểm tra bản lưu'}</strong>
    <p>${integrity.errors.length?integrity.errors.map(safe).join(' · '):'Không phát hiện lỗi nghiêm trọng trong tồn kho và sổ tiền.'}</p>
    <p>${integrity.warnings.length?integrity.warnings.map(safe).join(' · '):'Không có cảnh báo bổ sung.'}</p></div>
    <div class="chips"><button class="game-button" data-panel="finance">💰 Xem sổ dòng tiền</button><button class="game-button" data-panel="report">📈 Báo cáo chung</button></div>`;
}
function viewFinance(){
  const audit=E.financeAudit(S),rows=E.operationsForecast(S),inventory=E.inventoryAudit(S);
  const valuation=inventory.reduce((n,r)=>n+r.stockValue,0);
  return `<div class="hint">Giả định V49: sổ dòng tiền mới ghi các nghiệp vụ kể từ lúc nâng cấp V49, không tạo giao dịch lịch sử giả. Giá trị tồn kho = số hàng đang có × giá nhập; không bao gồm hàng đang giao. Đây là báo cáo game, không phải chứng từ kế toán thực.</div>
  <div class="grid two"><div class="report-stat"><small>💰 Tiền mặt hiện tại</small><b>${E.money(S.cash)}</b></div>
    <div class="report-stat"><small>📦 Giá trị hàng tồn</small><b>${E.money(valuation)}</b></div>
    <div class="report-stat"><small>📈 Lãi gộp tích lũy</small><b>${E.money(S.stats.revenue-S.stats.cogs)}</b></div>
    <div class="report-stat"><small>🏪 Doanh thu hôm nay</small><b>${E.money(S.today.revenue)}</b></div></div>
  <div class="info-strip"><span>Đã ghi ${audit.recorded} dòng tiền</span><span>${audit.valid?'✅ Khớp số dư':'⚠️ Chênh lệch '+E.money(Math.abs(audit.difference))}</span><span>Ghi từ ngày ${audit.firstDay}</span></div>
  <div class="section-heading">Sổ giao dịch gần nhất</div>
  ${audit.entries.length?audit.entries.slice(0,75).map(e=>`<div class="receipt-card"><div class="row between"><b>Ngày ${e.day} · ${safe(e.type)}</b><b style="color:${e.delta>0?'#287c4f':'#a34b33'}">${e.delta>0?'+':''}${E.money(e.delta)}</b></div><small>${safe(e.detail||'Giao dịch cửa hàng')} · #${e.seq}</small></div>`).join(''):'<div class="game-card">Chưa có giao dịch nào từ khi nâng cấp hệ thống sổ tiền.</div>'}
  <div class="section-heading">Tỷ trọng hàng hóa</div><div class="grid">${rows.map(r=>`<div class="game-card"><b>${r.icon} ${r.name}</b><p>Tồn ${r.onHand} SP · Dự kiến ${r.dailyVelocity}/ngày</p></div>`).join('')}</div>`;
}
function viewSettings(){
  return `<div class="section-heading">Thông tin người chơi</div><div class="row"><input class="input" id="storeNameInput" maxlength="25" value="${safe(S.name)}" aria-label="Tên cửa hàng"><button class="game-button" data-action="rename">Lưu tên</button></div>
  <div class="section-heading">Chất lượng và trải nghiệm</div>
  <div class="game-card"><div class="row between"><strong>🔊 Âm thanh thông báo</strong><button class="game-button small" data-action="sound">${S.settings.sound?'BẬT':'TẮT'}</button></div><div class="line"></div>
    <div class="row between"><strong>🎵 Nhạc nền thư giãn</strong><button class="game-button small" data-action="ambient">${ambientWanted()?'BẬT':'TẮT'}</button></div><div class="line"></div>
    <div class="row between"><strong>🏷️ Hiện tên nhân viên</strong><button class="game-button small" data-action="showNames">${S.settings.showNames?'BẬT':'TẮT'}</button></div><div class="line"></div>
    <div class="row between"><strong>🖼️ Phong cách hình ảnh</strong><select id="renderMode" class="input" style="width:auto"><option value="illustrated" ${S.settings.renderMode!=='3d'?'selected':''}>Chibi minh họa HD</option><option value="3d" ${S.settings.renderMode==='3d'?'selected':''}>3D thử nghiệm</option></select></div><div class="line"></div>
    <div class="row between"><strong>⚡ Mục tiêu FPS</strong><select id="fpsTarget" class="input" style="width:auto"><option value="20" ${S.settings.fpsTarget===20?'selected':''}>20 FPS tiết kiệm pin</option><option value="30" ${(S.settings.fpsTarget||30)===30?'selected':''}>30 FPS cân bằng</option><option value="45" ${S.settings.fpsTarget===45?'selected':''}>45 FPS</option><option value="60" ${S.settings.fpsTarget===60?'selected':''}>60 FPS nếu máy hỗ trợ</option></select></div><div class="line"></div>
    <div class="row between"><strong>✨ Hiệu ứng ánh sáng</strong><button class="game-button small" data-action="lighting">${S.settings.lighting!==false?'BẬT':'TẮT'}</button></div><div class="line"></div>
    <div class="row between"><strong>🎨 Chất lượng đồ họa</strong><select id="quality" class="input" style="width:auto" data-quality="1"><option value="auto" ${S.settings.quality==='auto'?'selected':''}>Tự động</option><option value="high" ${S.settings.quality==='high'?'selected':''}>Cao</option><option value="low" ${S.settings.quality==='low'?'selected':''}>Tiết kiệm pin</option></select></div></div>
  <div class="section-heading">Trợ năng iPhone</div>
  <div class="game-card"><div class="row between"><strong>🔠 Chữ và nút lớn hơn</strong><button class="game-button small" data-action="largeText">${S.settings.largeText?'BẬT':'TẮT'}</button></div><div class="line"></div>
    <div class="row between"><strong>🧘 Giảm chuyển động nền</strong><button class="game-button small" data-action="reduceMotion">${S.settings.reducedMotion?'BẬT':'TẮT'}</button></div></div>
  <div class="section-heading">Chơi trên Safari / màn hình chính</div>
  <div class="ios-welcome"><b>📱 Cách cài trên iPhone:</b> Mở đường dẫn HTTPS bằng Safari → nhấn nút <b>Chia sẻ</b> → chọn <b>Thêm vào Màn hình chính</b> → mở biểu tượng Cửa Hàng Tiện Lợi. Game mở ngay, không có màn hình buộc xoay máy. Xoay ngang để có diện tích chơi tốt nhất.<br><small>Đã cài PWA thì có thể chơi offline sau lần tải tài nguyên thành công. Không xóa dữ liệu website khi chưa xuất bản lưu.</small></div>
  <div class="section-heading">Lưu và khôi phục tiến độ</div>
  <div class="hint">Game lưu bằng localStorage và dự phòng IndexedDB trên cùng thiết bị. Nếu xoá dữ liệu Safari, cả hai nơi đều có thể mất. Hãy dùng Xuất bản lưu JSON và lưu vào ứng dụng Tệp/iCloud Drive để bảo vệ tiến độ.</div>
  <div class="ios-status ${UI.storageGood?'':'warning'}">💾 Lưu game: ${UI.storageGood?'Đang hoạt động':'Bị hạn chế'} · IndexedDB: ${safe(window.StoreVault?.status?.()||'chưa xác định')} · ${window.IOSGameViewport?.standalone()?'Ứng dụng đã thêm vào Màn hình chính':'Chạy trong trình duyệt'}</div>
  <div class="hint">🧪 Chế độ hiển thị: <b>${document.body.classList.contains('render-3d')?'WebGL 3D':'Canvas 2.5D'}</b> · <span id="settingsFps">${scene?.fps||'Chưa đo'} FPS</span>. Đã tải ${scene.loadedSprites||0}/${Object.keys(scene.sprites||{}).length||0} ảnh minh họa. FPS trong trình duyệt là tham khảo, không xác nhận tốc độ trên iPhone thật.</div>
  <div class="chips"><button class="game-button" data-panel="help">❓ Hướng dẫn</button><button class="game-button" data-action="install">📲 Cài game</button>${UI.swWaiting?'<button class="game-button green" data-action="update">🔄 Cập nhật an toàn</button>':''}</div>
  <div class="chips"><button class="game-button green" data-action="export">⬇️ Xuất bản lưu</button><button class="game-button" data-action="import">⬆️ Nhập bản lưu</button><button class="game-button red" data-action="reset">🗑️ Chơi lại từ đầu</button></div>
  <p class="muted">V60 Chibi Art Mobile • ${document.body.classList.contains('render-3d')?'WebGL 3D':'Canvas 2.5D'} • FPS ${scene.fps||'—'} • Offline-first • Dữ liệu không tự gửi lên máy chủ • ${UI.storageGood?'✅ Trình duyệt đang cho phép lưu':'⚠️ Trình duyệt đang hạn chế lưu'}</p>`;
}
function reset(){if(!window.confirm('Tạo cửa hàng mới? Toàn bộ tiến độ trên trình duyệt này sẽ được thay thế.'))return;
  S=E.createGame();save();closePanel();scene.visuals.clear();render();say('Bắt đầu ngày kinh doanh mới!');}
function exportSave(){save();const name='cua-hang-tien-loi-v60-backup.json';
  const b=new Blob([JSON.stringify(S,null,2)],{type:'application/json'});
  const file=new File([b],name,{type:'application/json'});
  if(navigator.canShare?.({files:[file]})&&typeof navigator.share==='function'){
    navigator.share({files:[file],title:'Sao lưu Cửa Hàng Tiện Lợi'}).then(()=>say('Đã chia sẻ bản lưu.')).catch(err=>{
      if(err.name!=='AbortError')fallbackDownload();});
    return;
  }
  fallbackDownload();
  function fallbackDownload(){const url=URL.createObjectURL(b),a=document.createElement('a');a.href=url;a.download=name;
    document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);say('Đã tạo bản sao lưu JSON.');}
}
function handleButton(btn){
  if(btn.hasAttribute('data-cat-panel')){UI.tab=btn.dataset.catPanel;openPanel('shelf');return;}
  if(btn.hasAttribute('data-panel')){openPanel(btn.dataset.panel);return;}
  if(btn.dataset.tab){UI.tab=btn.dataset.tab;renderPanel();return;}
  if(btn.dataset.qty){UI.quantities[btn.dataset.cat]=Number(btn.dataset.qty);renderPanel();return;}
  if(btn.dataset.promoRate){UI.quantities.promoRate=Number(btn.dataset.promoRate);renderPanel();return;}
  if(btn.dataset.buyOrder){act({type:'ORDER',id:btn.dataset.buyOrder,qty:UI.quantities[btn.dataset.buyOrder]||24});return;}
  if(btn.dataset.purchase){act({type:btn.dataset.kind==='decor'?'BUY_DECOR':'BUY_EQUIPMENT',id:btn.dataset.purchase});return;}
  if(btn.dataset.train){act({type:'TRAIN',staffId:btn.dataset.train});return;}
  if(btn.dataset.bonus){act({type:'STAFF_BONUS',staffId:btn.dataset.bonus});return;}
  if(btn.dataset.claim){act({type:'CLAIM_MISSION',id:btn.dataset.claim});return;}
  if(btn.dataset.claimStory){act({type:'CLAIM_STORY',id:btn.dataset.claimStory});return;}
  if(btn.dataset.layoutShelf){UI.layoutPick={type:'shelf',id:btn.dataset.layoutShelf};renderPanel();return;}
  if(btn.dataset.layoutDecor){UI.layoutPick={type:'decor',id:btn.dataset.layoutDecor};renderPanel();return;}
  if(btn.dataset.layoutSlot){if(!UI.layoutPick||UI.layoutPick.type!=='shelf'){say('Chọn một kệ trước khi chọn ô.',true);return;}act({type:'MOVE_SHELF',id:UI.layoutPick.id,slot:Number(btn.dataset.layoutSlot)});return;}
  if(btn.dataset.decorSlot){if(!UI.layoutPick||UI.layoutPick.type!=='decor'){say('Chọn một món đồ trang trí trước.',true);return;}act({type:'PLACE_DECOR',id:UI.layoutPick.id,slot:Number(btn.dataset.decorSlot)});return;}
  if(btn.dataset.claimDaily){act({type:'CLAIM_DAILY',id:btn.dataset.claimDaily});return;}
  if(btn.dataset.contract){act({type:'CLAIM_CONTRACT',id:btn.dataset.contract});return;}
  if(btn.dataset.priority){act({type:'PRIORITY',id:btn.dataset.priority});return;}
  if(btn.dataset.replenish){act({type:'REPLENISH',id:btn.dataset.replenish});return;}
  if(btn.dataset.serviceStandard){act({type:'SET_SERVICE_STANDARD',standard:btn.dataset.serviceStandard});return;}
  if(btn.dataset.achieve){act({type:'CLAIM_ACHIEVEMENT',id:btn.dataset.achieve});return;}
  if(btn.dataset.setPromo){act({type:'SET_PROMO',id:btn.dataset.setPromo,rate:UI.quantities.promoRate??10});return;}
  switch(btn.dataset.action){
    case 'testTouch':say('✅ Nút chạm hoạt động! Bạn có thể tiếp tục chơi.');break;
    case 'close':closePanel();break;
    case 'firstOrder':openPanel('order');break;
    case 'open':{const out=act({type:'OPEN'});if(out.ok)closePanel();break;}
    case 'closeShop':act({type:'CLOSE'});break;
    case 'expand':act({type:'EXPAND'});break;
    case 'pause':act({type:'TOGGLE_PAUSE'});break;
    case 'speed':act({type:'SET_SPEED',speed:S.speed>=3?1:S.speed+1});break;
    case 'zoomIn':scene.adjustZoom(.12);break;
    case 'zoomOut':scene.adjustZoom(-.12);break;
    case 'audit':act({type:'AUDIT'});break;
    case 'autoOrder':act({type:'AUTO_ORDER'});break;
    case 'replenishAll':act({type:'REPLENISH'});break;
    case 'huddle':act({type:'TEAM_HUDDLE'});break;
    case 'care':act({type:'CUSTOMER_CARE'});break;
    case 'hire':act({type:'HIRE'});break;
    case 'rotateCamera':if(scene.rotateCamera)scene.rotateCamera();else say('Camera xoay chỉ hỗ trợ WebGL 3D.');break;
    case 'hideTip':act({type:'SKIP_TUTORIAL'});break;
    case 'stopPromo':act({type:'SET_PROMO',id:E.activeCats(S)[0].id,rate:0});break;
    case 'sound':{const on=!S.settings.sound;if(!on)saveAmbient(false);act({type:'SETTING',key:'sound',value:on});window.StoreAudio?.unlock();window.StoreAudio?.setEnabled(on);if(on)window.StoreAudio?.play('welcome');break;}
    case 'ambient':{const enabled=!ambientWanted();saveAmbient(enabled);if(enabled&&!S.settings.sound)act({type:'SETTING',key:'sound',value:true});window.StoreAudio?.unlock();window.StoreAudio?.setEnabled(!!S.settings.sound);window.StoreAudio?.setAmbient(enabled);renderPanel();break;}
    case 'update':{if(UI.swWaiting){UI.swUpdateRequested=true;save();window.StoreVault?.flush?.();UI.swWaiting.postMessage({type:'ACTIVATE_UPDATE'});say('Đang áp dụng phiên bản mới...');}else say('Không có phiên bản mới.');break;}
    case 'install':{if(UI.siteInstallPrompt){UI.siteInstallPrompt.prompt();UI.siteInstallPrompt=null;}
      else if(window.IOSGameViewport?.ios)say('iPhone: Mở Safari → Chia sẻ → Thêm vào Màn hình chính.');
      else say('Trình duyệt: tìm mục Thêm vào Màn hình chính hoặc Cài đặt ứng dụng.');break;}
    case 'showNames':act({type:'SETTING',key:'showNames',value:!S.settings.showNames});break;
    case 'largeText':act({type:'SETTING',key:'largeText',value:!S.settings.largeText});break;
    case 'reduceMotion':act({type:'SETTING',key:'reducedMotion',value:!S.settings.reducedMotion});break;
    case 'lighting':act({type:'SETTING',key:'lighting',value:S.settings.lighting===false});break;
    case 'rename':act({type:'RENAME',name:$('storeNameInput').value});break;
    case 'export':exportSave();break;
    case 'import':$('importFile').click();break;
    case 'reset':reset();break;
  }
}
function onClick(e){if(!window.StoreAudio?.unlockedByUser){window.StoreAudio?.unlock();if(window.StoreAudio)window.StoreAudio.unlockedByUser=true;}
 const btn=e.target.closest('button');if(btn&&!btn.disabled)handleButton(btn);else{
  const card=e.target.closest('.staff-mini');if(card)openPanel('staff');
}}
document.addEventListener('click',onClick);
$('modalRoot').addEventListener('click',e=>{if(e.target===$('modalRoot'))closePanel();});
document.addEventListener('change',e=>{
  if(e.target.matches('[data-reserve]'))act({type:'SET_CASH_RESERVE',amount:Number(e.target.value)});
  if(e.target.matches('[data-rule-min],[data-rule-target]')){const id=e.target.dataset.ruleMin||e.target.dataset.ruleTarget;const card=e.target.closest('.game-card');const minimum=Number(card.querySelector('[data-rule-min]').value),target=Number(card.querySelector('[data-rule-target]').value);act({type:'SET_REORDER_RULE',id,minimum,target});}
  if(e.target.matches('[data-shift-staff]'))act({type:'SET_SHIFT',staffId:e.target.dataset.shiftStaff,shift:e.target.value});
  if(e.target.matches('[data-trait-staff]'))act({type:'SET_TRAIT',staffId:e.target.dataset.traitStaff,trait:e.target.value});
  if(e.target.matches('[data-role-staff]'))act({type:'SET_ROLE',staffId:e.target.dataset.roleStaff,role:e.target.value});
  if(e.target.id==='fpsTarget'){act({type:'SETTING',key:'fpsTarget',value:Number(e.target.value)});}
  if(e.target.id==='quality'){const out=act({type:'SETTING',key:'quality',value:e.target.value});if(out.ok)scene.resize();}
  if(e.target.id==='renderMode'){const out=act({type:'SETTING',key:'renderMode',value:e.target.value});if(out.ok){save();window.location.reload();}}
});
$('importFile').addEventListener('change',async e=>{
  const file=e.target.files?.[0];if(!file)return;
  try{if(file.size>2000000)throw Error('File sao lưu quá lớn.');
    const data=JSON.parse(await file.text());if(data.version!==E.VERSION)throw Error('Chỉ hỗ trợ định dạng dữ liệu từ V12.');
    if(!data.stats||!Array.isArray(data.staff)||!data.stock||!data.warehouse)throw Error('File thiếu dữ liệu game.');
    if(!window.confirm('Nhập bản lưu này sẽ thay thế tiến độ hiện tại. Tiếp tục?'))return;
    S=E.normalizeSave(data);save();closePanel();scene.visuals.clear();render();say('Đã nhập bản lưu thành công!');
  }catch(err){say('Không thể nhập: '+err.message,true);}finally{e.target.value='';}
});
// Desktop HTML drag-and-drop; mobile users can tap a source then a destination.
document.addEventListener('dragstart',e=>{const drag=e.target.closest('[data-drag-kind]');if(!drag)return;UI.layoutPick={type:drag.dataset.dragKind,id:drag.dataset.dragId};e.dataTransfer?.setData('text/plain',JSON.stringify(UI.layoutPick));});
document.addEventListener('dragover',e=>{if(e.target.closest('[data-drop-slot]'))e.preventDefault();});
document.addEventListener('drop',e=>{const el=e.target.closest('[data-drop-slot]');if(!el)return;e.preventDefault();if(!UI.layoutPick)return;const slot=el.dataset.dropSlot;if(slot.startsWith('d')&&UI.layoutPick.type==='decor')act({type:'PLACE_DECOR',id:UI.layoutPick.id,slot:Number(slot.slice(1))});else if(!slot.startsWith('d')&&UI.layoutPick.type==='shelf')act({type:'MOVE_SHELF',id:UI.layoutPick.id,slot:Number(slot)});});
window.addEventListener('keydown',e=>{if(e.key==='Escape')closePanel();if(e.key===' '&&!['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)){e.preventDefault();act({type:'TOGGLE_PAUSE'});}});
window.addEventListener('beforeunload',save);
window.addEventListener('pagehide',()=>{save();window.StoreVault?.flush?.();});
let audioServed=S.stats.served||0,audioDay=S.day,audioStock=E.stockTotal(S,'stock');
window.StoreAudio?.setEnabled(!!S.settings.sound);
window.addEventListener('pageshow',()=>{updateConnection();render();});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();UI.siteInstallPrompt=e;});
window.addEventListener('visibilitychange',()=>{if(document.hidden)save();});
setInterval(()=>{
  if(document.hidden||!bootReady)return;
  const times=S.paused?0:S.speed;
  for(let i=0;i<times;i++)E.advance(S,Math.random);
  if(S.day!==audioDay){window.StoreAudio?.play('day');audioDay=S.day;}
  if((S.stats.served||0)>audioServed){window.StoreAudio?.play('checkout');audioServed=S.stats.served||0;}
  const currentStock=E.stockTotal(S,'stock');
  if(currentStock>audioStock)window.StoreAudio?.play('stock');audioStock=currentStock;
  render();UI.saveTick++;
  if(UI.saveTick%4===0)save();
  if(UI.panel&&UI.saveTick%3===0&&!['settings'].includes(UI.panel) &&
    !(['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName)))renderPanel();
},1000);
render();updateConnection();
// Chờ IndexedDB khi trình duyệt không có bản lưu localStorage, tránh ghi đè bản cũ bằng game mới.
const recovery=Promise.resolve(window.StoreVault?.latest?.()).then(snapshot=>{
  if(!foundUsableLocalSave&&snapshot){S=E.normalizeSave(snapshot);say('Đã phục hồi tiến độ từ bản lưu dự phòng.');}
}).catch(()=>{}).finally(()=>{bootReady=true;render();save();});
window.ConvenienceGame={getState:()=>structuredClone(S),dispatch:act,openPanel,closePanel,reset,engine:E,release:releaseVersion,renderer:()=>document.body.classList.contains('render-3d')?'webgl':'canvas',graphicsStatus:()=>({loaded:scene.loadedSprites||0,expected:Object.keys(scene.sprites||{}).length,mode:S.settings.renderMode,quality:S.settings.quality}),ready:recovery};
// Browser QA-only fast-forward hook; absent for ordinary users.
if(window.__CHIBI_QA__===true){window.ConvenienceGame.advanceForTest=n=>{for(let i=0;i<Math.min(n,5000);i++)E.advance(S,()=>.5);render();save();return structuredClone(S);};}
if('serviceWorker' in navigator && location.protocol.startsWith('http')){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').then(reg=>{
    if(reg.waiting)UI.swWaiting=reg.waiting;
    reg.addEventListener('updatefound',()=>{const worker=reg.installing;
      worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller){UI.swWaiting=worker;say('Có phiên bản mới. Vào Cài đặt để cập nhật.');}});
    });
    let asked=false;navigator.serviceWorker.addEventListener('controllerchange',()=>{
      if(asked||!UI.swUpdateRequested)return;asked=true;save();location.reload();
    });
  }).catch(()=>{}));
}
})();
