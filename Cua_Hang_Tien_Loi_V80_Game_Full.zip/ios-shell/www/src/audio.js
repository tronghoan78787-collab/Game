/*
 * V34 — Sound design for convenience-store simulator.
 * Assumptions: 100% procedural sound; requires a real touch/click to unlock on iOS.
 * No autoplay before input. Game can be played muted. No network or audio files.
 */
(function(root){'use strict';
let ctx=null,enabled=false,ambient=false,timer=null,lastSound=0;
const frequencies={tap:560,order:460,stock:680,checkout:980,open:720,achievement:900,error:180,welcome:700,day:790,customer:620};
function unlock(){try{
 if(!ctx){const C=root.AudioContext||root.webkitAudioContext;if(!C)return false;ctx=new C();}
 if(ctx.state==='suspended')ctx.resume().catch(()=>{});
 return true;
}catch(e){return false;}}
function note(freq,duration=.13,delay=0,volume=.035,wave='sine'){
 if(!ctx||ctx.state!=='running'||!Number.isFinite(freq))return;
 const time=ctx.currentTime+delay;
 const oscillator=ctx.createOscillator(),gain=ctx.createGain();
 oscillator.type=wave;oscillator.frequency.setValueAtTime(freq,time);
 gain.gain.setValueAtTime(.0001,time);
 gain.gain.exponentialRampToValueAtTime(Math.max(.0001,volume),time+.015);
 gain.gain.exponentialRampToValueAtTime(.0001,time+duration);
 oscillator.connect(gain);gain.connect(ctx.destination);oscillator.start(time);oscillator.stop(time+duration+.02);
}
function play(event){
 if(!enabled || document.hidden)return;
 if(!ctx||ctx.state!=='running')return;
 const now=performance.now();if(event==='tap'&&now-lastSound<115)return;
 lastSound=now;
 const base=frequencies[event]||frequencies.tap;
 if(event==='checkout'){note(910,.065,0,.027,'square');note(1180,.11,.09,.028);}
 else if(event==='order'){note(440,.12,0,.026,'triangle');note(650,.15,.10,.035);}
 else if(event==='stock'){note(550,.055,0,.025,'triangle');note(700,.10,.065,.021);}
 else if(event==='achievement'){note(620,.18,0,.035);note(780,.18,.12,.035);note(1020,.32,.25,.031);}
 else if(event==='open'||event==='welcome'){note(520,.15,0,.034);note(660,.19,.15,.037);note(880,.30,.28,.030);}
 else if(event==='error'){note(235,.16,0,.025,'triangle');note(180,.19,.15,.022,'triangle');}
 else if(event==='day'){note(600,.18,0,.018);note(900,.3,.15,.020);}
 else note(base,.1,0,.025);
}
const tune=[330,392,440,392,294,330,392,262];let index=0;
function ambientPulse(){if(!enabled||!ambient||document.hidden||!ctx||ctx.state!=='running')return;
 const n=tune[index%tune.length];index++;
 note(n,.55,0,.009,'sine');note(n/2,.75,.11,.004,'triangle');
}
function setAmbient(value){ambient=Boolean(value);if(timer)clearInterval(timer);timer=null;
 if(ambient){unlock();timer=setInterval(ambientPulse,3600);ambientPulse();}
}
function setEnabled(value){enabled=Boolean(value);if(!enabled){setAmbient(false);return;}unlock();}
function stop(){if(timer)clearInterval(timer);timer=null;ambient=false;}
root.addEventListener('pagehide',()=>{if(ctx&&ctx.state==='running')ctx.suspend().catch(()=>{});});
root.addEventListener('pageshow',()=>{if(enabled&&ctx?.state==='suspended')ctx.resume().catch(()=>{});});
root.StoreAudio={unlock,setEnabled,setAmbient,stop,play,getEnabled:()=>enabled,getAmbient:()=>ambient};
})(window);
