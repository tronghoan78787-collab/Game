/* V47: versioned same-origin offline cache; waiting updates require explicit approval. */
'use strict';
const CACHE='cua-hang-tien-loi-premium-art-v60.0';
const ASSETS=['./','./index.html','./src/ios.js','./src/vault.js','./src/engine.js','./src/expansion.js','./src/director.js','./src/operations.js','./src/scene.js','./src/scene3d.js','./src/app.js','./src/style.css','./src/audio.js','./assets/icon-192.png','./assets/icon-512.png','./assets/preview.jpg','./assets/hero_v37.svg','./assets/avatars/an.svg','./assets/avatars/binh.svg','./assets/avatars/linh.svg','./assets/avatars/minh.svg','./assets/art/an_idle_happy.png','./assets/art/an_idle_sad.png','./assets/art/an_scan_happy.png','./assets/art/an_scan_sad.png','./assets/art/an_wave_happy.png','./assets/art/an_wave_sad.png','./assets/art/an_work_happy.png','./assets/art/an_work_sad.png','./assets/art/binh_idle_happy.png','./assets/art/binh_idle_sad.png','./assets/art/binh_scan_happy.png','./assets/art/binh_scan_sad.png','./assets/art/binh_wave_happy.png','./assets/art/binh_wave_sad.png','./assets/art/binh_work_happy.png','./assets/art/binh_work_sad.png','./assets/art/checkout.png','./assets/art/customer_a_idle_happy.png','./assets/art/customer_a_idle_sad.png','./assets/art/customer_a_wave_happy.png','./assets/art/customer_a_wave_sad.png','./assets/art/customer_a_work_happy.png','./assets/art/customer_a_work_sad.png','./assets/art/customer_b_idle_happy.png','./assets/art/customer_b_idle_sad.png','./assets/art/customer_b_wave_happy.png','./assets/art/customer_b_wave_sad.png','./assets/art/customer_b_work_happy.png','./assets/art/customer_b_work_sad.png','./assets/art/customer_c_idle_happy.png','./assets/art/customer_c_idle_sad.png','./assets/art/customer_c_wave_happy.png','./assets/art/customer_c_wave_sad.png','./assets/art/customer_c_work_happy.png','./assets/art/customer_c_work_sad.png','./assets/art/drink_empty.png','./assets/art/drink_full.png','./assets/art/drink_low.png','./assets/art/frozen_empty.png','./assets/art/frozen_full.png','./assets/art/frozen_low.png','./assets/art/fruit_empty.png','./assets/art/fruit_full.png','./assets/art/fruit_low.png','./assets/art/linh_idle_happy.png','./assets/art/linh_idle_sad.png','./assets/art/linh_scan_happy.png','./assets/art/linh_scan_sad.png','./assets/art/linh_wave_happy.png','./assets/art/linh_wave_sad.png','./assets/art/linh_work_happy.png','./assets/art/linh_work_sad.png','./assets/art/milk_empty.png','./assets/art/milk_full.png','./assets/art/milk_low.png','./assets/art/minh_idle_happy.png','./assets/art/minh_idle_sad.png','./assets/art/minh_scan_happy.png','./assets/art/minh_scan_sad.png','./assets/art/minh_wave_happy.png','./assets/art/minh_wave_sad.png','./assets/art/minh_work_happy.png','./assets/art/minh_work_sad.png','./assets/art/noodle_empty.png','./assets/art/noodle_full.png','./assets/art/noodle_low.png','./assets/art/snack_empty.png','./assets/art/snack_full.png','./assets/art/snack_low.png','./health.json','./manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  const names=await caches.keys();await Promise.all(names.filter(name=>name.startsWith('cua-hang-tien-loi-')&&name!==CACHE).map(name=>caches.delete(name)));
  await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
  const request=event.request;if(request.method!=='GET')return;
  const url=new URL(request.url);if(url.origin!==self.location.origin)return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    if(request.mode==='navigate'){
      try{const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),3500);
        try{const response=await fetch(request,{signal:controller.signal});if(response.ok){cache.put(request,response.clone()).catch(()=>{});return response;}}
        finally{clearTimeout(timeout);}
      }catch(error){}
      return await cache.match('./index.html')||new Response('Bạn cần có mạng trong lần mở game đầu tiên.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
    }
    const hit=await cache.match(request);if(hit)return hit;
    try{const response=await fetch(request);if(response.ok)cache.put(request,response.clone()).catch(()=>{});return response;}
    catch(error){return new Response('Tài nguyên chưa có sẵn offline.',{status:503});}
  })());
});
