# LỘ TRÌNH V71–V75 — ĐÃ TRIỂN KHAI

| Mốc | Chức năng thực tế | Quy tắc nghiệm thu |
|---|---|---|
| **V71** | Điều chỉnh giá bán từng ngành trong khoảng 80–130%; giá áp dụng vào hóa đơn | Giá thay đổi đúng doanh thu, không đổi giá nhập |
| **V72** | 4 sự kiện nhu cầu luân phiên theo ngày; khách đổi ngành hàng muốn mua | Nhu cầu có thể dự báo và không tăng tồn kho ảo |
| **V73** | 18 mặt hàng minh họa, chọn sản phẩm trưng bày chủ lực mỗi ngành | Nhu cầu ảnh hưởng +14%; không ghi nhận SKU là tồn kho riêng |
| **V74** | 4 mục tiêu phát triển, nhận thưởng một lần; biểu tượng trên kệ có hàng | Không nhận thưởng lặp, hình hiện đúng khu đã chọn |
| **V75** | Giao diện mobile, sao lưu tương thích, kiểm thử, tài nguyên và đóng gói | Bản nguồn, bản chơi một file và ZIP từng giai đoạn |

Mỗi bản ZIP giai đoạn có mã nguồn gameplay hoàn chỉnh, nhưng các tính năng mới V72–V75 được kích hoạt theo mốc. Đây là một bản beta phát triển, không phải game đã phát hành thương mại.
